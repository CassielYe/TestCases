Logout()
{
	
	lr_start_transaction("dso_findProductSearch06_logout");
	
	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("emxPreLogout.jsp", 
		"URL=https://plmtest.pg.com/enovia/emxPreLogout.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_url("emxLogout.jsp", 
		"URL=https://plmtest.pg.com/enovia/emxLogout.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/emxPreLogout.jsp", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);


	web_url("logout", 
		"URL=https://plmtest.pg.com/enovia/servlet/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/emxLogout.jsp", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("dso_findProductSearch06_logout",LR_AUTO);
	
	//web_cache_cleanup();
	//web_cleanup_cookies();
	
	return 0;
}