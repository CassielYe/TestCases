Action()
{

	lr_think_time(lr_get_attrib_double("time"));
		
	//start load search page.
	
	lr_start_transaction("dso_findProductSearch03loadsearchscreen");
	
	web_submit_data("emxCPNFindProductDataByAutonomySearch.jsp", 
		"Action=https://plmtest.pg.com/enovia/cpn/emxCPNFindProductDataByAutonomySearch.jsp?table=pgProductDataSearchTable&Style=dialog&listMode=search&multiColumnSort=true&sortColumnName=Name%2CRevision&parameter=ProductData&toolBar=CPNFullSearchToolbar&suiteKey=eServiceSuiteCPN&HelpMarker=emxhelpsearchingproductdata&selection=multiple&genericDelete=true&fromFPDSearch2=true&suiteKey=CPN&StringResourceFileId=emxCPNStringResource&SuiteDirectory=cpn&widgetId=null&targetLocation=hiddenFrame", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t168.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=csrfTokenName", "Value=ENO_CSRF_TOKEN", ENDITEM, 
		"Name=ENO_CSRF_TOKEN", "Value={ENO_CSRF_TOKEN}", ENDITEM, 
		"Name=currentApp", "Value=ENOBUPS_AP", ENDITEM, 
		EXTRARES, 
		"Url=../common/styles/emxUIProperties.css", "Referer=https://plmtest.pg.com/enovia/cpn/emxCPNFindProductDataByAutonomySearch.jsp?table=pgProductDataSearchTable&Style=dialog&listMode=search&multiColumnSort=true&sortColumnName=Name%2CRevision&parameter=ProductData&toolBar=CPNFullSearchToolbar&suiteKey=eServiceSuiteCPN&HelpMarker=emxhelpsearchingproductdata&selection=multiple&genericDelete=true&fromFPDSearch2=true&suiteKey=CPN&StringResourceFileId=emxCPNStringResource&SuiteDirectory=cpn&widgetId=null&"
		"targetLocation=hiddenFrame", ENDITEM, 
		"Url=../common/styles/emxUIForm.css", "Referer=https://plmtest.pg.com/enovia/cpn/emxCPNFindProductDataByAutonomySearch.jsp?table=pgProductDataSearchTable&Style=dialog&listMode=search&multiColumnSort=true&sortColumnName=Name%2CRevision&parameter=ProductData&toolBar=CPNFullSearchToolbar&suiteKey=eServiceSuiteCPN&HelpMarker=emxhelpsearchingproductdata&selection=multiple&genericDelete=true&fromFPDSearch2=true&suiteKey=CPN&StringResourceFileId=emxCPNStringResource&SuiteDirectory=cpn&widgetId=null&"
		"targetLocation=hiddenFrame", ENDITEM, 
		LAST);

	web_add_header("ENO_CSRF_TOKEN", 
		"{ENO_CSRF_TOKEN}");

	web_add_header("csrfTokenName", 
		"ENO_CSRF_TOKEN");

	web_custom_request("emxFullSearchGetData.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxFullSearchGetData.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/cpn/emxCPNFindProductDataByAutonomySearch.jsp?table=pgProductDataSearchTable&Style=dialog&listMode=search&multiColumnSort=true&sortColumnName=Name%2CRevision&parameter=ProductData&toolBar=CPNFullSearchToolbar&suiteKey=eServiceSuiteCPN&HelpMarker=emxhelpsearchingproductdata&selection=multiple&genericDelete=true&fromFPDSearch2=true&suiteKey=CPN&StringResourceFileId=emxCPNStringResource&SuiteDirectory=cpn&widgetId=null&targetLocation=hiddenFrame", 
		"Snapshot=t169.inf", 
		"Mode=HTML", 
		"Body=&includeDefaultSearchFields=false&showInitialResults=false&viewFormBased=true&filterColumnPosition=last&queryType=Indexed&table=pgProductDataSearchTable&toolbar=CPNFullSearchToolbar&HelpMarker=emxhelpsearchingproductdata&submitAction=refreshCaller&switchedNavMode=false&queryLimit=2000&exportButtons=true&showTypeField=false&table=pgProductDataSearchTable&Style=dialog&listMode=search&multiColumnSort=true&sortColumnName=Name%2CRevision&parameter=ProductData&toolBar=CPNFullSearchToolbar&suiteKey="
		"eServiceSuiteCPN&HelpMarker=emxhelpsearchingproductdata&selection=multiple&genericDelete=true&fromFPDSearch2=true&suiteKey=CPN&StringResourceFileId=emxCPNStringResource&SuiteDirectory=cpn&widgetId=null&targetLocation=hiddenFrame&includeQuerySwitch=false&fieldLabels=TITLE:emxFramework.FullTextSearch.TITLE_OR_SAP_DESCRIPTION&addCustomTableColumns=true&field=TYPES=type_POA,type_pgFinishedProduct,type_pgPackingSubassembly,type_pgFormulatedProduct,type_pgPackingMaterial,type_ProductDataPart,"
		"type_pgDSOAffectedFPPList,type_pgApprovedSupplierList,type_pgAuthorizedConfigurationStandard,type_pgAuthorizedTemporarySpecification,type_pgConsumerDesignBasis,type_pgIllustration,type_FormulaTechnicalSpecification,type_pgMakingInstructions,type_pgPackingInstructions,type_pgProcessStandard,type_pgQualitySpecification,type_pgRawMaterialPlantInstruction,type_pgStackingPattern,type_pgStandardOperatingProcedure,type_pgSupplierInformationSheet,type_pgLaboratoryIndexSpecification,"
		"type_TestMethodSpecification,type_FormulationProcess,type_InternalMaterial:Type!=type_InternalCoveringMaterial,type_InternalCoreMaterial:POLICY=policy_HypotheticalPrivateFormulationPart,policy_HypotheticalPublicFormulationPart,policy_ExperimentalFormulationPart,policy_PilotFormulationPart,policy_IPMRestrictedPart,policy_ECPart,policy_IPMSpecification,policy_IPMRestrictedSpecification,policy_ProductionFormulationProcess,policy_VirtualIntermediate,policy_pgDSOAffectedFPPList,policy_InternalMaterial,"
		"policy_POA,policy_SupplierEquivalent,policy_ManufacturerEquivalent,policy_pgURTProductData&formInclusionList=REVISION_TAG,POLICYCURRENT,PLANTS_AUTHORIZED,ORGANIZATION_NAME,BRAND_NAME,SPECIFICATION_SUBTYPE,SECURITY_CLASSIFICATION,OWNING_SEGMENT,ATTR_EXPIRATION_DATE,RELEASE_DATE,EFFECTIVE_DATE,OBSOLETE_DATE,POLICY_TAG,PLANTS_AUTHORIZED_TO_USE,PLANTS_AUTHORIZED_TO_PRODUCE,PLANTS_ACTIVATED,ARTWORK_CONNECTED&default=CURRENT=policy_ECPart.state_Release&action=getOnlyJSON", 
		EXTRARES, 
		"Url=../webapps/ENORIPE_Search/ENORIPE_Search.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/GEOWebSearchUI/GEOWebSearchUI.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");
	
	web_save_timestamp_param("tStamp", LAST);
 	lr_save_string(lr_eval_string("{tStamp}"),"timestamp");	

	web_url("self", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/pull/self?_={timestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t170.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/webapps/ENORIPE_Search/ENORIPE_Search_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/PADUtils/PADUtils.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/PADUtils/assets/PADOpenCommandsSettings.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNNavigationMap/SNNavigationMap.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNNavigationMap/assets/SNNavigationMap.settings.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNNavigationMap/SNNavigationMap_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_url("dimensions", 
		"URL=https://plmtest.pg.com/enovia/resources/dictionary/dimensions", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t171.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../6WVocab/access/PredicatesNLSNames?name=ds6w&tenant=OnPremise", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_custom_request("PredicateValue", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/PredicateValue?tenant=OnPremise", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t172.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"ds6w:type\":[\"POA\",\"pgArtwork\",\"pgFinishedProduct\",\"pgMasterFinishedProduct\",\"pgPackingSubassembly\",\"pgFormulatedProduct\",\"pgBaseFormula\",\"pgURTGeneralFormulation\",\"pgPackingMaterial\",\"pgMasterPackingMaterial\",\"Product Data Part\",\"pgFabricatedPart\",\"Finished Product Part\",\"Formulation Part\",\"Packaging Material Part\",\"Product Part\",\"Packaging Assembly Part\",\"pgMasterProductPart\",\"pgMasterRawMaterialPart\",\"pgOnlinePrintingPart\",\"pgCustomerUnitPart\","
		"\"pgInnerPackUnitPart\",\"pgMasterConsumerUnitPart\",\"pgMasterCustomerUnitPart\",\"pgMasterInnerPackUnitPart\",\"pgMasterPackagingAssemblyPart\",\"pgMasterPackagingMaterialPart\",\"pgAncillaryPackagingMaterialPart\",\"pgIntermediateProductPart\",\"pgCompetitiveProductPart\",\"pgSoftwarePart\",\"Appliance Product Part\",\"Assembled Product Part\",\"Closure Part\",\"Consumer Kit Part\",\"Consumer Unit Part\",\"Display Unit Part\",\"Handling Unit Part\",\"Label Part\",\"Packaging Component Part\",\""
		"Pallet Part\",\"Promotional Item\",\"Semi-Finished Product Part\",\"Trade Unit Part\",\"Transport Unit Part\",\"pgDSOAffectedFPPList\",\"pgApprovedSupplierList\",\"pgAuthorizedConfigurationStandard\",\"pgAuthorizedTemporarySpecification\",\"pgConsumerDesignBasis\",\"pgIllustration\",\"Formula Technical Specification\",\"pgMakingInstructions\",\"pgPackingInstructions\",\"pgProcessStandard\",\"pgQualitySpecification\",\"pgRawMaterialPlantInstruction\",\"pgStackingPattern\",\""
		"pgStandardOperatingProcedure\",\"pgSupplierInformationSheet\",\"pgLaboratoryIndexSpecification\",\"Test Method Specification\",\"pgTestMethod\",\"Formulation Process\",\"Virtual Intermediate\",\"Internal Material\"]}", 
		EXTRARES, 
		"Url=/enovia/webapps/Units/Units.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/W3DXComponents/assets/fonts/3DS_ChangeView_v3.eot", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/Core/assets/fonts/3ds_fonticon.eot", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/Decorator/Decorator.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_custom_request("PredicateValue_2", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/PredicateValue?tenant=OnPremise", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t173.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"ds6w:type\":[\"POA\",\"pgArtwork\",\"pgFinishedProduct\",\"pgMasterFinishedProduct\",\"pgPackingSubassembly\",\"pgFormulatedProduct\",\"pgBaseFormula\",\"pgURTGeneralFormulation\",\"pgPackingMaterial\",\"pgMasterPackingMaterial\",\"Product Data Part\",\"pgFabricatedPart\",\"Finished Product Part\",\"Formulation Part\",\"Packaging Material Part\",\"Product Part\",\"Packaging Assembly Part\",\"pgMasterProductPart\",\"pgMasterRawMaterialPart\",\"pgOnlinePrintingPart\",\"pgCustomerUnitPart\","
		"\"pgInnerPackUnitPart\",\"pgMasterConsumerUnitPart\",\"pgMasterCustomerUnitPart\",\"pgMasterInnerPackUnitPart\",\"pgMasterPackagingAssemblyPart\",\"pgMasterPackagingMaterialPart\",\"pgAncillaryPackagingMaterialPart\",\"pgIntermediateProductPart\",\"pgCompetitiveProductPart\",\"pgSoftwarePart\",\"Appliance Product Part\",\"Assembled Product Part\",\"Closure Part\",\"Consumer Kit Part\",\"Consumer Unit Part\",\"Display Unit Part\",\"Handling Unit Part\",\"Label Part\",\"Packaging Component Part\",\""
		"Pallet Part\",\"Promotional Item\",\"Semi-Finished Product Part\",\"Trade Unit Part\",\"Transport Unit Part\",\"pgDSOAffectedFPPList\",\"pgApprovedSupplierList\",\"pgAuthorizedConfigurationStandard\",\"pgAuthorizedTemporarySpecification\",\"pgConsumerDesignBasis\",\"pgIllustration\",\"Formula Technical Specification\",\"pgMakingInstructions\",\"pgPackingInstructions\",\"pgProcessStandard\",\"pgQualitySpecification\",\"pgRawMaterialPlantInstruction\",\"pgStackingPattern\",\""
		"pgStandardOperatingProcedure\",\"pgSupplierInformationSheet\",\"pgLaboratoryIndexSpecification\",\"Test Method Specification\",\"pgTestMethod\",\"Formulation Process\",\"Virtual Intermediate\",\"Internal Material\"]}", 
		EXTRARES, 
		"Url=/enovia/webapps/Core/assets/fonts/fontawesome-webfont.eot", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_custom_request("Predicates", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/Predicates?tenant=OnPremise", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t174.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body=ds6wg:PLMEntity", 
		LAST);

	web_custom_request("Predicates_2", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/Predicates", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t175.inf", 
		"Mode=HTML", 
		"EncType=text/uri-list", 
		"Body=ds6wg:POA", 
		LAST);

	web_custom_request("ElementsNLSNames", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/ElementsNLSNames?tenant=OnPremise", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t176.inf", 
		"Mode=HTML", 
		"EncType=text/uri-list", 
		"Body=ds6w:source\rvoid\rds6wg:Expiration Date\rds6wg:Effectivity Date\r", 
		LAST);
	
	
	//end load search page.
	
	lr_end_transaction("dso_findProductSearch03loadsearchscreen",LR_AUTO);
	

	web_revert_auto_header("X-Requested-With");

	web_add_header("Access-Control-Request-Headers", 
		"accept, content-type");


	web_add_auto_header("Origin", 
		"https://plmtest.pg.com");	
	

	web_custom_request("search", 
		"URL=https://plmsit-fed.pg.com:443/federated/search?xrequestedwith=xmlhttprequest", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t177.inf", 
		"Mode=HTML", 
		LAST);	
	
	lr_start_transaction("dso_findProductSearch04SecurityFilter");
	
	web_add_header("Origin", 
		"https://plmtest.pg.com");


	web_custom_request("search_3", 
		
		"URL=https://plmsit-fed.pg.com:443/federated/search?xrequestedwith=xmlhttprequest&ticket={token}", 
		
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t395.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"query\":\"[ds6wg:SECURITY_CLASSIFICATION]:*Dish*\",\"order_field\":\"relevance\",\"order_by\":\"desc\",\"select_synthesis\":[\"ds6wg:SECURITY_CLASSIFICATION\"],\"select_predicate\":[\"ds6wg:SECURITY_CLASSIFICATION\"],\"source\":[\"3dspace\"],\"tenant\":\"OnPremise\"}", 
		LAST);
	
	lr_end_transaction("dso_findProductSearch04SecurityFilter",LR_AUTO);	
	
	lr_start_transaction("dso_findProductSearch05applySearch");	

	web_reg_save_param_ex(
		"ParamName=lib",
		"LB=ds6w:library\",\"type\":\"string\",\"field\":\"implicit\",\"object\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=reserved",
		"LB=ds6w:reserved\",\"type\":\"boolean\",\"value\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=status",
		"LB=ds6w:status\",\"type\":\"string\",\"value\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=policy",
		"LB=ds6w:policy\",\"type\":\"string\",\"field\":\"implicit\",\"object\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=project",
		"LB=ds6w:project\",\"type\":\"string\",\"field\":\"implicit\",\"object\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=org",
		"LB=ds6w:originator\",\"type\":\"string\",\"field\":\"implicit\",\"object\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=resp",
		"LB=ds6w:responsible\/ds6w:originator\",\"type\":\"string\",\"value\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=revision",
		"LB=ds6wg:revision\",\"type\":\"string\",\"value\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=mod",
		"LB=ds6w:modified\",\"type\":\"date\",\"value\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	
	web_reg_save_param_ex(
		"ParamName=createDate",
		"LB=ds6w:created\",\"type\":\"date\",\"field\":\"implicit\",\"object\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=createDateTime",
		"LB=ds6w:created\",\"type\":\"date\",\"value\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
		web_reg_save_param_ex(
		"ParamName=modDate",
		"LB=ds6w:modified\",\"type\":\"date\",\"field\":\"implicit\",\"object\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=rsId",
		"LB=\"resourceid\",\"type\":\"STRING\",\"value\":\"",
		"RB=\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=sourceName",
		"LB=\"status\":true,\"name\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/search*",
		LAST);

	web_save_timestamp_param("tStamp", LAST);
 	lr_save_string(lr_eval_string("{tStamp}"),"timestamp");	
 
 	
	web_revert_auto_header("X-Requested-With");

	web_add_header("Access-Control-Request-Headers", 
		"accept, content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");
	
	web_custom_request("search_7", 
		"URL=https://plmsit-fed.pg.com:443/federated/search?xrequestedwith=xmlhttprequest", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"with_indexing_date\":true,\"with_nls\":false,\"label\":\"3DSearch-{pUserName}-{timestamp}\",\"locale\":\"en\",\"select_predicate\":[\"ds6w:identifier\",\"ds6wg:revision\",\"ds6w:type\",\"ds6w:responsible\",\"ds6w:originator\",\"ds6w:created\",\"ds6w:modified\",\"ds6w:label\",\"ds6w:description\",\"ds6w:project\"],\"select_file\":[\"icon\",\"thumbnail_2d\"],\"query\":\"([ds6w:identifier]:({pSearchName}) AND [ds6wg:SECURITY_CLASSIFICATION]:({securityCode}) AND ( flattenedtaxonomies:\\\"types/POA\\\" "
		"OR flattenedtaxonomies:\\\"types/pgArtwork\\\" OR flattenedtaxonomies:\\\"types/pgFinishedProduct\\\" OR flattenedtaxonomies:\\\"types/pgMasterFinishedProduct\\\" OR flattenedtaxonomies:\\\"types/pgPackingSubassembly\\\" OR flattenedtaxonomies:\\\"types/pgFormulatedProduct\\\" OR flattenedtaxonomies:\\\"types/pgBaseFormula\\\" OR flattenedtaxonomies:\\\"types/pgURTGeneralFormulation\\\" OR flattenedtaxonomies:\\\"types/pgPackingMaterial\\\" OR flattenedtaxonomies:\\\"types/"
		"pgMasterPackingMaterial\\\" OR flattenedtaxonomies:\\\"types/Product Data Part\\\" OR flattenedtaxonomies:\\\"types/pgFabricatedPart\\\" OR flattenedtaxonomies:\\\"types/Finished Product Part\\\" OR flattenedtaxonomies:\\\"types/Formulation Part\\\" OR flattenedtaxonomies:\\\"types/Packaging Material Part\\\" OR flattenedtaxonomies:\\\"types/Product Part\\\" OR flattenedtaxonomies:\\\"types/Packaging Assembly Part\\\" OR flattenedtaxonomies:\\\"types/pgMasterProductPart\\\" OR flattenedtaxonomies"
		":\\\"types/pgMasterRawMaterialPart\\\" OR flattenedtaxonomies:\\\"types/pgOnlinePrintingPart\\\" OR flattenedtaxonomies:\\\"types/pgCustomerUnitPart\\\" OR flattenedtaxonomies:\\\"types/pgInnerPackUnitPart\\\" OR flattenedtaxonomies:\\\"types/pgMasterConsumerUnitPart\\\" OR flattenedtaxonomies:\\\"types/pgMasterCustomerUnitPart\\\" OR flattenedtaxonomies:\\\"types/pgMasterInnerPackUnitPart\\\" OR flattenedtaxonomies:\\\"types/pgMasterPackagingAssemblyPart\\\" OR flattenedtaxonomies:\\\"types/"
		"pgMasterPackagingMaterialPart\\\" OR flattenedtaxonomies:\\\"types/pgAncillaryPackagingMaterialPart\\\" OR flattenedtaxonomies:\\\"types/pgIntermediateProductPart\\\" OR flattenedtaxonomies:\\\"types/pgCompetitiveProductPart\\\" OR flattenedtaxonomies:\\\"types/pgSoftwarePart\\\" OR flattenedtaxonomies:\\\"types/Appliance Product Part\\\" OR flattenedtaxonomies:\\\"types/Assembled Product Part\\\" OR flattenedtaxonomies:\\\"types/Closure Part\\\" OR flattenedtaxonomies:\\\"types/Consumer Kit "
		"Part\\\" OR flattenedtaxonomies:\\\"types/Consumer Unit Part\\\" OR flattenedtaxonomies:\\\"types/Display Unit Part\\\" OR flattenedtaxonomies:\\\"types/Handling Unit Part\\\" OR flattenedtaxonomies:\\\"types/Label Part\\\" OR flattenedtaxonomies:\\\"types/Packaging Component Part\\\" OR flattenedtaxonomies:\\\"types/Pallet Part\\\" OR flattenedtaxonomies:\\\"types/Promotional Item\\\" OR flattenedtaxonomies:\\\"types/Semi-Finished Product Part\\\" OR flattenedtaxonomies:\\\"types/Trade Unit "
		"Part\\\" OR flattenedtaxonomies:\\\"types/Transport Unit Part\\\" OR flattenedtaxonomies:\\\"types/pgDSOAffectedFPPList\\\" OR flattenedtaxonomies:\\\"types/pgApprovedSupplierList\\\" OR flattenedtaxonomies:\\\"types/pgAuthorizedConfigurationStandard\\\" OR flattenedtaxonomies:\\\"types/pgAuthorizedTemporarySpecification\\\" OR flattenedtaxonomies:\\\"types/pgConsumerDesignBasis\\\" OR flattenedtaxonomies:\\\"types/pgIllustration\\\" OR flattenedtaxonomies:\\\"types/Formula Technical "
		"Specification\\\" OR flattenedtaxonomies:\\\"types/pgMakingInstructions\\\" OR flattenedtaxonomies:\\\"types/pgPackingInstructions\\\" OR flattenedtaxonomies:\\\"types/pgProcessStandard\\\" OR flattenedtaxonomies:\\\"types/pgQualitySpecification\\\" OR flattenedtaxonomies:\\\"types/pgRawMaterialPlantInstruction\\\" OR flattenedtaxonomies:\\\"types/pgStackingPattern\\\" OR flattenedtaxonomies:\\\"types/pgStandardOperatingProcedure\\\" OR flattenedtaxonomies:\\\"types/pgSupplierInformationSheet\\\" "
		"OR flattenedtaxonomies:\\\"types/pgLaboratoryIndexSpecification\\\" OR flattenedtaxonomies:\\\"types/Test Method Specification\\\" OR flattenedtaxonomies:\\\"types/pgTestMethod\\\" OR flattenedtaxonomies:\\\"types/Formulation Process\\\" OR flattenedtaxonomies:\\\"types/Virtual Intermediate\\\" OR flattenedtaxonomies:\\\"types/Internal Material\\\" )) AND (flattenedtaxonomies:(\\\"types/POA\\\" OR \\\"types/pgFinishedProduct\\\" OR \\\"types/pgPackingSubassembly\\\" OR \\\"types/"
		"pgFormulatedProduct\\\" OR \\\"types/pgPackingMaterial\\\" OR \\\"types/Product Data Part\\\" OR \\\"types/pgDSOAffectedFPPList\\\" OR \\\"types/pgApprovedSupplierList\\\" OR \\\"types/pgAuthorizedConfigurationStandard\\\" OR \\\"types/pgAuthorizedTemporarySpecification\\\" OR \\\"types/pgConsumerDesignBasis\\\" OR \\\"types/pgIllustration\\\" OR \\\"types/Formula Technical Specification\\\" OR \\\"types/pgMakingInstructions\\\" OR \\\"types/pgPackingInstructions\\\" OR \\\"types/"
		"pgProcessStandard\\\" OR \\\"types/pgQualitySpecification\\\" OR \\\"types/pgRawMaterialPlantInstruction\\\" OR \\\"types/pgStackingPattern\\\" OR \\\"types/pgStandardOperatingProcedure\\\" OR \\\"types/pgSupplierInformationSheet\\\" OR \\\"types/pgLaboratoryIndexSpecification\\\" OR \\\"types/Test Method Specification\\\" OR \\\"types/Formulation Process\\\" OR \\\"types/Internal Material\\\")) AND ( NOT type:\\\"Internal Covering Material\\\" AND  NOT type:\\\"Internal Core Material\\\") AND "
		"(policy:\\\"Hypothetical-Private Formulation Part\\\" OR policy:\\\"Hypothetical-Public Formulation Part\\\" OR policy:\\\"Experimental Formulation Part\\\" OR policy:\\\"Pilot Formulation Part\\\" OR policy:\\\"Production Formulation Part\\\" OR policy:\\\"EC Part\\\" OR policy:\\\"Product Data Specification\\\" OR policy:\\\"Restricted Product Data Specification\\\" OR policy:\\\"Production Formulation Process\\\" OR policy:\\\"Virtual Intermediate\\\" OR policy:\\\"pgDSOAffectedFPPList\\\" OR "
		"policy:\\\"Internal Material\\\" OR policy:\\\"POA\\\" OR policy:\\\"Supplier Equivalent\\\" OR policy:\\\"Manufacturer Equivalent\\\" OR policy:\\\"pgURTProductData\\\")  \",\"refine\":{},\"order_by\":\"desc\",\"order_field\":\"relevance\",\"nresults\":40,\"start\":\"0\",\"source\":[],\"tenant\":\"OnPremise\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");	

	web_custom_request("ElementsNLSNames_2", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/ElementsNLSNames", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t181.inf", 
		"Mode=HTML", 
		"EncType=text/uri-list", 
		"Body=ds6w:label\rds6w:type\rds6wg:revision\rds6w:status\rds6w:responsible\rds6w:modified\rds6w:project\rds6w:identifier\rds6w:description\rds6w:community", 
		LAST);

	web_custom_request("ElementsNLSNames_3", 
		"URL=https://plmtest.pg.com/enovia/resources/6WVocab/access/ElementsNLSNames?tenant=OnPremise", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ds-json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		"EncType=text/uri-list", 
		"Body=ds6w:library\rds6w:reserved\rPOA\rds6w:context\rds6w:project\rds6w:organizationResponsible\rds6w:originator\r", 
		LAST);
	
	lr_end_transaction("dso_findProductSearch05applySearch",LR_AUTO);

	return 0;
}