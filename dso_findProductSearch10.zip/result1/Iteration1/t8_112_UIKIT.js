/* global define */
define('DS/UIKIT/UIKIT', [], function () {});

/**
 * Toggle manager. Switching content made easy.
 * @module DS/UIKIT/Toggler
 */
define('DS/UIKIT/Toggler',
    [
        'UWA/Core',
        'UWA/Controls/Abstract'
    ],
    function (Core, Abstract) {
        'use strict';

        function matches (element, selector) {
            var fn = element.matchesSelector ||
                element.mozMatchesSelector ||
                element.msMatchesSelector ||
                element.oMatchesSelector ||
                element.webkitMatchesSelector;
            return fn.call(element, selector);
        }

        /**
         * @lends module:DS/UIKIT/Toggler.Toggler#
         */
        var Toggler = Abstract.extend({
            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Toggler.Toggler#
             */
            defaultOptions: {
                activeClass: 'active',
                ignored: ['disabled'],
                selected: 0,
                type: 'radio'
            },

            /**
             * Toggle manager. Switching content made easy.
             * @example
             *  require('DS/UIKIT/Toggler', function (Toggler) {
             *      'use strict';
             *      new Toggler(document.querySelector('#a-container'));
             *      // → allow the children of the element provided to be toggled
             *
             *      new Toggler({
             *          container: document.querySelector('#another-container'),
             *          activeClass: 'selected',
             *          ignored: ['disabled', 'not-selectable'],
             *          selected: 1,
             *          events: {
             *              onToggle: function (element, index, active) {
             *                  console.log(active ? 'Entering' : 'Leaving', element.innerHTML);
             *              }
             *          }
             *      });
             *      // → same as before with more options : the CSS class 'selected' will be applied to an element
             *      // when toggled. If a element matches one of the ignored selectors it won't be selected.
             *      // The second child of the container will be selected.
             *      // Finally when a switch is performed, the provided callback will be called.
             *
             * @param {HTMLElement}                          container - The container of the elements to manage.
             * @param {Object}                                 options - The available options.
             * @param {HTMLElement}                [options.container] - The container of the elements to manage.
             * @param {String}          [options.activeClass='active'] - The class to apply to an element when switched to.
             * @param {String[]}        [options.ignored=['disabled']] - Classes or CSS selector used to prevent elements from being switched to.
             * @param {number}                    [options.selected=0] - The index of the element selected by default on a radio switcher.
             * @param {HTMLElement}                     [options.bind] - A container element to bind to the toggler container.
             *                                                           When an element is toggled by the toggler, the element at the same index will be toggled as well.
             * @param {Function}             [options.events.onToggle] - A function to call when a toggle is performed. It will be called with the toggled element, its index,
             *                                                           and a boolean indicating whether the element is now active or not.
             *
             * @constructs Toggler
             * @mixes module:UWA/Controls/Abstract.UWA.Controls.Abstract
             * @memberof module:DS/UIKIT/Toggler
             */
            init: function () {
                var options = !arguments[0].nodeType ? arguments[0] : {};

                if (!options.container && arguments[0].nodeType === 1) options.container = arguments[0];
                if (options.ignored && options.ignored.indexOf('disabled') === -1) options.ignored.push('disabled');
                if (options.bind && options.bind.nodeType !== 1) delete options.bind;

                this._parent(options);

                this.elements.container = this.options.container;

                delete this.options.container;
                delete options.container;

                this.handleEvents();

                this.options.type === 'radio' && this.toggle(this.options.selected);
            },

            /**
             * @private
             */
            handleEvents: function () {
                var that = this,
                    cursor, next;
                this.events = {};
                this.events.container = {
                    click: function (event) {
                        if (event.target.parentElement !== that.elements.container) {
                            next = true;
                            cursor = event.target;
                            while ((cursor = cursor.parentElement) && next) {
                                if (cursor.parentElement === that.elements.container) {
                                    next = false;
                                    that.toggle(cursor);
                                }
                            }
                        } else {
                            that.toggle(event.target);
                        }
                    }
                };

                this.elements.container.addEventListener('click', this.events.container.click, false);
            },

            /**
             * Toggle to the provided element.
             * @method
             * @memberof module:DS/UIKIT/Toggler.Toggler#
             * @example
             *      var tabContainer = document.querySelector('.tab');
             *      var toggler = new Toggler(tabContainer);
             *
             *      toggler.toggle(4);
             *      // → toggle to the fifth child.
             *
             *      toggler.toggle(tabContainer.children[0]);
             *      // → toggle to the provided element.
             *
             * @param {HTMLElement|number} element - The element to toggle (has to be a direct child of the container) or its index.
             * @param {Boolean}  [force]           - Force selection : if `true` is provided then the active class will be added.
             *                                       If `false` is provided then the active class will be removed.
             *                                       Else the active class will be toggled.
             */
            toggle: (function () {
                function doToggle (elements, element, force) {
                    if (this.options.type === 'radio') {
                        Array.prototype.forEach.call(elements, function (elm) {
                            elm.classList[elm === element ? 'add' : 'remove'](this.options.activeClass);
                        }, this);
                    } else if (force) {
                        // ie does not support toggle second parameter for classList.toggle
                        element.classList.add(this.options.activeClass);
                    } else if (force === false) {
                        element.classList.remove(this.options.activeClass);
                    } else {
                        element.classList.toggle(this.options.activeClass);
                    }
                }

                return function () {
                    var elements = this.elements.container.children,
                        element = typeof arguments[0] === 'number' ? elements[arguments[0]] : arguments[0],
                        force = arguments[1],
                        isIgnoredElement,
                        index,
                        boundElements,
                        boundElement;

                    if (element.nodeType !== 1) return;

                    // radio mode needs a selection
                    if (element.classList.contains(this.options.activeClass) && this.options.type === 'radio') return;

                    isIgnoredElement = this.options.ignored.some(function (selector) {
                        return element.classList.contains(selector) || matches(element, selector);
                    });

                    if (isIgnoredElement) return;

                    index = Array.prototype.indexOf.call(elements, element);

                    doToggle.call(this, elements, element, force);

                    this.activeElements = Array.prototype.filter.call(elements, function (elm) { return elm.classList.contains(this.options.activeClass); }, this);

                    // if a bind option was provided, toggle the element
                    if (this.options.bind) {
                        boundElements = this.options.bind.children;
                        boundElement = boundElements[index];
                        if (boundElement && boundElement.nodeType === 1) {
                            doToggle.call(this, boundElements, boundElement, force);
                        }
                    }

                    this.dispatchEvent('onToggle', [element, index, element.classList.contains(this.options.activeClass)]);
                };
            }()),

            /**
             * Get the currently selected elements
             * @memberof module:DS/UIKIT/Toggler.Toggler#
             * @return {HTMLElement|HTMLElement[]} - The selected element if radio or an array of selected element if checkbox.
             */
            getActiveElements: function () {
                return this.options.type === 'radio' ? this.activeElements[0] : this.activeElements;
            },

            /**
             * @inheritdoc
             * @memberof module:DS/UIKIT/Toggler.Toggler#
             */
            destroy: function () {
                this.elements.container.removeEventListener('click', this.events.container.click, false);
                if (this.activeElements instanceof Array) {
                    this.activeElements.length = 0;
                } else {
                    delete this.activeElements;
                }
                delete this.elements.container;
            }
        });

        return Toggler;
    }
);

/**
 * Contextual box for displaying content such as menu or navigation lists.
 * @module DS/UIKIT/Dropdown
 */
define('DS/UIKIT/Dropdown',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Controls/Abstract'
    ],

    function (UWA, Element, Event, Abstract) {

        'use strict';

        function addEvent (evnt, elem, func, capture) {
            if (elem.addEventListener)  // W3C DOM
                elem.addEventListener(evnt, func, capture);
            else if (elem.attachEvent) { // IE DOM
                elem.attachEvent('on' + evnt, func, capture);
            }
        }

        function addEvents (evnts, elem, capture) {
            Object.keys(evnts).forEach(function (evnt) {
                addEvent(evnt, elem, evnts[evnt], capture);
            });
        }

        function removeEvent (evnt, elem, func, capture) {
            if (elem.removeEventListener)  // W3C DOM
                elem.removeEventListener(evnt, func, capture);
            else if (elem.detachEvent) { // IE DOM
                elem.detachEvent('on' + evnt, func, capture);
            }
        }

        function removeEvents (evnts, elem, capture) {
            Object.keys(evnts).forEach(function (evnt) {
                removeEvent(evnt, elem, evnts[evnt], capture);
            });
        }

        /** @lends module:DS/UIKIT/Dropdown.Dropdown# */
        var Dropdown = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            name: 'dropdown',

            /**
             * @property {Object} defaultOptions - The default Dropdown options.
             * @private
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            defaultOptions: {
                className: '',
                bound: true,
                position: 'bottom left',
                closeOnClick: true,
                removeOnHide: true,
                contextual: false,
                offset: { x: 0, y: 0 },
                attributes: {}
            },

            /**
             * Dropdown visibility state.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            isVisible: false,

            /**
             * Dropdown activation state.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            enabled: true,

            /**
             * Contextual box for displaying content such as menu or navigation lists.
             *
             * Extend this component for more advance usage.
             *
             * @example
             * require(['DS/UIKIT/Dropdown', 'DS/UIKIT/Input/Button'], function (Dropdown, Btn) {
             *     var myButton = new Btn({ value: "Click me" }).inject(widget.body);
             *
             *     var myDropdown = new Dropdown({
             *         body: "<p>One fine body</p>",
             *         target: myButton.getContent()
             *     });
             * });
             *
             * @param {Object} options                           - The available options.
             *
             * @param {Element} [options.target]                 - Bind the Dropdown to the provided target element.
             *                                                     The `target` will be used for positioning, attaching events and inserting the Dropdown DOM.
             *                                                     In case of a contextual Dropdown, the Dropdown will only be shown when a click happens inside the `target` element.
             *                                                     Defaults to `document` for contextual.
             * @param {Boolean} [options.bound=true]             - If set to `true`, will auto show/hide the Dropdown when clicking the `target`.
             *                                                     Only works if `target` is set. Forced to `true` for contextual Dropdown.
             * @param {Boolean} [options.contextual=false]       - Should the Dropdown adopt a contextual behavior ? (displaying on right click and positioning under the mouse)
             * @param {String}  [options.position='bottom left'] - If specified, will force the Dropdown position to a specific location, default to `bottom left`, instead of
             *                                                     finding the best possible one based on available space.
             * @param {Object|Function} [options.altPosition]    - If provided, will let you specify the position of the Dropdown either by providing an object with `x` and `y` properties
             *                                                     or a function returning the same object structure.
             * @param {Element} [options.renderTo=document.body] - If specified will inject the Dropdown inside the provided Element. Default is `document.body`.
             * @param {Boolean} [options.closeOnClick=true]      - If `true` will hide the Dropdown when it is clicked. Forced to `true` for contextual Dropdown.
             * @param {Boolean} [options.removeOnHide=true]      - If `true` will remove the Dropdown from the DOM after it is hidden. Forced to `true` for contextual Dropdown.
             * @param {String}  [options.className='']           - An optional className to apply to the DropdownMenu in case you want to apply custom styles through your stylesheet.
             * @param {Element|String|Object} [options.body]     - The body of the Dropdown component. Can be an Element, a String (in case you only want a text displayed) or
             *                                                     an Object describing an element.
             * @param {Object}  [options.offset]                 - An optional offset to apply to the position if you are partially satisfied with the position you get and
             *                                                     do not want to specify an `altPosition`.
             *
             * @param {number} [options.offset.x=0]              - The x offset.
             * @param {number} [options.offset.y=0]              - The y offset.
             *
             * @param {Object} [options.attributes={}]           - A map of attributes to set to the Dropdown container.
             *
             * @param {Object} [options.events]                  - The available events.
             *
             * @param {Function} [options.events.onShow]         - An event dispatched when the Dropdown is shown.
             * @param {Function} [options.events.onHide]         - An event dispatched when the Dropdown is hidden.
             * @param {Function} [options.events.onClick]        - An event dispatched when the Dropdown is clicked.
             * @param {Function} [options.events.onClickOutside] - An event dispatched when a click is received outside of the Dropdown.
             * @param {Function} [options.events.onMouseLeave]   - An event dispatched when the cursor leaves the Dropdown container.
             *
             * @constructs Dropdown
             * @memberof module:DS/UIKIT/Dropdown
             */
            init: function (options) {

                this._parent(options);

                options = this.options;
                this.events = {};

                // Bind click on document to hide Dropdown
                this.events.document = {
                    click: function (event) {
                        var target = Event.getElement(event);

                        // Hide if the click happened outside of the container
                        if (!target.isInjected(this.elements.container) && target !== this.elements.container) {
                            if (this.options.contextual || !this.options.target.contains(target)) {
                                this.hide();
                                this.dispatchEvent('onClickOutside', [event]);
                            }
                        }
                    }.bind(this)
                };

                // Normalize entry options
                options.target = UWA.is(options.target, 'element') ? UWA.extendElement(options.target) : options.contextual ? UWA.extendElement(document) : null;
                options.bound = (options.target && options.bound) || options.contextual;
                options.closeOnClick = options.contextual ? true : options.closeOnClick;
                options.removeOnHide = options.contextual ? true : options.removeOnHide;

                // Will create the DOM
                this.buildSkeleton();
            },

            /**
             * Getter for the Dropdown body.
             * @return {Element} - The body DOM element.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            getBody: function () {
                return this.elements.container;
            },

            /**
             * Setter for the Dropdown body.
             * @param {Element|String|Object} body - The new body of the Dropdown component. Can be an Element,
             *                                       a String (in case you only want a text displayed) or an Object describing an element.
             * @returns {Dropdown} - The instance.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            setBody: function (body) {
                this.elements.container && this.elements.container.addContent(body);
                return this;
            },

            /**
             * Build HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options;

                // Break early if user called `buildSkeleton` directly
                if (elements.container) return;

                // Build container
                elements.container = UWA.createElement('div', {
                    'class': this.name + ' ' + options.className,
                    html: options.body
                });

                Object.keys(this.options.attributes).forEach(function (attrKey) {
                    elements.container.setAttribute(attrKey, options.attributes[attrKey]);
                });

                this.handleEvents();
            },

            /**
             * Attach main Dropdown events.
             * @private
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            handleEvents: function () {

                var elements = this.elements,
                    options = this.options;

                elements.container.addEvents({
                    click: this.dispatchEvent.bind(this, 'onClick'),
                    mouseleave: this.dispatchEvent.bind(this, 'onMouseLeave')
                });

                if (options.contextual) {
                    // Click event on the target to update the Dropdown position
                    this.events.target = {
                        mousedown: function (event) {

                            var target = Event.getElement(event),
                                isRightClick = UWA.Event.whichButton(event) === 2;

                            // Updates position if the click happened outside of the container
                            if (!target.isInjected(this.elements.container) && target !== this.elements.container &&
                            isRightClick && this.isVisible) {
                                this.updatePosition(event);
                            }
                        }.bind(this),
                        // Blocks the contextual menu and display our custom one
                        contextmenu: function (event) {
                            this.show(false, event);
                            Event.stop(event);
                        }.bind(this)
                    };

                    // Add the contextual events
                    addEvents(this.events.target, options.target, true);
                } else if (options.bound) {
                    // If bound will attach a click event for toggling the Dropdown visibility
                    this.events.target = { click: this.toggle.bind(this) };
                    addEvents(this.events.target, options.target, true);
                }
            },

            /**
             * Default `onClick` handler.
             * @private
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            onClick: function () {
                var preventClosing = arguments.length > 2 && !!arguments[2];
                !preventClosing && this.options.closeOnClick && this.hide();
            },

            /**
             * Update the Dropdown position.
             * We do not force the position when space is not big enough.
             * eg. if `options.position='bottom left'` but space is not available we put it to `bottom right`.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             * @returns {Dropdown} - The instance.
             */
            updatePosition: function (event, preventContextRefresh) {

                var that = this;

                var options = that.options,
                    elements = that.elements,
                    target = options.target,
                    position = that._position,
                    width, height,
                    left, top;

                function get (value) {
                    return UWA.is(value, 'function') ? value() : value;
                }

                // Do not update if not visible.
                if (!that.isVisible) return;

                // Dropdown aligns relative to an element of the DOM and there is no specific x/y coordinates
                // or target element provider function
                if (target && !options.altPosition) {
                    
                    // Once js-display class has been added, target could have moved.
                    // Only fetch viewport width, height and target position once, just before display
                    if (!preventContextRefresh) {

                        position = {};

                        var documentEl = document.documentElement;

                        // dropdown is injected within an element
                        // target coordinates have to be relative from the rendering target.
                        if (options.renderTo) {
                            position.offsets = target.getPosition(options.renderTo);
                        } else if (options.contextual && event) {
                            // dropdown is be positionned where the event happened (click usually)
                            position.offsets = {
                                x: event.pageX,
                                y: event.pageY
                            };
                        } else {
                            position.offsets = target.getOffsets();
                        }
    
                        // Keep track of surrounding dimensions to ensure entire visibility
                        position.viewportWidth = documentEl.clientWidth || window.innerWidth;
                        position.viewportHeight = documentEl.clientHeight || window.innerHeight;
                        position.scrollTop = window.pageYOffset || document.body.scrollTop || documentEl.scrollTop;
    
                        if (options.contextual) {
                            target = { offsetWidth: 0, offsetHeight: 0 };
                        } else {
                            // bottom of target element
                            position.offsets.y += target.offsetHeight;
                        }

                        position.initialOffsets = {
                            x: position.offsets.x,
                            y: position.offsets.y
                        };
                    }

                    // Default position is bottom & left
                    left = position.initialOffsets.x;
                    top = position.initialOffsets.y;
                    
                    width = elements.container.offsetWidth;
                    height = elements.container.offsetHeight;

                    // Center horizontally if specified and left space is big enough
                    if (options.position.indexOf('center') > -1 && left - width + target.offsetWidth > 0) {
                        left = left + (target.offsetWidth - width) / 2;
                    }

                    // Change to right if right space is not big enough or user specified right and left space is big enough
                    if (left + width > position.viewportWidth || (options.position.indexOf('right') > -1 && left - width + target.offsetWidth > 0)) {
                        left = left - width + target.offsetWidth;
                    }

                    // Ensure element is not cropped, happens when distance between target and left edge is lesser than menu's width.
                    if (left < 0) {
                        left = 0;
                    }

                    // Change to top if bottom space is not big enough or user specified top and top space is big enough
                    if (top + height > position.viewportHeight + position.scrollTop || (options.position.indexOf('top') > -1 && top - height - target.offsetHeight > 0)) {
                        if (top - height - target.offsetHeight > 0 || options.position.indexOf('top') > -1) {
                            elements.container.addClassName('dropup');
                            top = top - height - target.offsetHeight;
                        }
                    } else {
                        elements.container.removeClassName('dropup');
                    }

                    position.offsets = {
                        x: left + options.offset.x,
                        y: top + options.offset.y
                    };

                    // Store position info for inheriting components
                    that._position = position;

                    elements.container.setStyles({
                        left: position.offsets.x,
                        top: position.offsets.y
                    });
                    

                } else if (options.altPosition) {
                    // Precise x/y coordinates positioning or following a target element resolved by function
                    position = get(options.altPosition);

                    position.offsets = {
                        x: position.x + options.offset.x,
                        y: position.y + options.offset.y
                    };

                    // Store position info for inheriting component
                    that._position = position;
                    
                    elements.container.setStyles({
                        left: position.offsets.x,
                        top: position.offsets.y
                    });
                }
            },

            /**
             * Toggle the Dropdown visibility.
             * @returns {Dropdown} - The instance.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            toggle: function () {
                return this[this.isVisible ? 'hide' : 'show']();
            },

            /**
             * Show the Dropdown.
             * @param  {Boolean} [silent] - Avoid sending `onShow` event if `true`.
             * @param  {Object}  [event]  - An optional event to pass to the updatePosition.
             * @returns {Dropdown}        - The instance.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            show: function (silent, event) {

                var elements = this.elements,
                    options = this.options;

                // Break early if Dropdown is destroyed, disabled or already visible
                if (!elements.container || this.isVisible || !this.enabled) return this;

                // Update visibility state
                this.isVisible = true;

                // If not injected, do it now
                if (!elements.container.isInjected()) {
                    this.inject(options.renderTo ? options.renderTo : document.body);
                }

                // Ensure visibility
                elements.container.setStyle('display', '');

                // When shown add the click dismiss event
                if (this.hasEvent('onClickOutside') || options.bound) {
                    addEvent('click', document, this.events.document.click, true);
                }

                // Update the position only after it is injected and visible
                this.updatePosition(event);

                !silent && this.dispatchEvent('onShow');
                return this;
            },

            /**
             * Hide the Dropdown.
             * @param  {Boolean} [silent=false] - Avoid sending `onHide` event if set to true.
             * @returns {Dropdown}              - The instance.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            hide: function (silent) {

                var elements = this.elements,
                    options = this.options;

                // Break early if Dropdown is destroyed, disabled or already hidden
                if (!elements.container || !this.isVisible || !this.enabled) return;

                // Update visibility state
                this.isVisible = false;

                if (elements.container.isInjected()) {
                    if (options.removeOnHide) {
                        elements.container.remove();
                    }

                    // When hidden remove the click dismiss event
                    removeEvent('click', document, this.events.document.click, true);
                }

                // Ensure not visible
                elements.container.setStyle('display', 'none');

                !silent && this.dispatchEvent('onHide');
                return this;
            },

            /**
             * Enable the Dropdown.
             * @returns {Dropdown} - The instance.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            enable: function () {

                if (!this.enabled) {
                    this.enabled = true;
                }

                return this;
            },

            /**
             * Disable the Dropdown.
             * @return {Dropdown} - The instance.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            disable: function () {

                if (this.enabled) {
                    this.hide();
                    this.enabled = false;
                }

                return this;
            },

            /**
             * Destroy the Dropdown.
             * @memberof module:DS/UIKIT/Dropdown.Dropdown#
             */
            destroy: function () {
                // Remove any click event or DOM leftovers
                this.hide(true);
                this.options.bound && removeEvents(this.events.target, this.options.target, true);
                this._parent();
            }
        };

        return Abstract.extend(Dropdown);
    });

/**
 * Tells your users how slow your application could be.
 * @module DS/UIKIT/Spinner
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Spinner',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Controls/Abstract'
    ],


    function (UWA, Element, Event, Client, Abstract) {

        'use strict';

        function parseClassName (klasses) {
            var i, l, match;

            if (klasses) {
                klasses = klasses.split(' ');
                for (i = 0, l = klasses.length; i < l; i++) {
                    match = klasses[i].match(/(spinner-)?(small|large)$/);
                    if (match && !match[1]) {
                        if (match[0] === 'small') {
                            klasses[i] = 'spinner-sm';
                        } else if (match[0] === 'large') {
                            klasses[i] = 'spinner-lg';
                        }
                    }
                }
                klasses = klasses.join(' ');
            }
            return klasses;
        }

        /**
         * @lends module:DS/UIKIT/Spinner.Spinner#
         */
        var Spinner = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            name: 'spinner',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            defaultOptions: {
                className: '',
                hwaccel: true,
                visible: false,
                spin: true,
                animate: true
            },

            /**
             * Spinner visibility state.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            isVisible: false,

            /**
             * Tells your users how slow your application could be.
             *
             * @example
             * require(['DS/UIKIT/Spinner'], function (Spinner) {
             *     var spinner = new Spinner();
             *     spinner.inject(widget.body);
             *     spinner.show();
             *     var otherSpinner = new Spinner({ spin: false, renderTo: widget.body, visible: true });
             *     otherSpinner.spin();
             * });
             *
             * @param {Object} options                        - The available options.
             * @param {String}  [options.className]           - An optional class name.
             * @param {Boolean} [options.hwaccel=true]        - Whether to use hardware acceleration.
             * @param {Element} [options.renderTo]            - If provided will inject the spinner inside this Element. Else would have to be done manually.
             * @param {Boolean} [options.visible=false]       - Whether to display it on injection.
             * @param {Boolean} [options.spin=true]           - Whether to start as spinning. Else should call spin() manually.
             * @param {number}  [options.duration]            - If provided will spin only for the duration provided then hide itself. It will start as soon as it is shown.
             * @param {Boolean} [options.animate=true]        - Should the spinner be animated (opacity fade in).
             * @param {Object}  [options.events]              - The available events.
             *
             * @param {Function}  [options.events.onShow]     - Invoked when the spinner is shown.
             * @param {Function}  [options.events.onSpin]     - Invoked when the spinner starts spinning.
             * @param {Function}  [options.events.onSpinStop] - Invoked when the spinner stops spinning.
             * @param {Function}  [options.events.onHide]     - Invoked when the spinner is hidden.
             *
             * @constructs Spinner
             * @memberof module:DS/UIKIT/Spinner
             */
            init: function (options) {

                options = options || {};

                this._parent(options);

                this.buildSkeleton();

                // Handle renderTo option
                if (UWA.is(options.renderTo, 'element')) {
                    this.inject(options.renderTo);

                    // Remove reference
                    delete this.options.renderTo;
                }
            },

            /**
             * Post injection hook to handle the visible option.
             * @private
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            onPostInject: function () {
                if (this.options.visible || this.isVisible) {
                    this.isVisible = false;
                    this.show();
                }
            },

            /**
             * Build spinner HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            buildSkeleton: function () {

                var options = this.options;

                this.elements.container = UWA.createElement('div', {
                    'class': this.name + ' ' + parseClassName(options.className),
                    html: [
                        UWA.createElement('span', { 'class': 'spinner-bar' }),
                        UWA.createElement('span', { 'class': 'spinner-bar spinner-bar1' }),
                        UWA.createElement('span', { 'class': 'spinner-bar spinner-bar2' }),
                        UWA.createElement('span', { 'class': 'spinner-bar spinner-bar3' })
                    ]
                });

                if (options.spin) {
                    this.spin();
                }

                if (options.animate) {
                    this.elements.container.addClassName('fade');
                }

                // Force visible to true if duration provided.
                if (options.duration) {
                    options.visible = true;
                }

                if (options.hwaccel) {
                    this.elements.container.setStyle('transform', 'translate3d(0,0,0)');
                }

                this.elements.container.setStyles({ top: options.top, left: options.left });
            },

            /**
             * Starts spinning the spinner.
             * @returns {Spinner} - The instance.
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            spin: function () {
                var elements = this.elements;
                if (!elements.container.hasClassName('spinning')) {
                    elements.container.addClassName('spinning');
                    this.dispatchEvent('onSpin');
                }
                return this;
            },

            /**
             * Stops the spinner from spinning.
             * @returns {Spinner} - The instance.
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            stop: function () {
                var elements = this.elements;
                if (elements.container.hasClassName('spinning')) {
                    elements.container.removeClassName('spinning');
                    this.dispatchEvent('onSpinStop');
                }
                return this;
            },

            /**
             * Toggle the spinner.
             * @returns {Spinner} - The instance.
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            toggle: function () {
                return this[this.isVisible ? 'hide' : 'show']();
            },

            /**
             * Show the spinner.
             * @returns {Spinner} - The instance.
             */
            show: function () {

                var that = this,
                    options = this.options,
                    elements = this.elements;

                // Safe check for destroyed spinner
                if (!elements) { return; }

                if (!this.isVisible) {

                    if (options.duration) {
                        this.timer = setTimeout(function () {
                            that.stop();
                            that.hide();
                        }, options.duration);
                    }

                    // Update semaphore
                    this.isVisible = true;

                    elements.container.setStyle('display', 'inline-block');

                    if (options.animate) {
                        // A set timeout is needed to prevent batch of style with display property
                        setTimeout(function () {
                            // Check for elements is required in case a destroy was called right after a hide / show
                            // Check for isVisible in case someone called hide right after show
                            if (that.elements && that.isVisible) {
                                that.elements.container.addClassName('in');
                                that.dispatchEvent('onShow');
                            }
                        }, 50); // Cannot setTimeout 0 as it bugs in FF
                    } else {
                        that.dispatchEvent('onShow');
                    }
                }

                return this;
            },

            /**
             * Hide the spinner.
             * @returns {Spinner} - The instance.
             */
            hide: function () {

                var that = this,
                    options = this.options,
                    elements = this.elements;

                function animating () {
                    // Needed to avoid removing spinner if someone called show right after hide
                    if (!that.isVisible) {
                        // Check for elements is required in case a destroy was called right after a hide / show
                        elements && elements.container && elements.container.setStyle('display', '');
                        that.dispatchEvent('onHide');
                    }

                    // Destroy the spinner if using duration
                    if (that.timer) {
                        that.destroy();
                    }
                }

                // Safe check for destroyed spinner
                if (!elements) { return; }

                if (this.isVisible) {

                    // Update semaphore
                    this.isVisible = false;

                    if (options.animate) {

                        // In case we have a duration running
                        if (this.timer) {
                            clearTimeout(this.timer);
                        }

                        elements.container.removeClassName('in');
                        setTimeout(function () {
                            animating();
                        }, 300);
                    } else {
                        animating();
                    }
                }

                return this;
            },

            /**
             * Destroy the spinner.
             * @memberof module:DS/UIKIT/Spinner.Spinner#
             */
            destroy: function () {
                // To prevent the animation delay when destroying.
                if (this.options) {
                    this.options.animate = false;
                }
                this.hide();
                this._parent();
                this.elements = null;
            }
        };

        return Abstract.extend(Spinner);
    });

/**
 * A control for pre-loading images.
 * @module DS/UIKIT/Image
 */
define('DS/UIKIT/Image',
    [
        'UWA/Core',
        'UWA/Class',
        'UWA/Class/Options',
        'UWA/Class/Events'
    ],
    function (UWA, Class, Options, Events) {

        'use strict';

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) { return; }

            klasses = klasses.split(' ');
            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/(img-)?(rounded|circle|thumbnail|responsive)$/);
                if (match && !match[1]) {
                    klasses[i] = 'img-' + klasses[i];
                }
            }
            return klasses.join(' ');
        }

        /**
         * @lends module:DS/UIKIT/Image.Image#
         */
        var Image = {

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Image.Image#
             */
            defaultOptions: {
                className: 'img',
                url: null,
                width: '100%',
                height: '100%'
            },

            /**
             * A control for pre-loading images.
             * @param {Object} options - The available options.
             *
             * @param {String} [options.className='img'] - An optional class name.
             * @param {String|String[]} [options.url]    - The image resource url or many images.
             * @param {number} [options.width]           - The image(s) width.
             * @param {number} [options.height]          - The image(s) height.
             * @param {Object} [options.events]          - The available events.
             *
             * @param {Function} [options.events.onLoad]     - Called when an image is loaded properly.
             * @param {Function} [options.events.onError]    - Called when an image can not be loaded.
             * @param {Function} [options.events.onComplete] - Called when all images are loaded.
             *
             * @constructs Image
             * @memberof module:DS/UIKIT/Image
             */
            init: function (options) {
                this.setOptions(options);
                this.images = [];
                this.imageLoaded = 0;
            },

            /**
             * Load an image or many image.
             * @param {...String} - One or more image url.
             * @memberof module:DS/UIKIT/Image.Image#
             */
            load: function () {

                var that = this,
                    options = this.options,
                    cls = parseClassName(options.className);

                function handleEvent (name) {
                    return function () {

                        // We need to remove events else it gets fired twice
                        this.removeEvent('error');
                        this.removeEvent('load');

                        that.dispatchEvent(name, this);
                        if (!--that.imageLoaded) {
                            that.handleCompletion();
                        }
                    };
                }

                // Extract the number of images while creating the <tag> element
                [].slice.call(arguments).forEach(function (url) {
                    if (UWA.is(url, 'string')) {
                        var img = UWA.createElement('img', {
                            width: options.width,
                            height: options.height,
                            alt: url,
                            'class': cls
                        });

                        that.images.push(img);
                        that.imageLoaded++;
                    }
                });

                // Launch pre-loading of each image
                this.images.forEach(function (img) {
                    img.src = img.alt;
                    // Must add event after, else bugs
                    img.addEvents({
                        error: handleEvent('onError'),
                        load: handleEvent('onLoad')
                    });
                });
            },

            /**
             * Generic handler for completion.
             * @private
             * @memberof module:DS/UIKIT/Image.Image#
             */
            handleCompletion: function () {
                this.dispatchEvent('onComplete', [this.images]);
                this.images = [];
                this.imageLoaded = 0;
            }
        };

        return Class.extend(Options, Events, Image);
    });

/**
 * The abstract input class.
 * @module DS/UIKIT/Input
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Input',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Controls/Abstract'
    ],
    function (UWA, Element, Event, Client, Abstract) {

        'use strict';

        // Adding a Feature support
        Client.Features.inputPlaceholder = ('placeholder' in document.createElement('input'));

        /**
         * @lends module:DS/UIKIT/Input.Input#
         */
        var Input = {

            /**
             * @property {Object} defaultOptions - The default input options.
             * @private
             * @memberof module:DS/UIKIT/Input.Input#
             */
            defaultOptions: {
                className: '',
                attributes: {},
                value: '',
                name: '',
                disabled: false,
                commonClassName: 'form-control'
            },

            /**
             * If the input element is a native element or an emulated one.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Input.Input#
             */
            nativeInput: true,

            /**
             * Abstract class to build an input.
             *
             * @param {Object} options                         - Available options.
             * @param {String}  [options.className]            - An optional className to apply to the container.
             * @param {Object}  [options.attributes]           - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}  [options.value]                - The starting input value.
             * @param {String}  [options.id]                   - Sets the input id.
             * @param {String}  [options.name]                 - Sets the input name.
             * @param {Boolean} [options.disabled=false]       - Whether the input should be disabled from start.
             * @param {Object}  [options.events]               - The Available events.
             *
             * @param {Object}    [options.events.onChange]    - Invoked when the input value changes.
             * @param {Object}    [options.events.onClick]     - Invoked when the user click on the input.
             * @param {Object}    [options.events.onMouseDown] - Invoked when the user press the mouse button on the input.
             * @param {Object}    [options.events.onKeyDown]   - Invoked when the user press a key while focusing the input.
             *
             * @abstract
             * @constructs Input
             * @memberof module:DS/UIKIT/Input
             */
            init: function (options) {

                if (this.constructor === Input) {
                    throw new Error('Use a subclass of Input');
                }

                this._parent(options);

                this.events = null;

                // Build the DOM
                this.getContent();

                if (UWA.owns(options, 'name')) {
                    this.setName(options.name);
                }

                if (UWA.owns(options, 'value')) {
                    this.setValue(options.value);
                }

                if (this.elements.container && Client.Platform.ios) {
                    this.elements.container.classList.add('prevent-ios-zoom-in');
                }
            },

            /**
             * Returns the input content.
             * @returns {Element} - Control container.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            getContent: function () {
                if (!this.elements.container) {
                    this.buildSkeleton();
                    this.syncInput();
                }
                return this.elements.container;
            },

            /**
             * Builds the input skeleton.
             * @protected
             * @memberof module:DS/UIKIT/Input.Input#
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options;

                elements.input = this.buildInput().set(options.attributes);

                if (options.id) {
                    elements.input.id = options.id;
                }

                if (!this.nativeInput) {
                    elements.content = UWA.createElement('div', {
                        'class': this.getClassNames('-content')
                    });

                    elements.input.addClassName('hidden-input');

                    elements.container = UWA.createElement('div', {
                        html: [
                            elements.input,
                            elements.content
                        ]
                    });
                } else {
                    elements.content = elements.container = elements.input;
                }

                elements.container.addClassName(this.getClassNames());

                // This will call handleEvents
                this.setDisabled(options.disabled);
            },

            /**
             * Build the native input element.
             * @returns {Element} - The native input element
             * @memberof module:DS/UIKIT/Input.Input#
             * @protected
             */
            buildInput: function () {
                return UWA.createElement('input', { type: 'text' });
            },

            /**
             * Synchronize the control display with the native input state.
             */
            syncInput: function () {
                if (!this.nativeInput && this.elements.content) {
                    this.elements.content.setText(this.getValue());
                }
            },

            /**
             * Main function for handling events.
             * @memberof module:DS/UIKIT/Input.Input#
             * @protected
             */
            handleEvents: function () {

                var that = this,
                    elements = this.elements;

                function dispatch (event) {
                    return that.dispatchEvent.bind(that, event);
                }

                if (!this.events) {
                    this.events = {
                        container: {
                            click: dispatch('onClick'),
                            mousedown: dispatch('onMouseDown')
                        },
                        input: {
                            change: dispatch('onChange'),
                            keydown: dispatch('onKeyDown'),
                            focus: this.setFocus.bind(this, true),
                            blur: this.setFocus.bind(this, false)
                        }
                    };
                    // This event is necessary for languages which use IME (input method editors) in ff
                    // see https://www.w3.org/TR/uievents/#keys-IME
                    // or details https://techblog.open-xchange.com/2014/12/02/android-chrome-and-composition-events/
                    if (Client.Engine.firefox) {
                        // Use compositionend to make sure the input 2 byte char
                        // is done, then dispatch the normal onchange
                        this.events.input.compositionend = function (event) {
                            this.dispatchEvent('onChange', [event]);
                        }.bind(this);
                    }
                }

                if (this.isDisabled()) {
                    elements.container.removeEvents(this.events.container);
                    elements.input.removeEvents(this.events.input);
                } else {
                    // Only add state classes if it is a custom input
                    elements.container.addEvents(this.events.container);
                    elements.input.addEvents(this.events.input);
                }
            },

            /**
             * Set the focus on this input.
             * @param  {Boolean} [focus=true] - If falsy, will remove the focus.
             * @returns {Input}               - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            setFocus: function (focus) {

                var elements = this.elements;

                // Break early if touch
                if (!this.nativeInput && UWA.Utils.Client.Features.touchEvents) {
                    return this;
                }

                if (typeof focus === 'undefined') {
                    focus = true;
                }

                if (!this.nativeInput) {
                    elements.container.toggleClassName('focus', focus);
                }

                elements.input[focus ? 'focus' : 'blur']();

                return this;
            },

            /**
             * Alias to [setFocus(true)]{@link module:DS/UIKIT/Input.Input#setFocus}
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            focus: function () {
                return this.setFocus(true);
            },

            /**
             * Alias to [setFocus(false)]{@link module:DS/UIKIT/Input.Input#setFocus}
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            blur: function () {
                return this.setFocus(false);
            },

            /**
             * Set the input as disabled. Will remove events.
             * @param {Boolean} [disabled=true] - If false, enable the input.
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            setDisabled: function (disabled) {

                var elements = this.elements;

                if (typeof disabled === 'undefined') {
                    disabled = true;
                }

                elements.input.disabled = disabled;
                elements.container.toggleClassName('disabled', disabled);
                this.handleEvents();
                return this;
            },

            /**
             * Get if this input is disabled.
             * @returns {Boolean} - The disabled state of the input
             * @memberof module:DS/UIKIT/Input.Input#
             */
            isDisabled: function () {
                return !!this.elements.input.disabled;
            },

            /**
             * Shorthand for [setDisabled(false)]{@link module:DS/UIKIT/Input.Input#setDisabled}.
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            enable: function () {
                return this.setDisabled(false);
            },

            /**
             * Shorthand for [setDisabled()]{@link module:DS/UIKIT/Input.Input#setDisabled}.
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            disable: function () {
                return this.setDisabled();
            },

            /**
             * Set the input name attribute.
             * @param {String} name - The input new name.
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            setName: function (name) {
                if (UWA.is(name, 'string')) {
                    this.elements.input.name = name;
                }
                return this;
            },

            /**
             * Get the input name.
             * @returns {String} - The input name.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            getName: function () {
                return this.elements.input.name;
            },

            /**
             * Set the input id attribute.
             * @param {String} id - The input new id.
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            setId: function (id) {
                if (UWA.is(id, 'string')) {
                    this.elements.input.id = id;
                }
                return this;
            },

            /**
             * Get the input id.
             * @returns {String} - The input id.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            getId: function () {
                return this.elements.input.id;
            },

            /**
             * Set the input value.
             * @param {String} value - The new value.
             * @returns {Input} - The instance.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            setValue: function (value) {

                var input = this.elements.input,
                    tag =  input.getTagName();

                if (tag === 'input' || tag === 'textarea') {
                    input.value = value;
                } else {
                    input.setText(value);
                }

                this.syncInput();
                return this;
            },

            /**
             * Get the input value.
             * @returns {String} - The input value.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            getValue: function () {

                var input = this.elements.input,
                    tag = input.getTagName();

                return tag === 'input' || tag === 'textarea' ? input.value : input.getText();
            },

            /**
             * On mouse down default handler.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            onMouseDown: function (e) {
                // If client is touch do not focus, else it will pop native UI
                if (!this.nativeInput && !this.isDisabled()) {
                    Event.preventDefault(e);
                    this.focus();
                }
            },

            /**
             * On change handler.
             * @memberof module:DS/UIKIT/Input.Input#
             */
            onChange: function (e) {
                this.syncInput();
                this.bubbleOnChange(e);
            },

            /**
             * Dispatch the 'change' event in the input. Used internally to fire
             * the event when the native input is driven by the control.
             * @protected
             * @memberof module:DS/UIKIT/Input.Input#
             */
            dispatchOnChange: function () {
                Event.dispatchEvent(this.elements.input, 'change');
            },

            /**
             * Custom bubbling.
             * @method
             * @memberof module:DS/UIKIT/Input.Input#
             * @protected
             */
            bubbleOnChange: (function () {
                var bubbleOnChange;

                function getBubbleOnChange () {
                    if (bubbleOnChange === undefined) {
                        bubbleOnChange = false;

                        var container = document.createElement('div'),
                            input = document.createElement('input');

                        input.type = 'text';
                        container.appendChild(input);

                        // In order to dispatch an event, the input has to be in
                        // the dom (IE8)
                        container.style.display = 'none';
                        document.body.appendChild(container);

                        Element.addEvent.call(container, 'change', function (e) {
                            bubbleOnChange = true;
                            Event.stop(e);
                        });
                        Event.dispatchEvent(input, 'change');

                        Element.remove.call(container);
                        Element.removeEvents.call(container);
                    }
                    return bubbleOnChange;
                }

                return function (e) {
                    var eventHandler,
                        element = this.elements.input.parentNode;
                    if (!getBubbleOnChange()) {
                        // While we have a parent and the propagation has not been stopped
                        while (element && element.nodeType === 1 && (e.event || e).returnValue !== false) {
                            eventHandler = element._events && element._events.change;
                            if (eventHandler) {
                                eventHandler.handleEvent(e);
                            }
                            element = element.parentNode;
                        }
                    }
                };
            }())
        };

        return Abstract.extend(Input);
    });

/**
 * Display a small and adaptive label for a content
 * @module DS/UIKIT/Badge
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Badge',
    [
        'UWA/Core',
        'UWA/Controls/Abstract',
        'UWA/Event'
    ],
    function (UWA, Abstract) {

        'use strict';

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) { return; }
            klasses = klasses.split(' ');

            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/default|primary|info|warning|error|success$/);
                if (match && !match[1]) {
                    klasses[i] = 'badge-' + klasses[i];
                }
            }
            return klasses.join(' ');
        }

        function addEvent (evnt, elem, func, capture) {
            if (elem.addEventListener)  // W3C DOM
                elem.addEventListener(evnt, func, capture);
            else if (elem.attachEvent) { // IE DOM
                elem.attachEvent('on' + evnt, func, capture);
            }
        }

        function removeEvent (evnt, elem, func) {
            if (elem.removeEventListener) { // W3C DOM
                elem.removeEventListener(evnt, func, false);
            } else if (elem.detachEvent) {  // IE DOM
                elem.detachEvent('on' + evnt, func);
            }
        }

        /**
         * @lends module:DS/UIKIT/Badge.Badge#
         */
        var Badge = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component classname.
             * Component variations classname prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            name: 'badge',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            defaultOptions: {
                className: 'badge-default',
                closable: false,
                selectable: false,
                disabled: false
            },

            /**
             * Display a small and adaptive label for a content
             *
             * @example
             *
             * require(['DS/UIKIT/Badge'], function (Badge) {
             *   new Badge({ content: "Primary", className: "primary", icon: 'badge-alt' }).inject(body);
             * });
             *
             * @param {Object}   options                    - The available options.
             *
             * @param {String}   options.content            - String content to display.
             * @param {String}   [options.id]               - An optional id.
             * @param {String}   [options.name]             - An optional name.
             * @param {Boolean}  [options.closable=false]   - True to display a closing cross on the right.
             * @param {Boolean}  [options.selectable=false] - True to make the badge selectable (add slight border variations on hover and click).
             * @param {String}   [options.className]        - An optional className to apply to the container.
             *                                                Existing variations to use : `primary`, `info`, `warning`, `error`, `success`).
             * @param {String}   [options.icon]             - The Badge icon image className. Will get prefixed by `fonticon` whatsoever.
             * @param {Boolean}  [options.disabled=false]   - Whether the Badge should be disabled from start or not.
             *
             * @param {Object}   [options.events]           - The available events.
             *
             * @param {Function} [options.events.onClick]   - An event dispatched when clicking inside the badge. Returns the event and this instance.
             * @param {Function} [options.events.onClose]   - An event dispatched when clicking the closing cross. Returns the event and this instance.
             *
             * @constructs Badge
             * @memberof module:DS/UIKIT/Badge
             */
            init: function (options) {
                options = options || {};

                if (options.className) {
                    options.className = parseClassName(options.className);
                }

                this._parent(options);
                this.buildSkeleton();
            },

            /**
             * Build HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            buildSkeleton: function () {
                var elements = this.elements,
                    options = this.options;

                // Safe check if user called buildSkeleton directly
                if (elements.container) { return; }

                // Build container
                elements.container = UWA.createElement('span', {
                    'class': this.getClassNames()
                });

                if (options.id) { elements.container.id = options.id; }
                if (options.name) { elements.container.name = options.name; }
                this.setSelectable(options.selectable);
                this.setClosable(options.closable);

                elements.content = UWA.createElement('span', { 'class': this.name + '-content' }).inject(elements.container);
                elements.content.setText(options.content);
                elements.cross = UWA.createElement('span', { 'class': 'fonticon fonticon-cancel' }).inject(elements.container);
                options.icon && this.setIcon(this.options.icon);

                // Will call handleEvents()
                this.setDisabled(options.disabled);
            },

            /**
             * Set the badge icon using a font face icon.
             * @example
             * var badge = new Badge({...});
             * badge.setIcon('star')
             * // => `<span class = "fonticon fonticon-star"></span>`
             * @param  {String} klasses - The icon class name.
             * @returns {Badge}         - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            setIcon: function (klasses) {
                var elements = this.elements;

                klasses = klasses.split(' ');

                for (var index = 0, length = klasses.length; index < length; index++) {
                    if (!klasses[index].match('fonticon-')) {
                        klasses[index] = 'fonticon-' + klasses[index];
                    }
                }

                klasses = klasses.join(' ');

                // Create the icon element or change the class
                if (!elements.icon) {
                    elements.icon = UWA.createElement('span', {
                        'class': 'fonticon ' + klasses + ' ' + this.name + '-icon'
                    }).inject(elements.container, 'top');
                } else {
                    elements.icon.className = 'fonticon ' + klasses + ' ' + this.name + '-icon';
                }

                return this;
            },

            /**
             * Remove the icon.
             * @returns {Badge} - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            removeIcon: function () {
                if (this.elements.icon) {
                    this.elements.icon.destroy();
                }
                return this;
            },

            /**
             * Set the selection on this badge (if selectable).
             * @param  {Boolean} [select=true] - True to select, false to unselect.
             * @returns {Badge}                - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            select: function (select) {
                if (this.isDisabled()) { return; }
                if (!UWA.is(select)) { select = true; }
                if (select) {
                    this.elements.container.addClassName(this.name + '-selected');
                } else {
                    this.elements.container.removeClassName(this.name + '-selected');
                }
            },

            /**
             * Returns true if the badge is currently selected, else false.
             * @returns {Boolean} - The Badge selected state
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            isSelected: function () {
                return this.elements.container.hasClassName(this.name + '-selected');
            },

            /**
             * Set the className for this Badge.
             *
             * @param  {String} klass - A list of classes or a single class.
             * @returns {Badge}       - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            setClassName: function (klass) {
                this.options.className = parseClassName(klass);
                this.getContent().className = this.getClassNames();
                return this;
            },

            /**
             * Make the badge selectable or not
             *
             * @param {Boolean} [selectable=false] - True to make the badge selectable
             * @returns {Badge}                    - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            setSelectable: function (selectable) {
                if (typeof selectable === 'undefined') { selectable = false; }
                this.options.selectable = selectable;
                this.elements.container.toggleClassName(this.name + '-selectable', selectable);
                return this;
            },

            /**
             * Make badge cross visible or not.
             *
             * @param {Boolean} [closable=false] - True to show badge cross.
             * @returns {Badge}                  - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            setClosable: function (closable) {
                if (typeof closable === 'undefined') { closable = false; }
                this.options.closable = closable;
                this.elements.container.toggleClassName(this.name + '-closable', closable);
                return this;
            },

            /**
             * Main method for handling events.
             * @memberof module:DS/UIKIT/Badge.Badge#
             * @private
             */
            handleEvents: function () {
                var elements = this.elements,
                    options = this.options,
                    that = this;

                if (!this.events) {
                    this.events = {};
                    this.events.container = {
                        click: function (event) {
                            var target = UWA.Event.getElement(event);
                            if (!/fonticon-cancel/.test(target.className)) {
                                options.selectable && !that.isDisabled() && elements.container.addClassName(that.name + '-selected');
                                that.dispatchEvent('onClick', [event, that]);
                            }
                        }
                    };

                    this.events.cross = {
                        click: function (event) {
                            options.closable && that.dispatchEvent('onClose', [event, that]);
                        }
                    };

                    this.events.document = {
                        click: function (event) {
                            if (!UWA.Event.getElement(event).isInjected(that.elements.container)) {
                                options.selectable && !that.isDisabled() && elements.container.removeClassName(that.name + '-selected');
                                that.dispatchEvent('onClickOutside', [event, that]);
                            }
                        }
                    };
                }

                if (this.isDisabled()) {
                    elements.container.removeEvents(this.events.container);
                    elements.cross.removeEvents(this.events.cross);
                    removeEvent('click', document, this.events.document.click);
                } else {
                    elements.container.addEvents(this.events.container);
                    elements.cross.addEvents(this.events.cross);
                    addEvent('click', document, this.events.document.click, true);
                }
            },

            /**
             * Destroy the badge.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            destroy: function () {
                this.options.selectable && removeEvent('click', document, this.events.document.click, true);
                this._parent();
            },

            /**
             * Shorthand for setDisabled(false)
             * @return {Badge} - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            enable: function () {
                return this.setDisabled(false);
            },

            /**
             * Shorthand for setDisabled()
             * @return {Badge} - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            disable: function () {
                return this.setDisabled();
            },

            /**
             * Enable/disable the badge for clicking / selection.
             *
             * @param  {Boolean} [disabled=true] - Disable on `true`, enable on `false`.
             * @returns {Badge}                  - The instance.
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            setDisabled: function (disabled) {
                var elements = this.elements;

                if (typeof disabled === 'undefined') {
                    disabled = true;
                }

                elements.container.disabled = disabled;
                elements.container.toggleClassName('disabled', disabled);
                this.handleEvents();

                return this;
            },

            /**
             * Return true if the badge is disabled.
             * @returns {Boolean}
             * @memberof module:DS/UIKIT/Badge.Badge#
             */
            isDisabled: function () {
                return this.elements.container.disabled;
            }
        };

        return Abstract.extend(Badge);
    });

/**
 * Displays horizontal and/or vertical bars on the right and/or on the bottom of an element in order to move its content up and down and/or left and right.
 * @module DS/UIKIT/Scroller
 */

define('DS/UIKIT/Scroller', [
    'UWA/Core',
    'UWA/Utils',
    'UWA/Utils/Client',
    'UWA/Controls/Abstract',
    'UWA/Controls/Drag',
    'UWA/Class/Timed'

], function (UWA, Utils, Client, ControlsAbstract, Drag, Timed) {

    'use strict';

    /**
     * Gets the event position relative to the client screen.
     *
     * @param {DOMEvent} event
     * @returns {Object} a hash with coordinates stored in x/y properties
     */
    function domEventPosition (event) {
        if (event.event) {
            event = event.event;
        }
        var positions = event.changedTouches || event.touches || [event];
        var result = { x: 0, y: 0 };
        var l = positions.length;
        var i;
        for (i = 0; i < l; i++) {
            result.x += positions[i].clientX / l;
            result.y += positions[i].clientY / l;
        }
        return result;
    }

    /* Base data for each scroll direction */
    var baseInfos = {
        delta: 0,
        coef: 1,
        active: false,
        visible: false,
        scrollSize: 0,
        scrollPosition: 0,
        offsetSize: 0
    };

    /**
     * @lends module:DS/UIKIT/Scroller.DragScrollBar#
     */
    var DragScrollBar = Drag.extend({

        defaultOptions: {
            snap: 0,
            delay: 0
        },

        /**
         * @constructs DragScrollBar
         */
        init: function (scroller, options) {
            this._parent(options);
            this.scroller = scroller;
            this.direction = this.element.className.contains('scrollbar-y') ? 'y' : 'x';
            this.infos = scroller._infos[this.direction];

        },

        /*
         * Gets the position of the mouse relative to the scroll bar
         * @private
         * @memberof module:DS/UIKIT/Scroller.DragScrollBar#
         */
        _getPosition: function () {
            var scrollbarPosition = this.element.getBoundingClientRect()[this.direction === 'y' ? 'top' : 'left'];
            return domEventPosition(this.currentEvent)[this.direction] - scrollbarPosition;
        },

        /**
         * Start hook
         * @memberof module:DS/UIKIT/Scroller.DragScrollBar#
         */
        start: function (position) {
            this._parent(position);
            this.infos.active = true;
            this.scroller.update();
            // Store the initial position
            this.position = this._getPosition();
        },

        /**
         * Move hook
         * @memberof module:DS/UIKIT/Scroller.DragScrollBar#
         */
        move: function (position, delta) {
            this._parent(position, delta);
            // Update the scroll
            this.infos.delta = (this._getPosition() - this.position) * this.infos.coef;
            this.infos.active = true;
            this.scroller.updateVisible();
        },

        /**
         * Stop hook
         * @memberof module:DS/UIKIT/Scroller.DragScrollBar#
         */
        stop: function () {
            this._parent();
            this.scroller.updateActive(this.currentEvent);
        }
    });

    /**
     * @lends module:DS/UIKIT/Scroller.Scroller#
     */
    var Scroller = ControlsAbstract.extend(Timed, {
        /**
         * Component name used by `Abstract.getClassNames`.
         * Component class name.
         * Component variations class name prefix.
         * @type {String}
         * @readonly
         * @default
         * @constant
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        name: 'scroller',

        /**
         * @property {Object} - The options
         * @private
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        options: {
            element: null,
            scrollbars: 'auto',
            scrollbarsMargin: 4,
            scrollbarsMinSize: 50
        },

        /**
         * Displays horizontal and/or vertical bars on the right and/or on the bottom of an element in order to move its content up and down and/or left and right.
         *
         * @example
         *
         * <style type="text/css">
         *      #scroll { overflow: auto; height: 300px; width: 300px; margin: 0 auto;white-space: pre; font-size: 20px; line-height: 1.2em; border: 1px solid black; }
         * </style>
         * var scroll = Element.getElement.call(document, '#scroll');
         * var containerScroll = Element.getElement.call(document, '#container-scroll');
         * new Scroller({
         *     element: scroll
         * }).inject(containerScroll);
         *
         * @param {Object}  [options]                           - The available options.
         * @param {DOMElement}  [options.element]               - An existing element to use instead of creating a new one
         * @param {number}      [options.scrollbarsMargin=4]    - Space (in px) to leave before and after scrollbars
         * @param {number}      [options.scrollbarsMinSize=50]  - Minimum size (in px) of scrollbars
         *
         *
         * @constructs Scroller
         * @memberof module:DS/UIKIT/Scroller
         */
        init: function (options) {
            if (UWA.is(options) && UWA.is(options.element)) {
                UWA.extendElement(options.element);
            }

            this._parent(options);

            this._elementEvents = {
                mousemove: this.updateActive.bind(this),
                mouseout: this.updateActive.bind(this)
            };

            this.build();
            this.initInfos();
        },

        /**
         * Setup of the init state of the scroller
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        initInfos: function () {
            this._infos = {
                x: Object.create(baseInfos),
                y: Object.create(baseInfos)
            };
            this.setPeriodical('update', this.update, 1000);
            this.updateShift();
            this.update();
        },

        /**
         * Destroy the scroller
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        destroy: function () {
            
            this.clearAnimate('update');
            this.clearPeriodical('update');

            if (this.options.element) {
                var container = this.elements.container;
                container
                    .removeEvents(this._elementEvents)
                    .removeClassName(this.getClassNames())
                    .setContent(this.elements.content.childNodes);
                var oldDestroy = container.destroy;
                container.destroy = function () {}; // don't destroy the container
                this._parent();
                container.destroy = oldDestroy;
            } else {
                this._parent();
            }
        },

        /**
         * PostInject hook
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        onPostInjected: function () {
            this.initInfos();
        },

        /**
         * Initialize the wrapper, bind the events
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        build: function () {

            var container = this.options.element || UWA.createElement('div');
            container
                .addClassName(this.getClassNames())
                .addEvents(this._elementEvents);

            var extraClass = this.options.scrollbars === 'native' ? 'native-scrollbars ' : 'no-native-scrollbars ';

            var content = UWA.createElement('div', {
                'class': extraClass + this.getClassNames('-content'),
                events: {
                    scroll: this.updateVisible.bind(this)
                },
                html: [].slice.call(container.childNodes)
            }).inject(container);

            this.setDelayed('hide-overflow', function () {
                /* We have to set the overflow to hidden asynchronously, because
                 * of a nasty bug in Firefox.
                 */
                container.setStyle('overflow', 'hidden');
            }, 0);

            this.elements.container = container;
            this.elements.content = content;
        },

        /**
         * Get the inner element. Use this if you want to access the content of
         * the scroller.
         *
         * @returns {HTMLElement} the inner element
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        getInnerElement: function () {
            return this.elements.content;
        },

        /**
         * Get the scroll   bar for one direction. Optionally, the scrollbar is built if it does not exist yet.
         *
         * @param {String}  dir               - 'x' or 'y'
         * @param {Boolean} [create=false]    - Create the scrollbar if it does not exist
         * @returns {HTMLElement|undefined} - The scrollbar element or undefined if it does not exist yet.
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        getScrollbar: function (dir, create) {
            var scrollbar = this.elements[dir + 'Scrollbar'];
            if (!scrollbar && create) {
                scrollbar = this.elements[dir + 'Scrollbar'] = UWA.createElement('div', {
                    'class': this.getClassNames('-scrollbar', '-scrollbar-' + dir)
                }).inject(this.elements.container);
                new DragScrollBar(this, {
                    element: scrollbar,
                    root: this.elements.container
                });
                // force redraw layout, needed for css transition
                scrollbar.clientHeight; // jshint ignore:line
            }
            return scrollbar;
        },

        /**
         * Scroll to the provided element.
         *
         * @param  {String|Element} element     - The element itself or a CSS selector
         * @param  {String} [position='top']    - Put the element at the given position : 'top', 'center' or 'bottom'. Default to 'top'
         * @param  {number} [duration=0]        - Transition duration in milliseconds
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        scrollToElement: function (element, position, duration) {

            var offsetLeft, offsetTop;

            // Can be the element itself or just an id / class..
            if (!element.nodeType) {
                element = this.elements.container.getElement(element);
            }

            // Stop if the element cannot be retrieve
            if (!element) { return; }

            offsetLeft = element.offsetLeft;
            offsetTop = element.offsetTop;

            if (position === 'center') {
                offsetTop = offsetTop - (this.elements.content.getDimensions().height / 2) + (element.getDimensions().height / 2);
            }

            if (position === 'bottom') {
                offsetTop = offsetTop - this.elements.content.getDimensions().height + element.getDimensions().height;
            }

            this.scrollTo(offsetLeft, offsetTop, duration);

        },

        /**
         * Scroll to the provided coordinates.
         *
         * @param {number} x                    - Target on X axis
         * @param {number} y                    - Target on Y axis
         * @param {number} [duration=0]         - Transition duration in milliseconds
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         */
        scrollTo: function (x, y, duration) {

            var that = this, scrollRight, scrollDown, scrollStepX, scrollStepY, remainingX, remainingY, scrollXInterval, scrollYInterval, steps = 100;

            if (isNaN(x) || isNaN(y)) { return; }

            if (duration && !isNaN(duration) && duration > 0) {

                scrollDown = y > that.elements.content.scrollTop;
                scrollRight = x > that.elements.content.scrollLeft;

                remainingY = (scrollDown) ? (y - that.elements.content.scrollTop) : (that.elements.content.scrollTop - y);
                remainingX = (scrollRight) ? (x - that.elements.content.scrollLeft) : (that.elements.content.scrollLeft - x);

                scrollStepX = Math.ceil(remainingX / steps);
                scrollStepY = Math.ceil(remainingY / steps);

                // Go to the expected position starting from current position, one step by (duration / steps) milliseconds. Steps arbitrary chosen.
                scrollYInterval = (scrollStepY > 0) && setInterval(function () {
                    // Scroll a step forward
                    if (remainingY > 0) {
                        that.elements.content.scrollTop += (scrollDown) ? (scrollStepY) : (-scrollStepY);
                        remainingY -= scrollStepY;
                    } else {
                        // Deduce what remains (if necessary)
                        if (scrollDown) {
                            that.elements.content.scrollTop += remainingY;
                        } else {
                            that.elements.content.scrollTop -= remainingY;
                        }
                        // Finished
                        clearInterval(scrollYInterval);
                    }
                }, duration / steps);

                scrollXInterval = (scrollStepX > 0) && setInterval(function () {
                    // Scroll a step forward
                    if (remainingX > 0) {
                        that.elements.content.scrollLeft += (scrollRight) ? (scrollStepX) : (-scrollStepX);
                        remainingX -= scrollStepX;
                    } else {
                        // Deduce what remains (if necessary)
                        if (scrollRight) {
                            that.elements.content.scrollLeft += remainingX;
                        } else {
                            that.elements.content.scrollLeft -= remainingX;
                        }
                        // Finished
                        clearInterval(scrollXInterval);
                    }

                }, duration / steps);

            } else {

                this.elements.content.scrollLeft = x;
                this.elements.content.scrollTop = y;
            }

        },

        /**
         * Update the active scrollbars according to the current pointer
         * position. This will call `updateVisible` in order to update the
         * rendering.
         *
         * @param {DOMEvent} event the mouse or touch event to use to know
         * the position of the pointer.
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        updateActive: function (event) {
            this.updateShift();
            if (this.options.scrollbars !== 'virtual') {
                return;
            }

            function between (a, b, c) {
                return a < b && b < c;
            }
            if (event.type === 'mouseout' || event.type === 'touchend') {
                this._infos.x.active = this._infos.y.active = false;
            } else {
                var rect = this.elements.container.getBoundingClientRect();
                var zoneWidth = 12;
                var position = domEventPosition(event);
                ['x', 'y'].forEach(function (dir, y) {
                    var limit = rect[y ? 'right' : 'bottom'];
                    this._infos[dir].active = between(limit - zoneWidth, position[y ? 'x' : 'y'], limit) &&
                        between(rect[y ? 'top' : 'left'], position[dir], rect[y ? 'bottom' : 'right']);
                }, this);
            }
            this.updateVisible();
        },

        /**
         * Set the scrollbars visible for one second. This will call `update`
         * in order to update the rendering.
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        updateVisible: function () {
            this._infos.x.visible = this._infos.y.visible = true;
            this.setDelayed('scrollbars-visible', function () {
                this._infos.x.visible = this._infos.y.visible = false;
                this.update();
            }, 1000);
            this.update();
        },

        /**
         * Update the scrollbar shift
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        updateShift: function () {
            var content = this.elements.content;
            if (this._shift === undefined && content.isInjected()) {
                var scrollbars = this.options.scrollbars;
                if (scrollbars === 'auto') {
                    /* Disable virtual scrollbars in iOS by default, because when
                     * used with `-webkit-overflow-scrolling: touch;` in order to
                     * use momentum and bouncing, the 'scroll' event is not
                     * triggered until the scroll stops, so the rendering of the
                     * scrollbars is slow.
                     *
                     * Disable virtual scrollbars on Firefox if the scrollbar
                     * width is zero (mostly on MacOS for now), because we
                     * can't hide scrollbars on Firefox.
                     *
                     * Warning: chrome/MacOS with hidden native scrollbars does
                     * not apply the ::--webkit-scrollbar styles if the
                     * scrollbars were already displayed. Make sure scrollbars
                     * are hidden before determining the type of auto
                     * scrollbars.
                     */
                    if (Client.Platform.ios) {
                        scrollbars = 'native';
                        content.removeClassName('no-native-scrollbars').addClassName('native-scrollbars');
                    } else {
                        scrollbars = 'virtual';
                    }
                    this.options.scrollbars = scrollbars;
                }
                if (scrollbars === 'virtual') {
                    var shift = content.offsetWidth - content.clientWidth;
                    if (shift > 0 && shift < 30) {
                        // quick and dirty way to check if the shift has an reasonable value
                        this._shift = shift;
                        content.setStyles({
                            right: -this._shift,
                            bottom: -this._shift
                        });
                    } else if (Client.Engine.firefox) {
                        // Being tricky to hide FF scrollbar
                        this._shift = 16;
                        content.setStyles({
                            right: -this._shift,
                            bottom: -this._shift,
                            'padding-right': this._shift,
                            'padding-bottom': this._shift
                        });
                    }
                } else {
                    this._shift = 0;
                }

            }
        },

        /**
         * Access to the DOM to read the sizes needed for the `_write` method.
         *
         * @param {Boolean} y true if this is the 'y' direction
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        _read: function (y) {
            var infos = this._infos[y ? 'y' : 'x'];
            var content = this.elements.content;
            infos.scrollSize = content[y ? 'scrollHeight' : 'scrollWidth'];
            infos.scrollPosition = content[y ? 'scrollTop' : 'scrollLeft'] + infos.delta;
            infos.offsetSize = content[y ? 'offsetHeight' : 'offsetWidth'] - (this._shift || 0);

            if (infos.scrollPosition < 0) {
                infos.scrollPosition = 0;
            } else if (infos.scrollPosition > infos.scrollSize - infos.offsetSize) {
                infos.scrollPosition = infos.scrollSize - infos.offsetSize;
            }
        },

        /**
         * Update the DOM according to the current scroller state (data gathered by `_write` and other methods).
         *
         * @param {Boolean} y true if this is the 'y' direction
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        _write: function (y) {
            var dir = y ? 'y' : 'x',
                infos = this._infos[dir],
                options = this.options;

            if (infos.delta) {
                this.elements.content[y ? 'scrollTop' : 'scrollLeft'] = infos.scrollPosition;
                infos.delta = 0;
            }

            if (this.options.scrollbars === 'virtual') {
                // prevent virtual scrollbars from showing in FF when there is no need to scroll.
                var scroll = infos.scrollSize > (infos.offsetSize + (Client.Engine.firefox ? this._shift : 0));
                var scrollbar = this.getScrollbar(dir, scroll);

                if (scroll && infos.scrollSize) {
                    var totalSize = infos.offsetSize - 2 * options.scrollbarsMargin;
                    var size = (totalSize * (infos.offsetSize / infos.scrollSize));
                    if (size < options.scrollbarsMinSize) {
                        size = options.scrollbarsMinSize;
                    }

                    infos.coef = (infos.scrollSize - infos.offsetSize) / (totalSize - size);
                    scrollbar.style[y ? 'top' : 'left'] = (options.scrollbarsMargin + infos.scrollPosition / infos.coef) + 'px';
                    scrollbar.style[y ? 'height' : 'width'] = size + 'px';
                    scrollbar
                        .toggleClassName('active', infos.active)
                        .toggleClassName('visible', infos.visible);
                } else if (scrollbar) {
                    scrollbar.removeClassName('active').removeClassName('visible');
                }
            }
        },

        /**
         * Update the scroller rendering. This method is debounced using a
         * requestAnimationFrame and won't change anything if the direction
         * data did not change since the last call.
         * @memberof module:DS/UIKIT/Scroller.Scroller#
         * @private
         */
        update: function () {
            this.setAnimate('update', function () {
                this.updateShift();
                this._read(false);
                this._read(true);
                if (!UWA.equals(this._previousInfos, this._infos)) {
                    // Separate reads from writes to avoid unnecessary repaint
                    this._write(false);
                    this._write(true);
                    this._previousInfos = UWA.clone(this._infos);
                }
            });
        }
    });

    return ControlsAbstract.extend(Scroller);
});

/**
 * A slideshow component for cycling through elements.
 * A Carousel, or slideshow, is a component in charge of showing a list of images/content to the user.
 * The user can the click on the control to change the visible element.
 * @module DS/UIKIT/Carousel
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Carousel',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Controls/Abstract'
    ],


    function (UWA, Element, Event, Utils, Abstract) {

        'use strict';

        /* Small $() like content creation in memory "a la jquery" */
        function $ (html) {
            return UWA.extendElement(UWA.createElement('div').setContent(html).firstChild);
        }

        /**
         * @lends module:DS/UIKIT/Carousel.Carousel#
         */
        var Carousel = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component classname.
             * Component variations classname prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            name: 'carousel',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            defaultOptions: {
                className: '',
                autoPlay: true,
                infinite: true,
                dots: true,
                arrows: true,
                pauseOnHover: false,
                animation: 'slide',
                slideSelector: '> div',
                slideSpeed: 200,
                autoPlaySpeed: 5000,
                slideToShow: 1,
                slidesToScroll: 1
            },

            /**
             * A helper to the current slide. Avoid modifying it directly.
             * @type {Object}
             * @readonly
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            current: null,

            /**
             * A helper to all the slides. Avoid modifying them directly.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            slides: null,

            /**
             * A slideshow component for cycling through elements.
             *
             * @param {Object | Element[]} options              - You can either pass the slides directly or an object with more options.
             *
             * @param {String}  [options.className]             - An optional css class name that you can use for customizing the component easily.
             * @param {Element|Element[]} [options.slides]      - Either an Element already injected in the DOM containing your slides
             *                                                    or an array of Elements/HTML strings representing your slides.
             * @param {String}  [options.slideSelector='> div'] - A css selector. Will be used to find the slides in your `options.slides`.
             *                                                    This option is not used if `options.slides` is an array of Elements.
             * @param {Element} [options.renderTo]              - If specified will inject the Carousel inside the passed Element.
             *                                                    If not will have to be injected manually.
             * @param {Boolean} [options.autoPlay=true]         - Whether the slider should start to slide automatically.
             * @param {Boolean} [options.infinite=true]         - Whether the slider should loop when reaching the last slide.
             * @param {Boolean} [options.dots=true]             - Whether the slider should have a location indicator at the bottom.
             * @param {Boolean} [options.arrows=true]           - Whether the slider should have some arrows for controlling the sliding.
             * @param {Boolean} [options.pauseOnHover=false]    - If specified will pause any auto play on mouse hover.
             * @param {String}  [options.animation='slide']     - The slide animation type eg. `slide` or `fade`.
             * @param {Integer} [options.autoPlaySpeed=5000]    - The auto play sliding speed.
             * @param {Integer} [options.slideSpeed=200]        - The sliding animation speed.
             * @param {Integer} [options.slideToShow=1]         - Number of slide to be displayed as visible.
             * @param {Integer} [options.slidesToScroll=1]      - Number of slide to scroll when clicked.
             * @param {Object}  [options.events]                - The available events.
             *
             * @param {Function} [options.events.onSlide]       - Invoked when finishing a sliding motion.
             * @param {Function} [options.events.onLoop]        - Invoked when looping the carousel.
             * @param {Function} [options.events.onAddSlide]    - Invoked when adding a new slide.
             * @param {Function} [options.events.onRemoveSlide] - Invoked when removing a slide.
             *
             * @constructs Carousel
             * @memberof module:DS/UIKIT/Carousel
             */
            init: function (options) {

                options = options || {};

                // In case the slides were passed directly
                if (!UWA.is(options, 'object')) {
                    options = { slides: options };
                }

                this._parent(options);
                this.slides = [];
                this.buildSkeleton();

                // Handle renderTo option
                if (UWA.is(options.renderTo, 'element')) {
                    this.inject(UWA.extendElement(options.renderTo));
                    delete this.options.renderTo;
                }

                if (this.options.autoPlay) {
                    this.play();
                }
            },

            /**
             * Build the HTML skeleton for the carousel.
             * @example
             * <div container class="carousel">
             *     <ol dots class="carousel-indicators">
             *     <div content class="carousel-slides">
             *         <slide class="slide">
             *     <a arrowLeft class="left carousel-control">
             *     <a arrowRight class="right carousel-control">
             *
             * @private
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            buildSkeleton: function () {

                var that = this,
                    options = this.options,
                    isElement = UWA.is(options.slides, 'element'),
                    elements = this.elements,
                    slides, parent;

                /** Pause the autoPlay before sliding. This avoid avoid two slides one after the other. */
                function slide (index, event) {
                    // Prevent text selection
                    Event.preventDefault(event);

                    if (that.autoplayTimer) {
                        that.pause();
                        that.addEventOnce('onSlide', that.play.bind(that));
                    }
                    that.slide(index);
                }

                // Return early if container already built
                if (elements.container) return;

                elements.container = UWA.createElement('div', {
                    'class': this.name + ' ' + options.className
                });

                if (isElement) {
                    // If `options.slides` is a DOM element use it as our content
                    elements.content = UWA.extendElement(options.slides);
                    slides = this.getSlides();
                } else {
                    // We need to build the content
                    elements.content = UWA.createElement('div');
                    if (UWA.is(options.slides, 'array')) {
                        slides = options.slides;
                    }
                }

                // Add class once we have a proper content
                elements.content.addClassName(this.name + '-slides');

                // Handles the dots indicators at the bottom
                if (options.dots) {
                    elements.dots = UWA.createElement('ol', {
                        'class': this.name + '-indicators'
                    }).inject(elements.container);

                    elements.dots.addEvent('mousedown', function (event) {
                        var index, target = Event.getElement(event);

                        if (target.hasClassName('indicator')) {
                            index = elements.dots.getChildren().indexOf(target);
                            slide(index, event);
                        }
                    });
                }


                // Add the slides to the content
                slides && this.add(slides);

                // If the `options.slides is already injected, we need to add the container before it
                if (isElement && elements.content.isInjected()) {
                    parent = elements.content.getParent();
                    if (parent) {
                        elements.content.inject(elements.container);
                        elements.container.inject(parent);
                    }
                } else {
                    elements.content.inject(elements.container);
                }

                // Handles the arrow on each side
                if (options.arrows) {
                    elements.arrowLeft = UWA.createElement('a', {
                        'class': 'left ' + this.name + '-control',
                        html: '<span class ="fonticon fonticon-left-open"></span>'
                    }).inject(elements.container);

                    elements.arrowRight = UWA.createElement('a', {
                        'class': 'right ' + this.name + '-control',
                        html: '<span class ="fonticon fonticon-right-open"></span>'
                    }).inject(elements.container);

                    elements.arrowRight.addEvent('mousedown', function (e) { slide('right', e); });
                    elements.arrowLeft.addEvent('mousedown', function (e) { slide('left', e); });
                }

                delete options.slides;
            },

            /**
             * Return the slides.
             * @returns {Element[]} - Slide elements.
             * @private
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            getSlides: function () {
                return this.elements.content.getElements(this.options.slideSelector);
            },

            /**
             * Add one or many slide(s).
             * @param {Object[]|Element|String} options - The slide(s) to add. Can be an HTML string, an Element or an array of Elements.
             * @returns {Carousel}                      - The instance
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            add: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that.addSlide(option);
                });

                if (!this.current) {
                    this.setActive(0);
                }

                return this;
            },

            /**
             * Add a single slide.
             * @param  {Element|String} slide - The slide to add. Can be an HTML string or an Element.
             * @param  {number} [position]    - A position number for the slide. Will be added at the end if not provided.
             * @private
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            addSlide: function (slide, position) {

                var elements = this.elements;

                // Do not recreate a DOM element if already an element
                slide = UWA.is(slide, 'element') ? slide : $(slide);
                slide.addClassName('slide');

                if (UWA.is(position)) {
                // TODO: implement positioning when adding slides
                } else {
                    if (!slide.isInjected()) {
                        slide.inject(elements.content);
                    }
                    // Add a dot indicator if needed
                    if (this.options.dots) {
                        UWA.createElement('li', { 'class': 'indicator' }).inject(elements.dots);
                    }
                    this.slides.push(slide);
                    this.dispatchEvent('onAddSlide', slide);
                }
            },

            /**
             * Remove one or many slide(s).
             * @param  {number[]|number} options - The index(es) of the slides to remove.
             * @returns {Carousel}               - The instance
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            remove: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that.removeSlide(option);
                });

                if (!this.current) {
                    this.setActive(0);
                }

                return this;
            },

            /**
             * Remove one slide. Buggy for now.
             * @param  {number} index - The slide to remove.
             * @private
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            removeSlide: function (index) {

                if (this.slides[index]) {

                    this.slides[index].remove();
                    this.slides.splice(index, 1);

                    if (this.elements.dots) {
                        this.elements.dots.getChildren()[index].remove();
                    }

                    this.dispatchEvent('onRemoveSlide', this.slides[index]);
                }
            },

            /**
             * Make a slide active.
             * @param {number} index - The index of the slide to activate
             * @private
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            setActive: function (index) {

                var slide = this.slides[index],
                    elements = this.elements,
                    children;

                if (slide) {
                    slide.addClassName('active');
                    this.current = slide;

                    if (elements.dots) {
                        children = elements.dots.getChildren();
                        // Remove all active dots before adding new
                        children.forEach(function (dot) {
                            dot.removeClassName('active');
                        });
                        children[index].addClassName('active');
                    }
                }
            },

            /**
             * Slide the carousel in a direction or to a specific slide.
             * Will not slide again if already sliding.
             * @param  {number|String} [position='right'] - The direction eg. `left`, `right`, or a slide number.
             * @returns {Carousel}                        - The instance
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            slide: function (directionOrSlide) {

                var that = this,
                    options = this.options,
                    which = 'next',
                    direction = 'left',
                    index = this.slides.indexOf(this.current),
                    loop = false;

                // TODO: Add callback for completion

                // Slide only if we have at least two slides and if not already sliding
                if (this.slides.length < 2 || /sliding|fade/.test(this.current.className)) return;

                if (!UWA.is(directionOrSlide) || UWA.is(directionOrSlide, 'string')) {
                    if (directionOrSlide === 'left') {
                        direction = 'right';
                        which = 'prev';
                        index--;
                    } else {
                        index++;
                    }
                } else if (UWA.is(directionOrSlide, 'number') && this.slides[directionOrSlide] && index !== directionOrSlide) {
                    if (index > directionOrSlide) {
                        direction = 'right';
                        which = 'prev';
                    }
                    index = directionOrSlide;
                } else {
                    index = false;
                }

                // If we had a valid directionOrSlide
                if (index !== false) {

                    if (options.infinite && !this.slides[index]) {
                        index = index === this.slides.length ? 0 : this.slides.length - 1;
                        loop = true;
                    }

                    if (this.slides[index]) {

                        if (that.elements.dots) {
                            var children = that.elements.dots.getChildren();
                            children.forEach(function (dot) {
                                dot.removeClassName('active');
                            });
                        }

                        if (options.animation === 'slide') {
                            this.slides[index].addClassName('sliding ' + which);
                            this.current.addClassName('sliding');

                            setTimeout(function () {
                                that.slides[index].addClassName(direction);
                                that.current.addClassName(direction);

                                setTimeout(function () {
                                    that.current.removeClassName('sliding');
                                    that.current.removeClassName(direction);
                                    that.slides[index].removeClassName('sliding');
                                    that.slides[index].removeClassName(which);
                                    that.slides[index].removeClassName(direction);
                                    that.current.removeClassName('active');
                                    that.setActive(index);
                                    that.dispatchEvent('onSlide');
                                    loop && that.dispatchEvent('onLoop');
                                }, 600);
                            }, 50);
                        } else {
                            that.current.addClassName('fade in');
                            that.slides[index].addClassName('fade ' + which);
                            setTimeout(function () {
                                that.current.removeClassName('in');
                                that.slides[index].addClassName('in');

                                setTimeout(function () {
                                    that.current.removeClassName('fade');
                                    that.slides[index].removeClassName('fade');
                                    that.slides[index].removeClassName(which);
                                    that.slides[index].removeClassName('in');
                                    that.current.removeClassName('active');
                                    that.setActive(index);
                                    that.dispatchEvent('onSlide');
                                    loop && that.dispatchEvent('onLoop');
                                }, 600);
                            }, 50);
                        }
                    }
                }

                return this;
            },

            /**
             * Start auto cycling through slides.
             * @returns {Carousel} - The instance
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            play: function (preventEvents) {

                var that = this,
                    options = this.options;

                // If already playing, delete the previous interval and make a new one.
                this.autoplayTimer && this.pause();

                // If we have a pauseOnHover handle it below
                if (options.pauseOnHover && !preventEvents) {
                    this.elements.container.addEvents({
                        mouseover: function () {
                            that.pause(true);
                        },
                        mouseout: function () {
                            that.play(true);
                        }
                    });
                }

                // Start sliding, default to right
                this.autoplayTimer = setInterval(function () {
                    window.requestAnimationFrame(that.slide.bind(that, 'right'));
                }, options.autoPlaySpeed);

                return this;
            },

            /**
             * Pause any auto-cycle previously set.
             * @returns {Carousel} - The instance
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            pause: function (preventEvents) {

                var options = this.options;

                if (this.autoplayTimer) {
                    // If we have a pauseOnHover remove it now
                    if (options.pauseOnHover && !preventEvents) {
                        this.elements.container.removeEvent('mouseover');
                        this.elements.container.removeEvent('mouseout');
                    }

                    clearInterval(this.autoplayTimer);
                    this.autoplayTimer = null;
                }

                return this;
            },

            /**
             * Destroy the carousel.
             * You should call this to free up memory.
             * @memberof module:DS/UIKIT/Carousel.Carousel#
             */
            destroy: function () {
                this.pause();
                this._parent();
                this.elements = null;
            }
        };

        return Abstract.extend(Carousel);
    });

/* ! Copyright 2014 Dassault Systèmes */

/* Configure AMD Loader to load non AMD lib
 * See requirejs shim config for references :
 *   http://requirejs.org/docs/api.html#config-shim
 */

/* global require, define, Hammer */

// if Hammer has already been exported to global scope (pre-loaded), define it right away.
if (typeof Hammer !== 'undefined') {
    define('DS/VENHammer', function () { 'use strict'; return Hammer; });
} else {
    // In case the module gets executed multiple times
    if (require.toUrl('DS/VENHammer').indexOf('2.0.8/hammer') === -1) {
        // Avoid leaking variables
        (function () {
            'use strict';

            // Remove any query strings
            var path = require.toUrl('DS/VENHammer/2.0.8/hammer');
            if (path.indexOf('?') > -1) {
                path = path.substring(0, path.indexOf('?'));
            }

            require.config({
                paths: { 'DS/VENHammer': path },
                shim: { 'DS/VENHammer': { exports: 'Hammer' } }
            });
        }());
    }
}

define('DS/UIKIT/Touch',
    [
        'DS/VENHammer'
    ],
    /**
     * @module DS/UIKIT/Touch
     * @requires DS/VENHammer
     */
    function (VENHammer) {
        'use strict';

        // Fixing error on scrolling
        // See: https://github.com/hammerjs/hammer.js/wiki/How-to-fix-Chrome-35--and-IE10--scrolling-(touch-action)
        VENHammer.defaults.touchAction = 'pan-y';

        /**
         * @description
         * Handle the gesture events.
         *
         * # Usage
         *
         * Touch is simple to use, with an jQuery-like API. You don't need to add the new keyword, and the instance methods could be chained.
         *
         * ```js
         *     require(['DS/UIKIT/Touch'], function (Touch) {
         *
         *         var element = UWA.createElement('div');
         *         var touch = Touch(element).on("tap", function(event) {
         *             alert('hello!');
         *         });
         *
         *     });
         * ```
         *
         * You can change the default settings by adding an second argument with options
         *
         * ```js
         *     require(['DS/UIKIT/Touch'], function (Touch) {
         *
         *         var element = UWA.createElement('div');
         *         var touch = Touch(element, { drag: false, transform: false }).on("tap", function(event) {
         *             alert('hello!');
         *         });
         *
         *     });
         * ```
         *
         * # Gesture Events
         *
         * The following events are triggered;
         *
         * - hold
         * - tap
         * - doubletap
         * - drag, dragstart, dragend, dragup, dragdown, dragleft, dragright
         * - swipe, swipeup, swipedown, swipeleft, swiperight
         * - transform, transformstart, transformend
         * - rotate
         * - pinch, pinchin, pinchout
         * - touch
         * - release
         *
         * # Gesture Options
         *
         * The following options are available, and shown is their default value. You can find more (and the up-to-date) info about it in the source code, in `src/gestures/` probably.
         *
         *     drag: true
         *     drag_block_horizontal: false
         *     drag_block_vertical: false
         *     drag_lock_to_axis: false
         *     drag_max_touches: 1
         *     drag_min_distance: 10
         *     hold: true
         *     hold_threshold: 3
         *     hold_timeout: 500
         *     prevent_default: true
         *     prevent_mouseevents: false
         *     release: true
         *     show_touches: true
         *     stop_browser_behavior: Object
         *     swipe: true
         *     swipe_max_touches: 1
         *     swipe_velocity: 0.7
         *     tap: true
         *     tap_always: true
         *     tap_max_distance: 10
         *     tap_max_touchtime: 250
         *     doubletap_distance: 20
         *     doubletap_interval: 300
         *     touch: true
         *     transform: true
         *     transform_always_block: false
         *     transform_min_rotation: 1
         *     transform_min_scale: 0.01
         *
         * # Event Data
         *
         * The `event` argument in the callback contains the same properties for each gesture, making more sense for some than for others.
         * The gesture that was triggered is found in `event.type`. Following properties are available in `event.gesture`.
         * Best practice is to just do a `console.log(event)` while you're developing.
         *
         *     timestamp        {Number}        time the event occurred
         *     target           {HTMLElement}   target element
         *     touches          {Array}         touches (fingers, mouse) on the screen
         *     pointerType      {String}        kind of pointer that was used. matches Hammer.POINTER_MOUSE|TOUCH
         *     center           {Object}        center position of the touches. contains pageX and pageY
         *     deltaTime        {Number}        the total time of the touches in the screen
         *     deltaX           {Number}        the delta on x axis we have moved
         *     deltaY           {Number}        the delta on y axis we have moved
         *     velocityX        {Number}        the velocity on the x
         *     velocityY        {Number}        the velocity on y
         *     angle            {Number}        the angle we are moving from the start point.
         *     interimAngle     {Number}        interim angle since the last movement.
         *     direction        {String}        the direction moving from the start point. matches Hammer.DIRECTION_UP|DOWN|LEFT|RIGHT
         *     interimDirection {String}        interim direction since the last movement. matches Hammer.DIRECTION_UP|DOWN|LEFT|RIGHT
         *     distance         {Number}        the distance we have moved
         *     scale            {Number}        scaling of the touches, needs 2 touches
         *     rotation         {Number}        rotation of the touches, needs 2 touches *
         *     eventType        {String}        matches Hammer.EVENT_START|MOVE|END
         *     srcEvent         {Object}        the source event, like TouchStart or MouseDown *
         *     startEvent       {Object}        contains the same properties as above,
         *                                      but from the first touch. this is used to calculate
         *                                      distances, deltaTime, scaling etc
         * @constructs Touch
         * @memberof module:DS/UIKIT/Touch.Touch#
         */
        return VENHammer;
    }
);

/**
 * A clean and ready to use date picker.
 * @module DS/UIKIT/DatePicker
 * @extends UWA/Controls/Abstract
 */
define('DS/UIKIT/DatePicker',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Utils/Scroll',
        'UWA/Controls/Abstract',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],


    function (UWA, Element, Event, Client, ScrollUtils, Abstract, i18n) {

        'use strict';

        /**
         * Common helper functions.
         */
        function isValidDate (obj) {
            return UWA.is(obj, 'date') && !isNaN(obj.getTime());
        }

        /**
         * Returns true if the year is leap.
         */
        function isLeapYear (year) {
        // Solution by Matti Virkkunen: http://stackoverflow.com/a/4881951
            return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
        }

        /**
         * Returns the number of day for a specific month.
         */
        function getDaysInMonth (year, month) {
            return [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
        }

        function setToStartOfDay (date) {
            if (isValidDate(date)) date.setHours(0, 0, 0, 0);
        }

        /**
         * Helper for comparing two dates.
         */
        function compareDates (a, b) {
            // Weak date comparison (use setToStartOfDay(date) to ensure correct result)
            return a.getTime() === b.getTime();
        }

        /**
         * Adjust year and month variables.
         */
        function adjustCalendar (calendar) {
            if (calendar.month < 0) {
                calendar.year -= Math.ceil(Math.abs(calendar.month) / 12);
                calendar.month += 12;
            }
            if (calendar.month > 11) {
                calendar.year += Math.floor(Math.abs(calendar.month) / 12);
                calendar.month -= 12;
            }
            return calendar;
        }

        function fireEvent (el, eventName, data) {
            var ev;

            if (document.createEvent) {
                ev = document.createEvent('HTMLEvents');
                ev.initEvent(eventName, true, false);
                ev = UWA.extend(ev, data);
                el.dispatchEvent(ev);
            } else if (document.createEventObject) {
                ev = document.createEventObject();
                ev = UWA.extend(ev, data);
                el.fireEvent('on' + eventName, ev);
            }
        }

        /**
         * @lends module:DS/UIKIT/DatePicker.DatePicker#
         */
        var DatePicker = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            name: 'datepicker',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            defaultOptions: {
                field: null,
                bound: undefined,
                position: 'bottom left',
                defaultDate: null,
                setDefaultDate: false,
                firstDay: 0,
                minDate: null,
                maxDate: null,
                yearRange: 20,
                showWeekNumber: false,
                isRTL: false,
                yearSuffix: '',
                showMonthAfterYear: false,
                numberOfMonths: 1,
                mainCalendar: 'left',
                renderTo: undefined,
                i18n: {
                    previousMonth: i18n.previousMonth,
                    nextMonth: i18n.nextMonth,
                    months: [i18n.january, i18n.february, i18n.march, i18n.april, i18n.may, i18n.june, i18n.july, i18n.august, i18n.september, i18n.october, i18n.november, i18n.december],
                    weekdays: [i18n.sunday, i18n.monday, i18n.tuesday, i18n.wednesday, i18n.thursday, i18n.friday, i18n.saturday],
                    weekdaysShort: [i18n.sun, i18n.mon, i18n.tue, i18n.wed, i18n.thu, i18n.fri, i18n.sat]
                },
                // Used internally (don't config outside)
                minYear: 0,
                maxYear: 9999,
                minMonth: undefined,
                maxMonth: undefined
            },

            /**
             * A clean and ready to use date picker.
             *
             * @example
             * require(['DS/UIKIT/DatePicker', 'DS/UIKIT/Input/Text'], function (DatePicker, Text) {
             *     var input = new Text().inject(document.body);
             *     var picker = new DatePicker({ field: input });
             * });
             *
             * @param {Object} options                              - The available options.
             *
             * @param {Element}  [options.field]                    - Bind the picker to this form field element.
             * @param {String}   [options.position='bottom left']   - Position of the date picker, relative to the field (default to bottom & left).
             * @param {Boolean}  [options.bound=true]               - Automatically show/hide the picker on `field` focus. Only works if field is set.
             * @param {Element}  [options.trigger=field]            - Use a different element to trigger opening the datepicker.
             * @param {Date}     [options.defaultDate]              - The initial date to view when first opened. If none, will take field value or a current date.
             * @param {Boolean}  [options.setDefaultDate=false]     - Make the `defaultDate` the initial selected value.
             * @param {number}   [options.firstDay=0]               - Define the first day of week (0: Sunday, 1: Monday etc).
             * @param {Date}     [options.minDate]                  - The minimum/oldest date that can be selected.
             * @param {Date}     [options.maxDate]                  - The maximum/latest date that can be selected.
             * @param {number|number[]} [options.yearRange=10]      - Maximum number of years visible in years select, either side, or array of upper/lower range.
             * @param {Boolean}  [options.showWeekNumber=false]     - Show week numbers at head of row.
             * @param {Boolean}  [options.isRTL=false]              - i18n direction handling.
             * @param {String}   [options.yearSuffix]               - Additional text to append to the year in the calendar title.
             * @param {Boolean}  [options.showMonthAfterYear=false] - Show the month picker after year in header.
             * @param {number}   [options.numberOfMonths=1]         - Whether to show one or many month. Useful for multiple date pickings.
             * @param {String}   [options.mainCalendar='left']      - When numberOfMonths is used, this will help you to choose where the main calendar will be
             *                                                        (default `left`, can be set to `right`).
             * @param {Element}  [options.renderTo]                 - If specified will inject the datepicker inside this Element.
             *                                                        If bound is true and renderTo is null, will inject it in document.body.
             *                                                        If both or false/not provided will be added below the field.
             *                                                        If field is not provided than you will have to inject it manually.
             * @param {Object}   [options.events]                   - The available events.
             *
             * @param {Function}   [options.events.onSelect]        - Invoked on datepicker select.
             * @param {Function}   [options.events.onShow]          - Invoked on datepicker show.
             * @param {Function}   [options.events.onHide]          - Invoked on datepicker hide.
             * @param {Function}   [options.events.onDraw]          - Invoked on datepicker drawing a new month.
             *
             * @constructs DatePicker
             * @memberof module:DS/UIKIT/DatePicker
             */
            init: function (options) {

                var nom, fallback;

                this._parent(options);
                options = this.options;
                this.events = {};

                // Normalize args
                options.isRTL = !!options.isRTL;
                options.field = (UWA.is(options.field, 'element')) ? options.field : null;
                options.bound = !!(UWA.is(options.bound) ? options.field && options.bound : options.field);
                options.trigger = (UWA.is(options.trigger, 'element')) ? options.trigger : options.field;

                nom = parseInt(options.numberOfMonths, 10) || 1;
                options.numberOfMonths = nom > 4 ? 4 : nom;

                options.minDate = isValidDate(options.minDate) ? options.minDate : false;
                options.maxDate = isValidDate(options.maxDate) ? options.maxDate : false;

                if ((options.minDate && options.maxDate) && options.maxDate < options.minDate) {
                    options.maxDate = options.minDate = false;
                }

                // Handle default minimum options
                if (options.minDate) {
                    setToStartOfDay(options.minDate);
                    options.minYear  = options.minDate.getFullYear();
                    options.minMonth = options.minDate.getMonth();
                }
                if (options.maxDate) {
                    setToStartOfDay(options.maxDate);
                    options.maxYear  = options.maxDate.getFullYear();
                    options.maxMonth = options.maxDate.getMonth();
                }

                // Handle default year range option
                if (UWA.is(options.yearRange, 'array')) {
                    fallback = new Date().getFullYear() - 10;
                    options.yearRange[0] = parseInt(options.yearRange[0], 10) || fallback;
                    options.yearRange[1] = parseInt(options.yearRange[1], 10) || fallback;
                } else {
                    options.yearRange = Math.abs(parseInt(options.yearRange, 10)) || this.defaultOptions.yearRange;
                    if (options.yearRange > 100) {
                        options.yearRange = 100;
                    }
                }

                this.buildSkeleton();
            },

            /**
             * Build the datepicker skeleton and bind the events.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options,
                    defDate;

                // The main container
                elements.container = UWA.createElement('div', {
                    'class': this.name + (options.isRTL ? ' is-rtl' : '')
                });

                // Add datepicker container events
                elements.container.addEvent('mousedown', this.onMouseDown.bind(this), false, 0, true);
                elements.container.addEvent('change', this.onChange.bind(this));

                if (options.field) {
                    // Handles where to add the datepicker container
                    if (options.renderTo) {
                        elements.container.inject(options.renderTo);
                    } else if (options.bound) {
                        elements.container.inject(document.body);
                    } else {
                        options.field.parentNode.insertBefore(elements.container, options.field.nextSibling);
                    }

                    // Bind change on input field
                    this.events.onInputChange = this.onInputChange.bind(this);
                    options.field.addEvent('change', this.events.onInputChange);

                    if (!options.defaultDate) {
                        options.defaultDate = new Date(Date.parse(options.field.value));
                        options.setDefaultDate = true;
                    }
                }

                defDate = options.defaultDate;

                // Will render HTML by calling draw inside goToDate / setDate
                if (isValidDate(defDate)) {
                    if (options.setDefaultDate) {
                        this.setDate(defDate, true);
                    } else {
                        this.gotoDate(defDate);
                    }
                } else {
                    // No default date. Ensure visible view matches with selectable values
                    var date = new Date(),
                        min = options.minDate,
                        max = options.maxDate;

                    if (isValidDate(min) && date < min) {
                        date = min;
                    } else if (isValidDate(max) && date > max) {
                        date = max;
                    }

                    this.gotoDate(date);
                }

                // Handle display options if bound
                if (options.bound) {
                    this.hide();
                    elements.container.addClassName(' is-bound');

                    this.events.onInputClick = this.onInputClick.bind(this);
                    this.events.onInputFocus = this.onInputFocus.bind(this);
                    this.events.onInputBlur = this.onInputBlur.bind(this);

                    options.trigger.addEvents({
                        click: this.events.onInputClick,
                        focus: this.events.onInputFocus,
                        blur: this.events.onInputBlur
                    });
                } else {
                    this.show();
                }

            },

            /**
             * Default onMouseDown handler.
             * @param {DOMEvent} event
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onMouseDown: function (event) {

                var that = this,
                    target = Event.getElement(event),
                    options = this.options;

                if (!this.visible || !target) {
                    return;
                }

                if (!target.hasClassName('is-disabled')) {
                    if (target.hasClassName(this.name + '-button') && !target.hasClassName('is-empty')) {
                        this.setDate(new Date(target.getAttribute('data-year'), target.getAttribute('data-month'), target.getAttribute('data-day')));
                        if (options.bound) {
                            setTimeout(function () {
                                that.hide();
                                if (options.field) {
                                    options.field.blur();
                                }
                            }, 100);
                        }
                        return;
                    } else if (target.hasClassName(this.name + '-prev')) {
                        this.prevMonth();
                    } else if (target.hasClassName(this.name + '-next')) {
                        this.nextMonth();
                    }
                }

                if (!target.hasClassName(this.name + '-select')) {
                    Event.preventDefault(event);
                } else {
                    this._c = true;
                }
            },

            /**
             * Default onChange handler.
             * @param {DOMEvent} event
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onChange: function (event) {

                var target = Event.getElement(event);

                if (!target) {
                    return;
                }

                if (target.hasClassName(this.name + '-select-month')) {
                    this.gotoMonth(target.value);
                } else if (target.hasClassName(this.name + '-select-year')) {
                    this.gotoYear(target.value);
                }
            },

            /**
             * Default onInputChange handler.
             * @param {DOMEvent} event
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onInputChange: function (event) {

                var date;

                if (event.firedBy === this) {
                    return;
                }

                date = new Date(Date.parse(this.options.field.value));
                this.setDate(isValidDate(date) ? date : null);
            },

            /**
             * Default onInputFocus handler.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onInputFocus: function () {
                this.show();
            },

            /**
             * Default onInputClick handler.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onInputClick: function () {
                this.show();
            },

            /**
             * Default onInputBlur handler.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onInputBlur: function () {
                var that = this;

                if (!this._c) {
                    this._b = setTimeout(function () {
                        that.hide();
                    }, 50);
                }
                this._c = false;
            },

            /**
             * Default onClick handler.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            onClick: function (event) {

                var target = Event.getElement(event),
                    pEl = target;

                if (!target) {
                    return;
                }

                do {
                    if (pEl.hasClassName(this.name)) {
                        return;
                    }
                } while ((pEl = pEl.getParent()));

                if (this.visible && target !== this.options.trigger) {
                    this.hide();
                }
            },

            /**
             * Return a formatted string of the current selection.
             * @returns {String} date - The formatted date.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            toString: function () {
                // Display options for the date formated string
                var intlOptions,
                    dateString;
                if (!isValidDate(this.day)) {
                    dateString = '';
                } else if (!UWA.is(i18n._lang) || !UWA.is(window.Intl)) {
                    dateString = this.day.toDateString();
                } else {
                    intlOptions = {
                        weekday: 'short',
                        year: 'numeric',
                        month: 'short',
                        day: '2-digit'
                    };
                    // The Intl API is currently not supported on Safari
                    // nor in IE < 11 and and mobile browsers but Chrome mobile
                    dateString = new Intl.DateTimeFormat(i18n._lang, intlOptions).format(this.day);
                }
                return dateString;
            },

            /**
             * Return a Date object of the current selection.
             * @returns {Date} date - The current selected date.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            getDate: function () {
                return isValidDate(this.day) ? new Date(this.day.getTime()) : null;
            },

            /**
             * Set the current date selection.
             * This will be restricted within the bounds of minDate and maxDate options if they're specified.
             * You can optionally pass a boolean as the second parameter to prevent triggering of the onSelect callback (true), allowing the date to be set silently.
             * @param {String|Date} date       - The new date.
             * @param {Boolean} [silent=false] - Make it a silent update.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            setDate: function (date, silent) {

                var options = this.options,
                    min, max;

                if (!date) {
                    this.day = null;
                    return this.draw();
                }

                if (UWA.is(date, 'string')) {
                    date = new Date(Date.parse(date));
                }

                if (!isValidDate(date)) {
                    return;
                }

                min = options.minDate;
                max = options.maxDate;

                if (isValidDate(min) && date < min) {
                    date = min;
                } else if (isValidDate(max) && date > max) {
                    date = max;
                }

                this.day = new Date(date.getTime());
                setToStartOfDay(this.day);
                this.gotoDate(this.day);

                if (options.field && options.field.value !== this.toString()) {
                    options.field.value = this.toString();
                    !options.field.disabled && !silent && fireEvent(options.field, 'change', { firedBy: this });
                }

                if (!silent) {
                    this.dispatchEvent('onSelect', this.getDate());
                }
            },

            /**
             * Change the current view to see a specific date.
             * @param {Date} date - The date to go to.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            gotoDate: function (date) {

                var newCalendar = true,
                    firstVisibleDate,
                    lastVisibleDate,
                    visibleDate;

                if (!isValidDate(date)) {
                    return;
                }

                if (this.calendars) {
                    firstVisibleDate = new Date(this.calendars[0].year, this.calendars[0].month, 1);
                    lastVisibleDate = new Date(this.calendars[this.calendars.length - 1].year, this.calendars[this.calendars.length - 1].month, 1);
                    visibleDate = date.getTime();

                    // Get the end of the month
                    lastVisibleDate.setMonth(lastVisibleDate.getMonth() + 1);
                    lastVisibleDate.setDate(lastVisibleDate.getDate() - 1);
                    newCalendar = (visibleDate < firstVisibleDate.getTime() || lastVisibleDate.getTime() < visibleDate);
                }

                if (newCalendar) {
                    this.calendars = [{
                        month: date.getMonth(),
                        year: date.getFullYear()
                    }];

                    if (this.options.mainCalendar === 'right') {
                        this.calendars[0].month += 1 - this.options.numberOfMonths;
                    }
                }

                this.adjustCalendars();
            },

            /**
             * Update the calendar HTML based on model changes.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            adjustCalendars: function () {
                this.calendars[0] = adjustCalendar(this.calendars[0]);
                for (var c = 1; c < this.options.numberOfMonths; c++) {
                    this.calendars[c] = adjustCalendar({
                        month: this.calendars[0].month + c,
                        year: this.calendars[0].year
                    });
                }
                this.draw();
            },

            /**
             * Shortcut for picker.gotoDate(new Date())
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            gotoToday: function () {
                this.gotoDate(new Date());
            },

            /**
             * Change view to a specific month (zero-index, e.g. 0: January).
             * @param {number} month - The month to go to.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            gotoMonth: function (month) {
                if (!isNaN(month)) {
                    this.calendars[0].month = parseInt(month, 10);
                    this.adjustCalendars();
                }
            },

            /**
             * Change view no next available month.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            nextMonth: function () {
                this.calendars[0].month++;
                this.adjustCalendars();
            },

            /**
             * Change view no previous available month.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            prevMonth: function () {
                this.calendars[0].month--;
                this.adjustCalendars();
            },

            /**
             * Change view to a specific full year (e.g. "2012")
             * @param {number} year - The year to go to.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            gotoYear: function (year) {
                if (!isNaN(year)) {
                    this.calendars[0].year = parseInt(year, 10);

                    // Handling case user is going to a date over the max one / under the min one
                    if (this.calendars[0].month > this.options.maxMonth && this.calendars[0].year >= this.options.maxYear) {
                        this.gotoDate(this.options.maxDate);
                    } else if (this.calendars[0].month < this.options.minMonth && this.calendars[0].year <= this.options.maxYear) {
                        this.gotoDate(this.options.minDate);
                    } else {
                        this.adjustCalendars();
                    }

                }
            },

            /**
             * Change the minDate.
             * Set to false to reset the minDate.
             * @param {Date} date - The new minDate.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            setMinDate: function (date) {
                if (isValidDate(date)) {
                    setToStartOfDay(date);
                    this.options.minDate = date;
                    this.options.minYear = this.options.minDate.getFullYear();
                    this.options.minMonth = this.options.minDate.getMonth();
                } else if (date === false) {
                    this.options.minDate = false;
                    this.options.minYear = false;
                    this.options.minMonth = false;
                }
            },

            /**
             * Change the maxDate.
             * Set to false to reset the maxDate.
             * @param {Date} date - The new maxDate.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            setMaxDate: function (date) {
                if (isValidDate(date)) {
                    setToStartOfDay(date);
                    this.options.maxDate = date;
                    this.options.maxYear = this.options.maxDate.getFullYear();
                    this.options.maxMonth = this.options.maxDate.getMonth();
                } else if (date === false) {
                    this.options.maxDate = false;
                    this.options.maxYear = false;
                    this.options.maxMonth = false;
                }
            },

            /**
             * Clear both min and max dates.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            clearDates: function () {
                this.setMinDate(false);
                this.setMaxDate(false);
            },

            /**
             * Draw the datepicker.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            draw: function (force) {

                var that = this,
                    options = this.options,
                    elements = this.elements,
                    minYear = options.minYear,
                    maxYear = options.maxYear,
                    minMonth = options.minMonth,
                    maxMonth = options.maxMonth,
                    html = '';

                function renderTitle (c, year, month, refYear) {
                    var i, j, arr,
                        isMinYear = year === options.minYear,
                        isMaxYear = year === options.maxYear,
                        html = '<div class="datepicker-title">',
                        monthHtml,
                        yearHtml,
                        prev = true,
                        next = true;

                    for (arr = [], i = 0; i < 12; i++) {
                        arr.push('<option value="' + (year === refYear ? i - c : 12 + i - c) + '"' +
                        (i === month ? ' selected' : '') +
                        ((isMinYear && i < options.minMonth) || (isMaxYear && i > options.maxMonth) ? 'disabled' : '') + '>' +
                        options.i18n.months[i] + '</option>');
                    }
                    monthHtml = '<div class="datepicker-label">' +
                              options.i18n.months[month] + '<select class="datepicker-select datepicker-select-month">' + arr.join('') + '</select>' +
                            '</div>';

                    if (UWA.is(options.yearRange, 'array')) {
                        i = options.yearRange[0];
                        j = options.yearRange[1] + 1;
                    } else {
                        i = year - options.yearRange;
                        j = 1 + year + options.yearRange;
                    }

                    for (arr = []; i < j && i <= options.maxYear; i++) {
                        if (i >= options.minYear) {
                            arr.push('<option value="' + i + '"' + (i === year ? ' selected' : '') + '>' + (i) + '</option>');
                        }
                    }
                    yearHtml = '<div class="datepicker-label">' +
                              year + options.yearSuffix + '<select class="datepicker-select datepicker-select-year">' + arr.join('') + '</select>' +
                           '</div>';

                    if (options.showMonthAfterYear) {
                        html += yearHtml + monthHtml;
                    } else {
                        html += monthHtml + yearHtml;
                    }

                    if (isMinYear && (month === 0 || options.minMonth >= month)) {
                        prev = false;
                    }

                    if (isMaxYear && (month === 11 || options.maxMonth <= month)) {
                        next = false;
                    }

                    if (c === 0) {
                        html += '<button class="datepicker-prev' + (prev ? '' : ' is-disabled') + '" type="button">' + options.i18n.previousMonth + '</button>';
                    }
                    if (c === (options.numberOfMonths - 1)) {
                        html += '<button class="datepicker-next' + (next ? '' : ' is-disabled') + '" type="button">' + options.i18n.nextMonth + '</button>';
                    }

                    html += '</div>';

                    return html;
                }

                if (!this.visible && !force) {
                    return;
                }

                if (this.year <= minYear) {
                    this.year = minYear;
                    if (!isNaN(minMonth) && this.month < minMonth) {
                        this.month = minMonth;
                    }
                }
                if (this.year >= maxYear) {
                    this.year = maxYear;
                    if (!isNaN(maxMonth) && this.month > maxMonth) {
                        this.month = maxMonth;
                    }
                }

                for (var c = 0; c < options.numberOfMonths; c++) {
                    html += '<div class="' + this.name + '-calendar">' + renderTitle(c, this.calendars[c].year, this.calendars[c].month, this.calendars[0].year) + this.render(this.calendars[c].year, this.calendars[c].month) + '</div>';
                }

                // Set the HTML for the picker
                elements.container.setHTML(html);

                if (options.bound) {
                    if (options.field.type !== 'hidden') {
                        setTimeout(function () {
                            options.trigger.focus();
                        }, 1);
                    }
                }

                setTimeout(function () {
                    that.dispatchEvent('onDraw');
                }, 0);
            },

            /**
             * Updates the datepicker position.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            updatePosition: function () {

                var options = this.options,
                    elements = this.elements,
                    field = options.trigger,
                    width = elements.container.offsetWidth,
                    height = elements.container.offsetHeight,
                    offsets = field.getOffsets(),
                    viewportWidth = window.innerWidth || document.documentElement.clientWidth,
                    viewportHeight = window.innerHeight || document.documentElement.clientHeight,
                    scrollTop,
                    left, top;

                if (options.renderTo) {
                    var scroller = ScrollUtils.getClosestScrollable(options.renderTo, "y");
                    scrollTop = scroller ? scroller.scrollTop : 0;
                    top = field.getPosition(options.renderTo).y + field.getComputedSize('marginTop');
                } else {
                    scrollTop = window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop;
                    top = offsets.y;
                }

                left = offsets.x;
                top += field.offsetHeight;

                // Default position is bottom & left
                if (left + width > viewportWidth || (options.position.indexOf('right') > -1 && left - width + field.offsetWidth > 0)) {
                    left = left - width + field.offsetWidth;
                }

                if (top + height > viewportHeight + scrollTop || (options.position.indexOf('top') > -1 && top - height - field.offsetHeight > 0)) {
                    top = top - height - field.offsetHeight;
                }

                elements.container.setStyles({
                    position: 'absolute',
                    left: left,
                    top: top
                });
            },

            /**
             * Render HTML for a particular month.
             * @private
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            render: function (year, month) {

                var that = this,
                    options = this.options,
                    now = new Date(),
                    days = getDaysInMonth(year, month),
                    before = new Date(year, month, 1).getDay(),
                    data = [],
                    row = [],
                    cells,
                    after;

                function renderTable (data) {
                    return '<table cellpadding="0" cellspacing="0" class="' + that.name + '-table">' + renderHead() + renderBody(data) + '</table>';
                }

                function renderHead () {
                    var i, arr = [];
                    if (options.showWeekNumber) {
                        arr.push('<th></th>');
                    }
                    for (i = 0; i < 7; i++) {
                        arr.push('<th scope="col"><abbr title="' + renderDayName(i) + '">' + renderDayName(i, true) + '</abbr></th>');
                    }
                    return '<thead>' + (options.isRTL ? arr.reverse() : arr).join('') + '</thead>';
                }

                function renderBody (rows) {
                    return '<tbody>' + rows.join('') + '</tbody>';
                }

                function renderWeek (d, m, y) {
                    // Lifted from http://javascript.about.com/library/blweekyear.htm, lightly modified.
                    var oneJan = new Date(y, 0, 1),
                        weekNum = Math.ceil((((new Date(y, m, d) - oneJan) / 86400000) + oneJan.getDay() + 1) / 7);
                    return '<td class="' + that.name + '-week">' + weekNum + '</td>';
                }

                function renderDayName (day, abbr) {
                    day += options.firstDay;
                    while (day >= 7) {
                        day -= 7;
                    }
                    return abbr ? options.i18n.weekdaysShort[day] : options.i18n.weekdays[day];
                }

                function renderDay (d, m, y, isSelected, isToday, isDisabled, isEmpty) {
                    var arr = [];
                    if (isEmpty) {
                        return '<td class="is-empty"></td>';
                    }
                    if (isDisabled) {
                        arr.push('is-disabled');
                    }
                    if (isToday) {
                        arr.push('is-today');
                    }
                    if (isSelected) {
                        arr.push('is-selected');
                    }
                    return '<td data-day="' + d + '" class="' + arr.join(' ') + '">' +
                         '<button class="' + that.name + '-button ' + that.name + '-day" type="button" ' +
                            'data-year="' + y + '" data-month="' + m + '" data-day="' + d + '">' +
                                d +
                         '</button>' +
                       '</td>';
                }

                function renderRow (days, isRTL) {
                    return '<tr>' + (isRTL ? days.reverse() : days).join('') + '</tr>';
                }

                setToStartOfDay(now);

                if (options.firstDay > 0) {
                    before -= options.firstDay;
                    if (before < 0) {
                        before += 7;
                    }
                }

                cells = days + before;
                after = cells;

                while (after > 7) {
                    after -= 7;
                }
                cells += 7 - after;

                for (var i = 0, r = 0; i < cells; i++) {

                    var day = new Date(year, month, 1 + (i - before)),
                        isDisabled = (options.minDate && day < options.minDate) || (options.maxDate && day > options.maxDate),
                        isSelected = isValidDate(this.day) ? compareDates(day, this.day) : false,
                        isToday = compareDates(day, now),
                        isEmpty = i < before || i >= (days + before);

                    row.push(renderDay(1 + (i - before), month, year, isSelected, isToday, isDisabled, isEmpty));

                    if (++r === 7) {
                        if (options.showWeekNumber) {
                            row.unshift(renderWeek(i - before, month, year));
                        }
                        data.push(renderRow(row, options.isRTL));
                        row = [];
                        r = 0;
                    }
                }

                return renderTable(data);
            },

            /**
             * Returns the visible state of the datepicker.
             * @returns {Boolean}
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            isVisible: function () {
                return this.visible;
            },

            /**
             * Show the datepicker.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            show: function () {

                var options = this.options;

                if (!this.visible) {
                    this.elements.container.removeClassName('is-hidden');
                    this.visible = true;
                    this.draw();

                    if (options.bound) {
                        this.events.onClickOutside = this.onClick.bind(this);
                        Element.addEvent.call(document, 'click', this.events.onClickOutside);
                        this.updatePosition();
                    }

                    this.dispatchEvent('onShow');
                }
            },

            /**
             * Hide the datepicker.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            hide: function () {

                var visible = this.visible;

                if (visible !== false) {
                    if (this.options.bound) {
                        Element.removeEvent.call(document, 'click', this.events.onClickOutside);
                    }

                    this.elements.container.style.cssText = '';
                    this.elements.container.addClassName('is-hidden');
                    this.visible = false;

                    if (UWA.is(visible)) {
                        this.dispatchEvent('onHide');
                    }
                }
            },

            /**
             * Destroy the datepicker.
             * @memberof module:DS/UIKIT/DatePicker.DatePicker#
             */
            destroy: function () {

                var options = this.options,
                    elements = this.elements;

                this.hide();

                if (options.field) {
                    options.field.removeEvent('change', this.events.onInputChange);

                    if (options.bound) {
                        options.trigger.removeEvent('click', this.events.onInputClick);
                        options.trigger.removeEvent('focus', this.events.onInputFocus);
                        options.trigger.removeEvent('blur', this.events.onInputBlur);
                    }
                }

                if (elements.container.parentNode) {
                    elements.container.parentNode.removeChild(this.elements.container);
                }

                this._parent();
            }
        };

        return Abstract.extend(DatePicker);
    });

/**
 * Small bubble next to an element that displays additional information.
 * @module DS/UIKIT/Tooltip
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Tooltip',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Controls/Abstract'
    ],


    function (UWA, Element, Event, Client, Abstract) {

        'use strict';

        /**
         * The tooltip position order for smart positioning
         * @type {Array}
         */
        var isMutationObserverAvailable = 'MutationObserver' in window;

        /**
         * @lends module:DS/UIKIT/Tooltip.Tooltip#
         */
        var Tooltip = {

            /**
             * The allowed positions
             * @type {Array}
             * @private
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            _positions: ['top', 'top right', 'right', 'bottom right', 'bottom', 'bottom left', 'left', 'top left'],

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            name: 'tooltip',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            defaultOptions: {
                className: '',
                animate: true,
                offset: {
                    x: 0,
                    y: 0
                },
                anchor: 'target',
                position: 'top',
                trigger: 'hover focus',
                autoHide: true,
                closeOnClick: false
            },

            /**
             * Tooltip visibility state.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            isVisible: false,

            /**
             * Initiate the scroll polling mechanism only
             * for popovers and click tooltips.
             * @type {Boolean}
             * @private
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            shouldListenForScroll: false,

            /**
             * Small bubble next to an element that displays additional information.
             *
             * @example
             * require(['DS/UIKIT/Tooltip'], function (Tooltip) {
             *     var leftButton = new Button({ value: "left"}).inject(body);
             *     new Tooltip({ position: "left", target: leftButton.getContent(), body: "One fine body" });
             * });
             *
             * @param {Object|Element}                           options - The available options or a DOM element directly.
             * @param {Element}                           options.target - The target needed for positioning the tooltip.
             * @param {String}                        [options.position] - An optional position. Could be 'top', 'top right', 'right', 'bottom right', 'bottom', 'bottom left', 'left', or 'top left'
             * @param {String}                    [options.className=''] - An optional class name.
             * @param {Boolean}                  [options.animate=false] - Whether the tooltip should be animated (slight fade in).
             * @param {Boolean}                  [options.autoHide=true] - Whether the tooltip should be hidden when it's out of viewport.
             * @param {Element|String|Object}             [options.body] - The tooltip body to append.
             * @param {String}                  [options.position="top"] - How should the tooltip be placed around the target.
             * @param {String}           [options.trigger="hover focus"] - How should the tooltip get shown.
             *                                                             Tooltips are disabled by default on touch devices.
             *                                                             If you wish to enable the tooltip on a touch device, please provide a `'touch'` trigger.
             * @param {Boolean}             [options.closeOnClick=false] - If `true` will hide the Tooltip when target is clicked.
             * @param {Object}                          [options.offset] - The tooltip offset to target.
             * @param {number}                      [options.offset.x=0] - The tooltip offset x to target.
             * @param {number}                      [options.offset.y=0] - The tooltip offset y to target.
             * @param {Object}                           [options.delay] - Delay before showing and hiding the tooltip.
             * @param {number}                      [options.delay.show] - Delay before showing.
             * @param {number}                      [options.delay.hide] - Delay before hiding.
             *
             * @param {Object}                          [options.events] - The available events.
             * @param {Function}                 [options.events.onShow] - Invoked when the tooltip is shown.
             * @param {Function}                 [options.events.onHide] - Invoked when the tooltip is hide.
             * @param {String}                                [position] - An optional position similar to options.position.
             *
             * @constructs Tooltip
             * @memberof module:DS/UIKIT/Tooltip
             */
            init: function (options, position) {
                options = options || {};

                if (UWA.is(options, 'element')) {
                    options = { target: options };
                }

                if (position) { options.position = position; }

                // be sure to keep the default triggers
                if (options.trigger === 'touch') options.trigger = this.defaultOptions.trigger + ' touch';
                this._parent(options);
                this._mutationObserver = undefined;

                this.options.animate = Client.Features.transitionsCSS && this.options.animate;
                this.buildSkeleton();
            },

            /**
             * Get the tooltip body content.
             * @returns {Element} content - The body content.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            getBody: function () {
                return this.elements && this.elements.body;
            },

            /**
             * Change the tooltip body content.
             * @param {Element|String|Object} content - The new content.
             * @returns {Tooltip}                     - The instance.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            setBody: function (content) {
                if (this.getBody()) {
                    this.elements.body.empty();
                    this.elements.body.addContent(content);
                }
                this.isVisible && this.updatePosition(this._lastValidPosition);
                return this;
            },

            /**
             * Get the CSS classes for positioning.
             * @param {String} positions - The input classes to parse.
             * @returns {String}         - The CSS classes as a space separated string.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            getPositionClasses: function (positions) {
                var cls = positions || this.options.position,
                    position = cls;

                if (cls.split(' ').length > 1) {
                    cls = position.indexOf('top') > -1 ? ['top'] : ['bottom'];
                    cls.push(position.indexOf('left') > -1 ? 'left' : 'right');
                    cls = cls[0] + ' ' + cls.join('-');
                }

                return cls;
            },

            /**
             * Build HTML skeleton.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            buildSkeleton: function () {

                var createElement = UWA.createElement,
                    elements = this.elements,
                    options = this.options,
                    cls = options.position;

                if (cls.split(' ').length > 1) {
                    cls = options.position.indexOf('top') > -1 ? ['top'] : ['bottom'];
                    cls.push(options.position.indexOf('left') > -1 ? 'left' : 'right');
                    cls = cls[0] + ' ' + cls.join('-');
                }

                // Safe check if user called buildSkeleton directly
                if (elements.container) {
                    return;
                }

                // Build container
                elements.container = createElement('div', {
                    'class': this.getClassNames() + ' ' + cls
                });

                // Build arrow
                createElement('div', {
                    'class': this.name + '-arrow'
                }).inject(elements.container);

                // Build body
                elements.body = createElement('div', {
                    'class': this.name + '-body',
                    html: options.body || options.target.getAttribute('title') || '...'
                }).inject(elements.container);

                // Remove the title to avoid double tooltips
                options.target.setAttribute('title', '');

                // Handle animate option
                if (options.animate) {
                    elements.container.addClassName('fade');
                }

                // Add events
                this.handleEvents();

                // In case a DOM element was passed
                delete options.body;
            },

            /**
             * Main function for handling events.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            handleEvents: function () {

                var that = this,
                    options = this.options,
                    isTouch = UWA.Utils.Client.Features.touchEvents,
                    triggers = options.trigger.split(' ');

                function enter (_show, touch) {
                    return function (mouseEvent) {
                        if (that._shouldStopEventChain) {
                        // event coming from a touchstart event chain + tooltips disabled on touch : prevent any action.
                        // touchmove -> touchend -> mouseover -> mousemove -> mousedown -> mouseup
                        // Reset the semaphore if click event (end of the touchstart event chain)
                            if (mouseEvent && mouseEvent.type === 'click') that._shouldStopEventChain = false;
                            return;
                        }
                        var show = (_show === undefined) ? !that.isVisible : _show;

                        if (show && touch) {
                            // Hide the tooltip on touch devices when the body is clicked.
                            that._touchstart = Element.addEvent.call(document.body, 'touchstart', function (evt) {
                                Element.removeEvent.call(document.body, 'touchstart', that._touchstart);
                                if (that.elements.container.isInjected() && Event.getElement(evt) !== options.target) {
                                    enter(false)();
                                }
                            });
                        }

                        if (options.delay) {
                            clearTimeout(that.timeout);
                            that.timeout = setTimeout(function () {
                                if (show && that.options.target && that.options.target.isInjected()) that.show();
                                else if (!show) that.hide();
                            }, show ? options.delay.show : options.delay.hide);
                        } else {
                            that[show ? 'show' : 'hide']();
                        }
                    };
                }

                // Add events
                if (!this.events && options.target) {
                    this.events = {};

                    if (isTouch) {
                        this.events.touchstart = function (evt) {
                            // this will prevent the tooltip from showing when the trigger is touched
                            // by "canceling" the click, focus... events that follow the touchstart.
                            // the event chain is as follows:
                            // touchstart -> touchmove -> touchend -> mouseover -> mousemove -> mousedown -> mouseup -> click
                            if (this.options.trigger.indexOf('touch') === -1) {
                                this._shouldStopEventChain = true;
                                evt.stopPropagation();
                            }
                        }.bind(this);
                    }

                    triggers.forEach(function (trigger) {
                        if (trigger === 'hover') {
                            this.events.mouseover = enter(true);
                            this.events.mouseout = enter(false);
                        }

                        if (trigger === 'focus') {
                            if (isTouch) {
                                this.events.click = enter(undefined, isTouch);
                            } else {
                                this.events.focus = enter(true);
                                this.events.blur = enter(false);
                            }
                        }

                        if (trigger === 'click') {
                            this.shouldListenForScroll = true;
                            this.events.click = enter();
                        }
                    }, this);

                    if (options.closeOnClick && !this.events.click) {
                        this.events.click = enter();
                    }

                    if (!options.target.addEvents) {
                        UWA.extendElement(options.target);
                    }
                    options.target.addEvents(this.events);

                }
            },

            /**
             * Remove any position changes made on the component.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            resetPosition: function () {
                this.elements.container.setStyles({ top: null, left: null });
                this._positions
                    .map(this.getPositionClasses)
                    .join(' ').split(' ')
                    .forEach(function (cls) {
                        this.elements.container.hasClassName(cls) && this.elements.container.removeClassName(cls);
                    }, this);
            },

            /**
             * Set CSS classes for a requested position.
             * This will change the position of the tooltip arrow.
             * @param {String} requestedPosition - where the tooltip is to be placed
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            setPlacementClasses: function (requestedPosition) {
                this.getPositionClasses(requestedPosition)
                    .split(' ')
                    .forEach(function (cls) {
                        !this.elements.container.hasClassName(cls) && this.elements.container.addClassName(cls);
                    }, this);
            },


            /**
             * Change the top and left CSS properties of the tooltip.
             * @param  {String} requestedPosition   - where the tooltip should be placed
             * @param  {Object} targetPosition      - the position of the tooltip target
             * @param  {Object} targetSize          - the tooltip target height and width
             * @param  {Object} tooltipSize         - the tooltip height and width
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            setPosition: function (requestedPosition, targetPosition, targetSize, tooltipSize) {
                var position = targetPosition,
                    positionClasses = this.getPositionClasses(requestedPosition);

                // Handling Firefox and IE returning NaN instead of 0 for SVG objects
                if (isNaN(targetSize.width)) targetSize.width = 0;

                if (isNaN(targetSize.height)) targetSize.height = 0;


                if (/-right/.test(positionClasses)) {
                    position.x += targetSize.width - tooltipSize.width;
                } else if (/(top|bottom)$/.test(positionClasses)) {
                    position.x += (targetSize.width / 2) - (tooltipSize.width / 2);
                }

                if (/bottom/.test(positionClasses)) {
                    position.y += targetSize.height;
                } else if (/^(left|right)$/.test(positionClasses)) {
                    position.x -= tooltipSize.width;
                    position.y += (targetSize.height / 2) - (tooltipSize.height / 2);
                    if (positionClasses === 'right') {
                        position.x += targetSize.width + tooltipSize.width;
                    }
                } else {
                    position.y -= tooltipSize.height;
                }

                this.elements.container.setStyles({
                    left: Math.round(position.x + this.options.offset.x + parseInt(this.options.target.getStyle('marginLeft'), 10)),
                    top: Math.round(position.y + this.options.offset.y + parseInt(this.options.target.getStyle('marginTop'), 10))
                });
            },


            /**
             * Recompute the position of the tooltip if it is close to an edge of the screen.
             * @param  {String} requestedPosition - where the tooltip is to be placed
             * @param  {Object} targetSize        - the tooltip target height and width
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            adjustPosition: function (requestedPosition, targetSize) {
                var bodyRect = document.body.getBoundingClientRect(),
                    tooltipRect = this.elements.container.getBoundingClientRect(),
                    THRESHOLD = Math.floor((5 * bodyRect.width) / 100), // eslint-disable-line no-magic-numbers
                    closeToRightEdge = (bodyRect.width - tooltipRect.right) <= THRESHOLD,
                    closeToLeftEdge = tooltipRect.left < THRESHOLD,
                    targetPosition, tooltipSize;

                if (closeToRightEdge || closeToLeftEdge) {
                    targetPosition = this.options.target.getPosition(document.body);
                    tooltipSize = this.elements.container.getSize();
                    this.setPosition(requestedPosition, targetPosition, targetSize, tooltipSize);
                }
            },

            /**
             * Check if the tooltip is visible.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            isNotFullyVisible: function () {
                return !this.elements.container.isInViewport(document.body) ||
                !this.elements.container.isInViewport(document.body, true);
            },

            /**
             * Update the tooltip position.
             * @param {String} [position] - where the tooltip is to be placed
             * @returns {Tooltip}         - The instance.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @method updatePosition
             */
            updatePosition: (function () {
                function getNextPosition (currentPosition) {
                    var next  = (this._positions.indexOf(currentPosition) + 1) % this._positions.length;
                    return this._positions[next];
                }
                return function () {
                    var iterationCount = typeof arguments[1] === 'number' ? arguments[1] : 0,
                        MAX_ITERATION_COUNT = this._positions.length,
                        requestedPosition,
                        options,
                        targetPosition,
                        targetSize;

                    if (iterationCount >= MAX_ITERATION_COUNT) return;

                    options = this.options;
                    requestedPosition = arguments[0] || options.position;

                    targetPosition = options.target.getPosition(document.body);
                    targetSize = options.target.getSize();

                    this.resetPosition();
                    this.setPlacementClasses(requestedPosition);
                    // get the size of the tooltip container at the very last moment since changing the position classes
                    // also changes the size of the tooltip.
                    this.setPosition(requestedPosition, targetPosition, targetSize, this.elements.container.getSize());

                    // it could happen that when the target is too close to the edge of its viewport
                    // the dimensions of the tooltip change due to the constraints of its new position.
                    // this leads to the tooltip being slightly misplaced
                    // therefore in those specific cases (less than 5% of the viewport width - arbitrary -)
                    // the top and left values need to be recomputed
                    if (/^(top|bottom)$/.test(requestedPosition) || this._needsPositionAdjusment) {
                        this.adjustPosition(requestedPosition, targetSize);
                    }

                    // in the end if the tooltip is cropped then retry until a valid position
                    // is found or until all available positions have been tried.
                    if (this.isNotFullyVisible()) {
                        this.updatePosition(getNextPosition.call(this, requestedPosition), iterationCount + 1);
                    } else {
                        this._lastValidPosition = requestedPosition;
                    }

                    return this;
                };
            }()),

            /**
             * Toggle the tooltip.
             * @return {Tooltip} - The instance.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            toggle: function () {
                return this[this.isVisible ? 'hide' : 'show']();
            },


            /**
             * Update the position of the tooltip if content has been injected into the container
             * by direct DOM manipulation.
             * @param  {MutationRecord[]} mutations
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            _contentInsertionMutationCallback: function (mutations) {
                var contentChanged = mutations.some(function (mutation) {
                    return mutation.addedNodes.length || mutation.removedNodes.length;
                });
                contentChanged && this.updatePosition(this._lastValidPosition);
            },


            /**
             * Hide the tooltip if its target has been removed from the DOM.
             * @param  {MutationRecord[]} mutations
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             * @private
             */
            _targetRemovalMutationCallback: function (mutations) {
                var isTargetRemoved = mutations.some(function (mutation) {
                    return Array.prototype.indexOf.call(mutation.removedNodes, this.options.target) !== -1;
                }, this);
                isTargetRemoved && this.hide();
            },

            /**
             * Show the tooltip.
             * @return {Tooltip} - The instance.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            show: function () {

                var that = this,
                    elements = this.elements;

                // Safe check for destroyed tooltip
                if (!elements) return;

                if (isMutationObserverAvailable) {
                    if (!this._mutationObserver) {
                        this._mutationObserver = new MutationObserver(function (mutations) {
                            that._targetRemovalMutationCallback(mutations);
                            that._contentInsertionMutationCallback(mutations);
                        });
                    }
                    try {
                        this._mutationObserver.observe(this.options.target.parentNode, { childList: true });
                        this._mutationObserver.observe(this.elements.container, { childList: true, subtree: true });
                    } catch (observerTargetException) {
                    // failure if the first parameter of the observe call is not a node
                    // this will prevent the error from being logged in the browser
                    }
                }

                // Set an interval to poll for target position to detect scrolls
                // This is not an optimal solution but when used with a Scroller component the scroll event
                // is not dispatched on the window. Therefore we cannot detect scroll without losing genericity.
                // Moreover this is a temporary solution has the anchor option has not been implemented.
                // Only initiate this mechanism for non hover component.
                if (this.shouldListenForScroll && this.options.autoHide) {
                    // clear any pending poll
                    clearInterval(this._scrollInterval);
                    this._initialTargetClientRect = this.options.target.getBoundingClientRect();
                    this._scrollInterval = setInterval(function () {
                        var targetClientRect;
                        // See https://stackoverflow.com/questions/19275088/in-google-maps-getboundingclientrect-gives-unspecified-error-in-ie
                        // Basically, IE sometimes do not returns anything more than an exception while it should returns something because it does not recognize the target.
                        try {
                            targetClientRect = that.options.target.getBoundingClientRect();
                        } catch (e) {
                            targetClientRect = { bottom: 0 };
                        }
                        // @see http://devdocs.io/dom/element/getboundingclientrect
                        // scrolling is taken into account in the returned object
                        if (that._initialTargetClientRect.bottom !== targetClientRect.bottom) {
                            // As the hiding is not natural, we need to simulate the focus lost.
                            try {
                                that.options.target.blur && that.options.target.blur();
                            } catch (e) { /* See https://stackoverflow.com/questions/2350554/javascript-ie-error-unexpected-call-to-method-or-property-accesss */ }
                            that.hide();
                        }
                    }, 300);
                }

                if (!this.isVisible) {

                    // Update semaphore
                    this.isVisible = true;

                    // Update DOM
                    // If a scrollbar is visible it will twist the target position
                    // injecting the tooltip at the top seems to prevent the scrollbar
                    // from showing. If not a overflow: hidden could be another approach
                    this.inject(document.body, 'top');

                    this.updatePosition(this._lastValidPosition);

                    this.elements.container.addClassName('in');

                    if (this.options.animate) {
                        setTimeout(function () {
                            // Check for elements is required in case a destroy was called right after a hide / show
                            // Check for isVisible in case someone called hide right after show
                            if (that.elements && that.isVisible) {
                                that.dispatchEvent('onShow');
                            }
                        }, 150);
                    } else {
                        this.dispatchEvent('onShow');
                    }
                }

                return this;
            },

            /**
             * Hide the tooltip
             * @return {Tooltip} - The instance.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            hide: function () {

                var that = this,
                    options = this.options,
                    elements = this.elements;

                function animating () {
                    // Check for elements is required in case a destroy was called right after a hide / show
                    // Check for isVisible in case someone called hide right after show
                    if (!that.isVisible && that.elements) {
                        that.elements.container.remove(document.body);
                        // Remove the margin on body to avoid content movement
                        that.dispatchEvent('onHide');
                    }
                }


                // Safe check for destroyed tooltip
                if (!elements) { return; }

                // clear scroll polling related objects
                if (this.shouldListenForScroll) {
                    clearInterval(this._scrollInterval);
                    this._initialTargetClientRect = undefined;
                }

                if (isMutationObserverAvailable && this._mutationObserver) this._mutationObserver.disconnect();

                if (this.isVisible) {

                    // Update semaphore
                    this.isVisible = false;

                    // Update
                    elements.container.removeClassName('in');

                    if (options.animate) {
                        setTimeout(function () {
                            animating();
                        }, 150);
                    } else {
                        animating();
                    }
                }

                return this;
            },

            /**
             * Destroy the tooltip.
             * @memberof module:DS/UIKIT/Tooltip.Tooltip#
             */
            destroy: function () {
                // To prevent the animation delay when destroying.
                if (this.options) {
                    this.options.animate = false;
                    // Remove any events added to target
                    this.options.target && this.options.target.removeEvents(this.events);
                }
                this.hide();
                this._touchstart && Element.removeEvent.call(document.body, 'touchstart', this._touchstart);
                this._mutationObserver = null;
                this._parent();
                this.elements = null;
            }
        };

        return Abstract.extend(Tooltip);
    });

/**
 * A component that creates a Menu with a list of items that you can manipulate.
 * @module DS/UIKIT/Menu
 * @extends UWA/Controls/Abstract
 */
define('DS/UIKIT/Menu',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Controls/Abstract'
    ],


    function (UWA, Element, Event, Utils, Abstract) {

        'use strict';

        var checkHeaderDivider = (function () {
            var headerDividerRegex = /^(header|divider)$/;
            return function (classes) {
                if (!classes) return false;
                var splitted = classes.split(' ');
                for (var i = 0; i < splitted.length; i++) {
                    if (headerDividerRegex.test(splitted[i])) return true;
                }
                return false;
            };
        }());

        /**
         * Check if the given input is an image.
         * @param  {String} image - String to check
         * @returns {Boolean}
         */
        function isImage (image) {
            return /\.(gif|jpg|jpeg|tiff|png)$/i.test(image);
        }

        /**
         * @lends module:DS/UIKIT/Menu.Menu#
         */
        var Menu = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            name: '',

            /**
             * Class name for default template.
             * @type {String}
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            templateClassname: '',

            /**
             * The Menu item title.
             * @type {Object}
             * @memberof Menu#
             */
            backItem: null,

            /**
             * The Menu items.
             * @type {Object[]}
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            items: null,

            /**
             * The Menu visibility state.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            isVisible: false,

            /**
             * Selected index position in a keyboard navigation context.
             * @type {number}
             * @memberof module:DS/UIKIT/Menu.Menu#
             * @private
             */
            keyboardIndex: -1,

            /**
             * @property {Object} defaultOptions - The default Menu options.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            defaultOptions: {
                multiSelect: false,
                attributes: {}
            },

            /**
             * A component that creates a Menu with a list of items that you can manipulate.
             *
             * @param {Object} options                         - The available options.
             * @param {String} [options.className]             - An optional css class name that you can use for customizing the component easily.
             * @param {Boolean} [options.multiSelect=false]    - In case of sub-menus. True to allow more than one item selection.
             * @param {Object[]} options.items                 - The Menu items.
             * @param {String}  options.items.text             - The item text.
             * @param {Boolean} [options.items.disabled=false] - Whether to disable this item from start.
             * @param {String}  [options.items.name=text]      - An alternative identifier, useful for finding an item in case of similar items. Defaults to `options.items.text`.
             * @param {String}  [options.items.title]          - An optional text that will be shown as a tooltip when hovering this item.
             * @param {String}  [options.items.icon]           - If provided and it is an image file (`toto.jpg`) it will add an <img> with the given path.
             *                                                   Else it will add the icon value as a class on this item element.
             * @param {String}  [options.items.fonticon]       - If provided will prefix the value given by `fonticon-` and add it as a class on this item element.
             * @param {String}  [options.items.className]      - An optional css class name that you can use for customizing this item.
             *                                                   If it is equal to `header` or `divider` > special case.
             * @param {Function}[options.items.handler]        - An optional handler to call when this item is clicked. Will be called after the main `onClick`.
             *                                                   Prefer the main `onClick` event for performance reasons when possible.
             * @param {Boolean} [options.items.selectable]     - If provided item will be selectable
             * @param {Boolean} [options.items.selected]       - If provided item will be selectable and selected from start
             *
             * @param {Object}  [options.attributes={}]        - A map of attributes to set to the Menu container.
             *
             * @constructs Menu
             * @memberof module:DS/UIKIT/Menu
             */
            init: function (options) {

                options = options || {};
                if (options.kb === undefined) options.kb = true;

                this._parent(options);
                this.items = [];
                this.buildSkeleton();

                if (options.items) {
                    options.items.forEach(function (item) {
                        this.addItem(item);
                    }, this);
                }
            },

            /**
             * Build HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            buildSkeleton: function () {

                var createElement = UWA.createElement,
                    elements = this.elements;

                // Safe check if user called `buildSkeleton` directly
                if (elements.container) {
                    return;
                }

                // Build container
                elements.container = createElement('div', {
                    'class': this.getClassNames(),
                    styles: {
                        display: 'none'
                    }
                });

                Object.keys(this.options.attributes).forEach(function (attrKey) {
                    elements.container.setAttribute(attrKey, this.options.attributes[attrKey]);
                }, this);

                // Build wrapper
                elements.wrapper = createElement('ul', { 'class': this.name +  '-wrap', 'tabindex': '1' });
                this.options.multiSelect && elements.wrapper.addClassName('dropdown-multiselect');
                elements.wrapper.inject(elements.container);
            },

            /**
             * Hide the Menu.
             * @returns {Menu} - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            hide: function () {

                if (this.isVisible) {
                    this.isVisible = false;
                    this.getContent().setStyle('display', 'none');
                    this.dispatchEvent('onHide');
                }

                return this;
            },

            /**
             * Show the Menu.
             * @returns {Menu} - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            show: function () {

                if (!this.isVisible) {
                    this.isVisible = true;
                    this.getContent().setStyle('display', '');
                    this.focusIt();
                    this.dispatchEvent('onShow');
                }

                return this;
            },

            /**
             * Focus the menu wrapper
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            focusIt: function () {
                // For keyboard nav
                this.options.kb && this.elements.wrapper.focus();
            },

            /**
             * Add one or many item(s) to the Menu.
             * @param {Object|Object[]} options           - Either a single item or an array of items.
             * @param {String}   options.text             - The item text.
             * @param {Boolean}  [options.disabled=false] - Whether to disable this item from start.
             * @param {String}   [options.id]             - An optional item id for your item.
             * @param {String}   [options.name=text]      - An alternative identifier, useful for finding an item in case of similar items. Defaults to `options.items.text`.
             * @param {String}   [options.icon]           - If provided and it is an image file (`toto.jpg`) it will add an <img> with the given path.
             *                                              Else it will add the icon value as a class on this item element.
             * @param {String}   [options.fonticon]       - If provided will prefix the value given by `fonticon-` and add it as a class on this item element.
             * @param {String}   [options.className]      - An optional css class name that you can use for customizing this item.
             *                                              If it is equal to `header` or `divider` > special case.
             * @param {Function} [options.handler]        - An optional handler to call when this item is clicked.
             * @param {Boolean}  [options.selectable]     - If provided item will be selectable
             * @param {Boolean}  [options.selected]       - If provided item will be selectable and selected from start
             * @param {number}   [options.index]          - The index at which to add the menu (one-based index). Will take the next available index if not provided or wrong.
             * @param {Object}   [options.attributes={}]  - A map of attributes to set to the item container.
             * @returns {Menu}                            - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            addItem: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that._addItem(option);
                });

                return this;
            },

            addBackItem: function (options) {
                options.isBackItem = true;
                this.backItem = this._addItem(options);
                return this.backItem;
            },

            /**
             * Add the specified menu item.
             * @param {Object} options - The available options. See `addItem`.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            _addItem: function (options) {

                var elements = this.elements,
                    cls = options.className || '',
                    item = {}, next,
                    that = this;

                item.id = options.id || 'itm-' + Utils.getUUID().substr(0, 6);

                if (!options.name) {
                    item.name = options.text;
                }

                if (options.disabled) {
                    cls += ' disabled';
                }

                if (options.selected) {
                    options.selectable = true;
                }

                if (options.selectable) {
                    cls += ' selectable';
                    item.toggleSelection = function () {
                        that.toggleSelection(item);
                    };
                }

                item.elements = {};

                // Create item container
                item.elements.container = UWA.createElement('li', {
                    'class': 'item ' + cls,
                    id: item.id,
                    title: options.title || ''
                });

                Object.keys(options.attributes || {}).forEach(function (attrKey) {
                    item.elements.container.setAttribute(attrKey, options.attributes[attrKey]);
                });

                if (options.name) {
                    item.elements.container.set('name', options.name);
                }

                if (options.template) {
                    item.elements.content = UWA.createElement('div', {
                        'class': 'item ' + this.templateClassname,
                        id: item.id,
                        html: options.template
                    }).inject(item.elements.container);

                } else if (options.text) {
                    item.elements.content = UWA.createElement('span', {
                        'class': 'item-text',
                        text: options.text || ''
                    }
                    ).inject(item.elements.container);
                }

                if (checkHeaderDivider(options.className)) {
                    item.elements.container.removeClassName('item');
                } else {

                    // Add the fonticon option
                    if (options.fonticon) {
                        item.elements.icon = UWA.createElement('span', {
                            'class': 'fonticon fonticon-' + options.fonticon
                        }).inject(item.elements.container, 'top');
                        elements.wrapper.addClassName(this.name + '-icons');
                    }

                    // Will add an icon only if it does not have a fonticon
                    if (!options.fonticon && options.icon) {

                        // If it is a real image
                        if (isImage(options.icon)) {
                            item.elements.icon = UWA.createElement('img', {
                                src: options.icon,
                                'class': 'item-icon'
                            });
                        } else {
                            // DEPRECATED: This is for legacy support
                            item.elements.icon = UWA.createElement('span', {
                                'class': options.icon
                            });
                        }

                        item.elements.icon.inject(item.elements.container, 'top');
                        elements.wrapper.addClassName(this.name + '-icons');
                    }
                }

                // Keep reference on the handler option
                if (options.handler && UWA.is(options.handler, 'function')) {
                    item.handler = options.handler;
                }

                // Handle the position option (only if not adding at end)
                if (options.index && options.index !== this.items.length + 1) {
                    next = this.items[options.index - 1];
                    item.elements.container.inject(next.elements.container, 'before');
                    if (!options.isBackItem) {
                        this.items.splice(options.index - 1, 0, UWA.merge(item, options));
                    }
                } else {
                    // Add item in parent DOM and save it in our array
                    item.elements.container.inject(elements.wrapper);
                    this.items.push(UWA.merge(item, options));
                }

                if (options.selected) {
                    this.select(item);
                }

                return item;
            },

            /**
             * Remove one or many specified item(s) from the Menu.
             * @param {number|String|Element} options - Identifier of the item to be removed. Or an array of identifiers to remove.
             *                                        Can be the item Element, the item name, the item index (from `this.items`).
             * @returns {Menu}                        - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            removeItem: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that._removeItem(option);
                });

                return this;
            },

            /**
             * Remove the item back.
             * @returns {Menu} - The Menu instance
             * @memberof Menu#
             */
            removeBackItem: function () {
                this.backItem && this.backItem.elements.container.destroy();
                this.backItem = null;
                return this;
            },

            /**
             * Removes the specified item from the menu.
             * @param {number|String|Element} id - Identifier of the item to remove. See `removeItem`.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            _removeItem: function (id) {

                var item = this.getItem(id);

                if (item) {
                    item.elements.container.destroy();
                    this.items.splice(this.items.indexOf(item), 1);
                }
            },

            /**
             * Update one or many menu item(s).
             *
             * @param {Object|Object[]} options          - Either a single item or an array of items.
             *
             * @param {number|String|Element} options.id - Identifier of the item to update.
             * @param {String} [options.text]            - The new item `text`. (will change item `name` if `name` is not specified)
             * @param {String} [options.disabled]        - The new item `disabled` state.
             * @param {String} [options.name]            - The new item `name`.
             * @param {String} [options.title]           - The new item `title`.
             * @param {String} [options.icon]            - The new item `icon`. If provided and it is an image file (`toto.jpg`) it will add an <img> with the given path.
             *                                             Else it will add the given value for icon as a class for this item.
             * @param {String} [options.fonticon]        - The new item `fonticon`. If provided, will prefix the value given by `fonticon-` and add it as a class on this item.
             * @param {String} [options.className]       - The new `className`. An optional `css` class name that you can use for customizing this item.
             *                                             If it is equal to `header` or `divider` > special case).
             * @param {Function}[options.handler]        - An optional new `handler` to call when this item is clicked. Will be called after the main 'onClick'.
             *                                             Prefer the main `onClick` event for performance reasons.
             * @returns {Menu}                           - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            updateItem: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that._updateItem(option);
                });

                return this;
            },

            /**
             * Updates the specified item from the Menu.
             * @param {Object} options - The available options. See `updateItem`.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            _updateItem: function (options) {

                var item = this.getItem(options.id), templateDOM;

                // TODO: update index

                function updateIcon (item) {
                    item.elements.icon && item.elements.icon.destroy();
                    item.elements.icon = UWA.createElement('span', {
                        'class': item.icon
                    }).inject(item.elements.container, 'top');
                }

                function updateFontIcon (item) {
                    item.elements.icon && item.elements.icon.destroy();
                    item.elements.icon = UWA.createElement('span', {
                        'class': 'fonticon fonticon-' + item.fonticon
                    }).inject(item.elements.container, 'top');
                }

                if (item) {
                    if (UWA.is(options.text) && item.text !== options.text) {
                        item.text = options.text;
                        item.elements.container.getElement('.item-text').setText(options.text);
                    }

                    templateDOM = item.elements.container.getElement('.' + this.templateClassname);

                    if (UWA.is(options.template) && templateDOM) {
                        templateDOM.setHTML(options.template);
                    }

                    if (UWA.is(options.name) && item.name !== options.name) {
                        item.name = options.name;
                    }

                    if (UWA.is(options.title) && item.title !== options.title) {
                        item.title = options.title;
                        item.elements.container.title = options.title;
                    }

                    if (UWA.is(options.fonticon) && item.fonticon !== options.fonticon) {
                        item.fonticon = options.fonticon;
                        updateFontIcon(item);
                    } else if (UWA.is(options.icon) && item.icon !== options.icon) {
                        item.icon = options.icon;
                        updateIcon(item);
                    }

                    if (UWA.is(options.disabled)) {
                        item.elements.container.toggleClassName('disabled', options.disabled);
                    }

                    if (UWA.is(options.className) && item.className !== options.className) {
                        item.elements.container.removeClassName(item.className);
                        item.elements.container.addClassName(options.className);
                        item.className = options.className;

                        // Test for special header / divider class
                        if (checkHeaderDivider(options.className)) {
                            item.elements.container.removeClassName('item');
                        } else {
                            item.elements.container.addClassName('item');
                        }
                    }

                    if (UWA.is(options.handler)) {
                        item.handler = options.handler;
                    }
                }
            },

            /**
             * Allow an item to be clicked.
             * @param {number|String|Element} id - Identifier of the item to enable.
             * @returns {Menu}                   - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            enableItem: function (id) {
                var item = this.getItem(id);
                item && item.elements.container.removeClassName('disabled');
                return this;
            },

            /**
             * Remove the possibility for an item to be clicked. Giving it a `disabled` state.
             * @param {number|String|Element} id - Identifier of the item to enable.
             * @returns {Menu}                   - The Menu instance
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            disableItem: function (id) {
                var item = this.getItem(id);
                item && item.elements.container.addClassName('disabled');
                return this;
            },

            /**
             * Retrieves the specified item from the Menu.
             * @param  {number|String|Element} id - Identifier of the item to retrieve.
             * @returns {Object}                  - The matching item if some, else false.
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            getItem: function (id) {

                var i, l, element,
                    item = false;

                // Retrieves the item
                for (i = 0, l = this.items.length; i < l; i += 1) {
                    item = this.items[i];
                    // If argument is a Node, compare to item's HTML id
                    if (id && id.nodeType) {
                        element = id.hasClassName('item') ? id : id.getParent();
                        if (item.id === element.id) break;
                        // If argument is a Number, compare to item's index position
                        // If argument is a String, compare to item's unique id or item's name
                    } else if (i === id || item.id === id || item.name === id) {
                        break;
                    }

                    item = false;
                }

                return item;
            },

            /**
             * Fake an hover on a given item or disable hover.
             * @param {number|String|Element} id  - Identifier of the item to retrieve.
             * @param {Boolean} [hover=true]      - True to hover, false to un-hover.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            _hoverItem: function (id, hover) {
                var item = this.getItem(id);

                if (item) {
                    hover = (hover === undefined) ? (true) : hover;
                    if (hover) {
                        item.elements.container.addClassName('js-selected');
                        this.options.kb && item.elements.container.focus();
                    } else {
                        item.elements.container.removeClassName('js-selected');
                    }
                }
            },

            /**
             * Change index of the item selected through the keyboard.
             * @param {String} type         - 'reset', 'up', 'down'. Will proceed an initialization if nothing is provided.
             * @param {Integer} [position]  - Optional position form which start instead of keyboard index.
             * @private
             * @memberof module:DS/UIKIT/Menu.Menu#
             */
            _updateKeyboardIndex: function (type, position) {

                var pos = position || this.keyboardIndex,
                    savePos = this.keyboardIndex,
                    shouldUpdate = false,
                    item;

                if (pos === -1 && type !== 'reset') {
                    // If no position yet, initiate to first item
                    pos = 0;
                    shouldUpdate = true;
                } else if (type === 'down' && pos < this.items.length - 1) {
                    // Go down when possible
                    pos = pos + 1;
                    shouldUpdate = true;
                } else if (type === 'up' && pos > 0) {
                    // Go up when possible
                    pos = pos - 1;
                    shouldUpdate = true;
                } else if (type === 'reset') {
                    // Unselect active item and reset index
                    shouldUpdate = true;
                    this._hoverItem(pos, false);
                    pos = -1;
                } else if (!type) {
                    shouldUpdate = true;
                }
                item = this.getItem(pos);

                if (item && checkHeaderDivider(item.elements.container.className)) {
                    shouldUpdate = false;
                    if (type === 'down' || type === 'up') {
                        this._updateKeyboardIndex(type, pos);
                    }
                }

                // Select item at the given index
                if (shouldUpdate && pos >= 0) {
                    this._hoverItem(savePos, false);
                    this._hoverItem(pos);
                    this.keyboardIndex = pos;
                }
            },

            /**
            * Toggle the selected state of a provided item
            *
            * @param  {Object} item - The item object
            * @memberof module:DS/UIKIT/Menu.Menu#
            */
            toggleSelection: function (item) {
                this.select(item, !item.selected);
            },

            /**
             * Select or unselect the provided item.
             *
             * @param  {Object}     item            - The item object
             * @param  {Boolean}    [selected=true] - If `false`, unselect the item instead of selecting it.
             * @memberof module:DS/UIKIT/Menu.Menu#
             * @method select
             */
            select: (function () {

                var processSelection = function (item, selected) {
                    item.selected = selected;
                    item.elements.container[selected ? 'addClassName' : 'removeClassName']('selected');
                };

                return function (item, selected) {
                    var selectedItems, radio = !this.options.multiSelect;

                    if (selected === undefined || selected === true) {
                        // If radio mode, unselect previously selected item
                        if (radio) {
                            selectedItems = this.items.filter(function (item) { return item.selected; });
                            selectedItems[0] && processSelection(selectedItems[0], false);
                        }
                        processSelection(item, true);
                    } else {
                        // If radio mode and item is already selected, do not unselect it.
                        if (radio && item.selected) { return; }
                        processSelection(item, false);
                    }
                };
            }())
        };

        return Abstract.extend(Menu);
    });

/* jshint curly: false, maxlen: 2000 */
/* global define */

define('DS/UIKIT/Core',
    [
        //'css!DS/UIKIT/UIKIT'
    ],

/**
 * The Core module that requires the main css.
 * @module DS/UIKIT/Core
 */
function () {

    'use strict';

    var debug = true,
        slice = Array.prototype.slice,
        exports = {
        /**
         * Wrapper for console.log.
         * @private
         */
        log: function () {
            if (!debug) { return; }
            if (window.console) {
                if (typeof (console.log) === 'function') { // modern browsers
                    console.log.apply(console, slice.call(arguments));
                } else if (typeof (console.log) === 'object') { // IE
                    console.log(slice.call(arguments));
                }
            } else if (window.opera && typeof (opera.postError) === 'function') { // Opera
                opera.postError.apply(null, slice.call(arguments));
            }
        }
    };

    return exports;
});

define('DS/UIKIT/Mask',
    [
        'UWA/Core',
        'DS/UIKIT/Spinner',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],
    function (UWA, Spinner, i18n) {

        'use strict';

        /**
         * @exports DS/UIKIT/Mask
         * @requires DS/UIKIT/Spinner
         * @namespace Mask
         */
        var Mask = {

            /**
             * Create a mask over the provided element.
             * @example
             * require(['DS/UIKIT/Mask'], function (Mask) {
             *     var element = UWA.createElement('div');
             *     Mask.mask(element);
             * });
             * @param {Element} element               - The DOM element to mask.
             * @param {String} [message='Loading...'] - An optional message to display.
             */
            mask: function (element, message) {

                var mask;

                if (this.isMasked(element)) {
                    this.unmask(element);
                }

                element.addClassName('masked');
                mask = UWA.createElement('div', { 'class': 'mask' });

                message = UWA.is(message, 'string') ? message : i18n.loading;
                message = UWA.createElement('div', {
                    'class': 'mask-wrapper',
                    html: {
                        tag: 'div',
                        'class': 'mask-content',
                        html: [
                            new Spinner({
                                visible: true,
                                animate: true,
                                spin: true
                            }),
                            UWA.createElement('span', {
                                'class': 'text',
                                text: message
                            })
                        ]
                    }
                }).inject(mask);

                mask.inject(element);
            },

            /**
             * Unmask the provided element.
             * @param {Element} element - The DOM element to unmask.
             */
            unmask: function (element) {
                var mask = element.getElement(' > .mask');
                if (mask) { mask.destroy(); }
                element.removeClassName('masked');
            },

            /**
             * Test if element is masked or not.
             * @param {Element} element - The DOM element to check for mask.
             * @returns {Boolean} - `true` if element is masked. False otherwise.
             */
            isMasked: function (element) {
                return element.hasClassName('masked');
            }
        };

        return Mask;
    });

/**
 * Small overlay of content to provide extra information next to an element.
 * @module DS/UIKIT/Popover
 * @extends DS/UIKIT/Tooltip
 */
define('DS/UIKIT/Popover',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'DS/UIKIT/Tooltip'
    ],


    function (UWA, Element, Event, Client, Tooltip) {

        'use strict';

        /**
         * @lends module:DS/UIKIT/Popover.Popover#
         */
        var Popover = {

            /**
             * The allowed positions
             * @type {Array}
             * @private
             * @memberof module:DS/UIKIT/Popover.Popover#
             */
            _positions: ['top', 'right', 'bottom', 'left'],

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Popover.Popover#
             */
            name: 'popover',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Popover.Popover#
             */
            defaultOptions: {
                position: 'right',
                trigger: 'click'
            },

            /**
             * Small overlay of content to provide extra information next to an element.
             *
             * @example
             * require(['DS/UIKIT/Popover'], function (Popover) {
             *     var topButton = new Button({ value: "Popover on top"}).inject(body);
             *     new Popover({
             *         target: topButton.getContent(),
             *         position: "top",
             *         body: "Lorem ipsum dolor...",
             *         title: "Popover top"
             *     });
             * });
             *
             * @param {Object}                        options - The available options.
             *
             * @param {Element}                options.target - The target needed for positioning the popover.
             * @param {String}         [options.className=''] - An optional class name.
             * @param {Boolean}       [options.animate=true ] - Whether the popover should be animated (slight fade in).
             * @param {Boolean}       [options.autoHide=true] - Whether the popover should be hidden when its parent container is out of viewport.
             * @param {Element|String|Object}  [options.body] - The popover body to append.
             * @param {Element|String|Object} [options.title] - The popover title to append.
             * @param {String}     [options.position="right"] - How should the popover be placed around the target.
             * @param {String}      [options.trigger="click"] - How should the popover gets shown.
             *                                                  Popovers are disabled by default on touch devices.
             *                                                  If you wish to enable the popover on a touch device, please provide a `'touch'` trigger.
             *
             * @param {Object}               [options.offset] - The popover offset to target.
             * @param {number}           [options.offset.x=0] - The popover offset x to target.
             * @param {number}           [options.offset.y=0] - The popover offset y to target.
             *
             * @param {Object}                [options.delay] - Delay before showing and hiding the popover.
             * @param {number}         [options.delay.show=0] - Delay before showing.
             * @param {number}         [options.delay.hide=0] - Delay before hiding.
             *
             * @param {Object}               [options.events] - The available events.
             * @param {Function}      [options.events.onShow] - Invoked when the popover is shown.
             * @param {Function}      [options.events.onHide] - Invoked when the popover is hide.
             *
             * @constructs Popover
             * @memberof module:DS/UIKIT/Popover
             *
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#hide as #hide
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#toggle as #toggle
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#isVisible as #isVisible
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#setPosition as #setPosition
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#updatePosition as #updatePosition
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#getBody as #getBody
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#setBody as #setBody
             * @borrows module:DS/UIKIT/Tooltip.Tooltip#destroy as #destroy
             */
            init: function (options) {
                this._parent(options);
                this._needsPositionAdjusment = true;
                this.shouldListenForScroll = true;
            },

            /**
             * Build HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/Popover.Popover#
             */
            buildSkeleton: function () {

                var createElement = UWA.createElement,
                    elements = this.elements,
                    options = this.options;

                // Safe check if user called buildSkeleton directly
                if (elements.container) {
                    return;
                }

                // Build container
                elements.container = createElement('div', {
                    'class': this.name + ' ' + options.className + ' ' + options.position
                });

                // Build arrow
                createElement('div', {
                    'class': this.name + '-arrow'
                }).inject(elements.container);

                // Build title
                if (options.title) {
                    this.setTitle(options.title);
                }

                // Build body
                elements.body = createElement('div', {
                    'class': this.name + '-body',
                    html: options.body || ''
                }).inject(elements.container);

                // Handle animate option
                if (options.animate) {
                    elements.container.addClassName('fade');
                }

                // Add events
                this.handleEvents();

                // In case a DOM element was passed
                options.body = null;
            },

            /**
             * Get the popover title text.
             * @returns {Element} title - The title text.
             * @memberof module:DS/UIKIT/Popover.Popover#
             */
            getTitle: function () {
                var elements = this.elements;

                if (!elements.title) {
                    elements.title = UWA.createElement('h3', {
                        'class': this.name + '-title'
                    }).inject(elements.container);
                }

                return elements.title;
            },

            /**
             * Change the popover title text.
             * @param {String} title - The new title.
             * @returns {Popover}    - The instance.
             * @memberof module:DS/UIKIT/Popover.Popover#
             */
            setTitle: function (title) {
                this.getTitle().setText(title);
                this.isVisible && this.updatePosition(this._lastValidPosition);
                return this;
            }
        };

        return Tooltip.extend(Popover);
    });

/**
 * Displays user centric messages.
 * @module DS/UIKIT/Alert
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Alert',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Core'
    ],

    function (UWA, Element, Event, Utils, Abstract) {

        'use strict';

        /**
         * @lends module:DS/UIKIT/Alert.Alert#
         */
        var Alert = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component classname.
             * Component variations classname prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Alert.Alert#
             */
            name: 'alert',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Alert.Alert#
             */
            defaultOptions: {
                className: '',
                messageClassName: 'alert-primary',
                animate: true,
                closable: true,
                visible: false,
                hideDelay: 2000,
                autoHide: false,
                closeOnClick: true,
                icon: true,
                maximumVisibleMessages: 5,
                fullWidth: false,
                attributes: {}
            },

            /**
             * The visible state.
             * @type {Boolean}
             * @default false
             * @readonly
             * @memberof module:DS/UIKIT/Alert.Alert#
             */
            isVisible: false,

            /**
             * The messages queue.
             * Internal usage only.
             * @type {Array}
             * @private
             * @memberof module:DS/UIKIT/Alert.Alert#
             */
            messages: null,

            /**
             * Id of the timeout hiding the current message.
             * Internal usage only.
             * @type {number}
             * @private
             * @memberof module:DS/UIKIT/Alert.Alert#
             */
            hidingIntervalId: null,

            /**
             * Displays user centric messages.
             * Display a very simple alert with only a body.
             * The alert will be displayed inside an alert container that you will have to inject in the page.
             *
             * @example
                require(['DS/UIKIT/Alert'], function (Alert) {

                    var myButton = new Button({ value: "Click me" }).inject(body);

                    var myAlert = new Alert({
                        closable: true,
                        visible: true
                    }).inject(body);

                    myButton.addEvent("onClick", function () {
                        myAlert.add({ className: "primary", message: "foo" });
                    });

                });
             *
             * @param {Object} options                               - The available options.
             *
             * @param {String}   [options.className]                   - An optional class name.
             * @param {String}   [options.messageClassName=`primary`]  - An optional default message class name. Available: `primary`, `error`, `warning`.
             * @param {String}   [options.icon=true]                   - Whether to display an icon next to the alert. Will match messageClassName type.
             * @param {Boolean}  [options.animate=true]                - Whether the alert messages be animated.
             * @param {Boolean}  [options.autoHide=false]              - Whether the alert messages should try to remove themselves after a delay.
             * @param {number}   [options.hideDelay=2000]              - The delay time before the messages attempt to hide themselves.
             * @param {number}   [options.maximumVisibleMessages=5]    - The maximum number of messages to display at once.
             * @param {Boolean}  [options.closable=false]              - Whether the alert messages should have a cross at top right. Also bind the removeMessage when clicked.
             * @param {Boolean}  [options.closeOnClick=false]          - Whether the alert message should be closed when clicked.
             * @param {Boolean}  [options.fullWidth=false]             - True to fit the container width.
             * @param {Object}   [options.attributes={}]               - A map of attributes to set to the Alert container.
             * @param {Element}  [options.renderTo]                    - If specified will inject the alert inside this Element.
             *                                                           If not will have to be injected manually.
             * @param {Boolean}  [options.visible=false]               - The alert messages starts displaying after DOM injection. Else you have to call show / toggle manually.
             * @param {Element|Array|String|Object} [options.messages] - The initial message(s) to display.
             *
             * @param {Element|String} options.messages.message        - The message to display.
             * @param {String} [options.messages.className=options.messageClassName] - The message className.
             *
             * @param {Object}   [options.events]                      - The available events.
             *
             * @param {Function}   [options.events.onShow]             - Invoked when the alert container is shown.
             * @param {Function}   [options.events.onHide]             - Invoked when the alert container is hide.
             * @param {Function}   [options.events.onClick]            - Invoked when an alert message is clicked.
             * @param {Function}   [options.events.onRemoveMessage]    - Invoked when a message is removed from the Alert.
             * @param {Function}   [options.events.onShowMessage]      - Invoked when a message is shown inside the Alert.
             *
             * @constructs Alert
             * @memberof module:DS/UIKIT/Alert
             */
            init: function (options) {

                var opts = options || {};

                this._parent(opts);
                this.messages = [];
                this.buildSkeleton();

                // Handle initial messages option
                this.add(this.options.messages);

                // Handle renderTo option
                if (opts.renderTo) {
                    this.inject(opts.renderTo);

                    // Remove reference
                    delete this.options.renderTo;
                }
            },

            /**
             * Build HTML skeleton.
             * @private
             */
            buildSkeleton: function () {

                var elements = this.elements;

                // Safe check if user called buildSkeleton directly
                if (elements.container) {
                    return;
                }

                // Build container
                elements.container = UWA.createElement('div', {
                    'class': this.getClassNames(),
                    events: {
                        click: this.eventHandler.bind(this)
                    }
                });

                Object.keys(this.options.attributes).forEach(function (attrKey) {
                    elements.container.setAttribute(attrKey, this.options.attributes[attrKey]);
                }, this);

                if (this.options.fullWidth) {
                    elements.container.addClassName(this.name + '-fullwidth');
                }
            },

            /**
             * Add one or many message(s) in the alert queue.
             * @param {Element|String|Array|Object} messages - The messages to display.
             *
             * @param  {Element|String}               messages.message                              - The message to display.
             * @param  {String}                       [messages.className=options.messageClassName] - The message className.
             * @return {this} instance.
             */
            add: function (messages) {

                var that = this;

                messages = Utils.splat(messages);
                messages.forEach(function (msg) {
                    that.messages.push(msg);
                });

                if (this.elements.container.isInjected()) {
                    this.showMessages();
                }

                return this;
            },

            /**
             * Run or stop auto hiding timeout.
             *
             * @param  {Boolean} autoHide   - True to start auto hiding, false to stop
             * @param  {Element} element    - Container of the message being auto hidden
             *
             * @private
             */
            toggleAutoHide: function (autoHide, element) {
                var that = this;

                if (autoHide && element) {
                    this.hidingIntervalId = setTimeout(function () {
                        that.remove(element);
                    }, that.options.hideDelay);
                } else {
                    clearInterval(this.hidingIntervalId);
                }
            },

            /**
             * Create the DOM message object.
             * @param  {Object} msg - The message object (see add).
             * @private
             */
            createMessage: function (msg) {

                var element, match, i, l,
                    that = this,
                    index = 100,
                    elements = this.elements,
                    options = this.options,
                    messages = this.getMessages(),
                    offsetDimensions = 0,
                    className = options.messageClassName || '';

                // Get a z-index
                if (messages.length > 0) {
                    index = messages[messages.length - 1].getStyle('z-index') - 1;
                }

                // Change the message class if needed be
                if (msg && msg.className) {
                    className = msg.className;
                }

                // Parse the className and convert it if needed. primary > alert-primary
                className = className.split(' ');
                for (i = 0, l = className.length; i < l; i++) {
                    match = className[i].match(/(alert-)?(primary|warning|error|success|default|info)$/);

                    if (match && !match[1]) {
                        if (className[i] === 'default' || className[i] === 'info') {
                            className[i] = 'primary';
                        }
                        className[i] = 'alert-' + className[i];
                        break;
                    }
                }
                className = className.join(' ');

                // Create the message body
                element = UWA.createElement('div', {
                    'class': this.name + '-message ' + className,
                    html: msg.message ? msg.message : msg,
                    styles: {
                        zIndex: index
                    }
                });

                if (typeof msg.attributes === 'object') {
                    Object.keys(msg.attributes).forEach(function (attrKey) {
                        element.setAttribute(attrKey, msg.attributes[attrKey]);
                    });
                }

                // Handle the animate option
                if (options.animate) {
                    element.addClassName('fade');
                }

                // Handle the closable option
                // Always closable since spec...
                if (options.closable || true) {
                    element.addClassName(this.name + '-closable');

                    UWA.createElement('span', {
                        'class': 'close fonticon fonticon-cancel'
                    }).inject(element, 'top');
                }

                // Handle the icon option
                if (options.icon) {
                    element.addClassName(this.name + '-has-icon');

                    UWA.createElement('span', {
                        'class': 'icon fonticon'
                    }).inject(element, 'top');
                }

                // Get offsetDimensions
                messages.forEach(function (message) {
                    offsetDimensions += message.getDimensions().outerHeight;
                });

                element.inject(elements.container);

                setTimeout(function () {
                    // Set default style
                    // Rounding is needed for layout problems
                    element.setStyle('top', Math.round(offsetDimensions));

                    // Launch the animation
                    if (options.animate) {
                        element.addClassName('in');
                    }

                    if (options.autoHide) {

                        that.toggleAutoHide(true, element);

                        element.addEvents({
                            mouseover: that.toggleAutoHide.bind(that, false),
                            mouseleave: that.toggleAutoHide.bind(that, true, element)
                        });

                    }
                }, 10);

                this.dispatchEvent('onShowMessage', element);
            },

            /**
             * Returns all the DOM message elements.
             * @return {Element[]} messages - The DOM messages.
             */
            getMessages: function () {
                return this.getContent().getElements('.' + this.name + '-message');
            },

            /**
             * Show and instantiate the messages from the messages queue.
             * @private
             */
            showMessages: function () {

                var that = this,
                    activeMessages = this.getMessages().length;

                if (this.isVisible && activeMessages < this.options.maximumVisibleMessages) {
                    this.messages = this.messages.filter(function (message, i) {
                        if (message) {
                            if (activeMessages + i + 1 > that.options.maximumVisibleMessages) {
                                return true;
                            } else {
                                that.createMessage(message);
                            }
                        }
                    });

                }
            },

            /**
             * Update the messages positions. Called when moved or delete occurs.
             * @private
             */
            updateMessages: function () {

                var messages = this.getMessages(),
                    offsetDimensions = 0;

                messages.forEach(function (message) {

                    var newPosition = offsetDimensions,
                        dimensions = message.getDimensions();

                    offsetDimensions += dimensions.outerHeight;

                    message.setStyles({
                        top: Math.round(newPosition)
                    });
                });

                if (messages.length < this.options.maximumVisibleMessages) {
                    this.showMessages();
                }
            },

            /**
             * Post injection hook to handle the visible option.
             * @private
             */
            onPostInject: function () {
                this.showMessages();

                if (this.options.visible || this.isVisible) {
                    this.isVisible = false;
                    this.show();
                }
            },

            /**
              * Remove a single message from the queue.
              * @param  {Element} message - The message DOM element to remove.
              * @return {this} instance.
              */
            remove: function (message) {

                var that = this;

                function removeMessage (message) {
                    that.dispatchEvent('onRemoveMessage', message);
                    message.destroy();
                    that.updateMessages();
                }

                // Handle the animate option
                if (this.options && this.options.animate) {
                    message.removeClassName('in');
                    setTimeout(removeMessage.bind(this, message), 500);
                } else {
                    removeMessage(message);
                }

                return this;
            },

            /**
             * Main event handler for message click.
             * @param {Event} event - The event.
             * @private
             */
            eventHandler: function (event) {

                var target = Event.getElement(event),
                    cls = this.name + '-message',
                    element;

                // Find the proper node
                element = target.hasClassName(cls) ? target : target.getClosest('.' + cls);

                if (element) {
                    if (this.options.closeOnClick) {
                        this.dispatchEvent('onClick', [event, element]);
                        this.remove(element);
                    } else if (target.hasClassName('close') || target.getParent().hasClassName('close')) {
                        this.remove(element);
                    } else {
                        this.dispatchEvent('onClick', [event, element]);
                    }
                }
            },

            /**
             * Toggle the alert.
             * @return {this} instance.
             */
            toggle: function () {
                return this[this.isVisible ? 'hide' : 'show']();
            },

            /**
             * Show the alert.
             * @return {this} instance.
             */
            show: function () {

                var elements = this.elements;

                // Safe check for destroyed alert
                if (!elements) { return; }

                if (!this.isVisible) {

                    // Update semaphore
                    this.isVisible = true;

                    if (elements.container.isInjected()) {
                        elements.container.setStyle('visibility', 'visible');
                        this.showMessages();
                        this.dispatchEvent('onShow');
                    }
                }

                return this;
            },

            /**
             * Hide the alert.
             * @return {this} instance.
             */
            hide: function () {

                var elements = this.elements;

                // Safe check for destroyed alert
                if (!elements) { return; }

                if (this.isVisible) {

                    // Update semaphore
                    this.isVisible = false;

                    if (elements.container.isInjected()) {
                        elements.container.setStyle('visibility', '');
                        this.dispatchEvent('onHide');
                    }
                }

                return this;
            },

            /**
             * Destroy the alert.
             */
            destroy: function () {
                // To prevent the animation delay when destroying.
                if (this.options) {
                    this.options.animate = false;
                }
                this.hide();
                this._parent();
                this.elements = null;
            }
        };

        return Abstract.extend(Alert);
    });

/**
 * Display a Dropdown with items and sub-menus that the user can click.
 * @module DS/UIKIT/DropdownMenu
 * @extends DS/UIKIT/Dropdown
 * @requires DS/UIKIT/Menu
 */
define('DS/UIKIT/DropdownMenu',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'DS/UIKIT/Dropdown',
        'DS/UIKIT/Menu'
    ],
    function (UWA, Element, Event, Utils, Dropdown, Menu) {

        'use strict';

        var CLS = 'dropdown-menu',
            CLS_HIDDEN = 'dropdown-menu-hidden',
            CLS_ITEM = 'item',
            CLS_ITEM_BACK = 'item-back',
            CLS_SUBITEM = 'item-submenu',
            CLS_ITEM_TEMPLATE = 'item-template',
            ExtendedMenu = Menu.extend({ name: CLS, templateClassname: CLS_ITEM_TEMPLATE });

        function addEvent (evnt, elem, func, capture) {
            if (elem.addEventListener)  // W3C DOM
                elem.addEventListener(evnt, func, capture);
            else if (elem.attachEvent) { // IE DOM
                elem.attachEvent('on' + evnt, func, capture);
            }
        }

        function addEvents (evnts, elem, capture) {
            Object.keys(evnts).forEach(function (evnt) {
                addEvent(evnt, elem, evnts[evnt], capture);
            });
        }

        var checkHeaderDivider = (function () {
            var headerDividerRegex = /^(header|divider|disabled)$/;
            return function (classes) {
                if (!classes) return false;
                var splitted = classes.split(' ');
                for (var i = 0; i < splitted.length; i++) {
                    if (headerDividerRegex.test(splitted[i])) return true;
                }
                return false;
            };
        }());

        /**
         * @lends module:DS/UIKIT/DropdownMenu#
         */
        var DropdownMenu = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default dropdown-menu
             * @constant
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            name: CLS,

            /**
             * The DropdownMenu items.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            items: null,

            /**
             * The DropdownMenu menus.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            menus: null,

            /**
             * The menu where the keyboard navigation currently takes place.
             * @type {Object}
             * @readonly
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            activeMenu: null,

            /**
             * @property {Object} defaultOptions - The default DropdownMenu options.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            defaultOptions: {
                subMenuMaxDepth: 20,
                responsiveMode: true
            },

            /**
             * Display a DropdownMenu with items and submenus that the user can click.
             *
             * @example
             * require(['DS/UIKIT/DropdownMenu'], function (DropdownMenu) {
             *     var myButton = new Button({ value: "Click me" }).inject(body);
             *     var myDropdownMenu = new DropdownMenu({
             *       target: myButton.getContent(),
             *       items: [
             *           { text: "Action" },
             *           { text: "Another action" },
             *           { text: "Something else here" },
             *           {
             *               text : "A sub-menu here ",
             *               items : [
             *                   { text : "Sub-menu Action" },
             *                   { text : "Another sub-menu action" },
             *                   { text : "Something else here" }
             *               ]
             *           },
             *           { className: "divider" },
             *           { text: "Header example", className: "header" },
             *           { text: "Action" }
             *       ]
             *     });
             *  });
             *
             * @param {Object} options                           - The available options.
             *
             * @param {Element} [options.target]                 - Bind the DropdownMenu to the provided target element.
             *                                                     The `target` will be used for positioning, attaching events and inserting the DropdownMenu DOM.
             *                                                     In case of a contextual DropdownMenu, the DropdownMenu will only be shown when a click happens inside the `target` element.
             *                                                     Defaults to `document.body` for contextual.
             * @param {Boolean} [options.bound=true]             - If set to `true`, will attach click events to the `target` option for automatically showing/hiding the dropdown.
             *                                                     Only works if `target` is set. Forced to `true` for contextual DropdownMenu.
             * @param {Boolean} [options.contextual=false]       - Should the DropdownMenu adopt a contextual behavior ? (displaying on right click and positioning under the mouse)
             * @param {String}  [options.position='bottom left'] - If specified, will force the DropdownMenu position to a specific location, default to `bottom left`, instead of
             *                                                     finding the best possible one based on available space.
             * @param {Boolean} [options.responsiveMode=true]    - Activate/desactivate responsive mode.
             * @param {number}  [options.subMenuMaxDepth=20]     - Will not render any submenu having a depth greater than the one provided.
             * @param {Element} [options.renderTo=document.body] - If specified will inject the DropdownMenu inside the provided Element. Default is `document.body`.
             *                                                     with `x` and `y` properties or a function returning the same object structure.
             * @param {Element} [options.renderTo=document.body] - If specified will inject the DropdownMenu inside the provided Element. Default is `document.body`.
             * @param {Boolean} [options.closeOnClick=true]      - If `true` will hide the DropdownMenu when it is clicked. Forced to `true` for contextual Dropdown.
             * @param {Boolean} [options.removeOnHide=true]      - If `true` will remove the DropdownMenu from the DOM after it is hidden. Forced to `true` for contextual Dropdown.
             * @param {String}  [options.className='']              - An optional css class name that you can use for customizing the component easily.
             * @param {Object}  [options.offset]                 - An optional offset to apply to the main DropdownMenu position if you are partially satisfied with the position you get and
             *                                                     do not want to specify an `altPosition`.
             *
             * @param {number} [options.offset.x=0]              - The x offset.
             * @param {number} [options.offset.y=0]              - The y offset.
             *
             * @param {Object} [options.attributes]              - A map of attributes to set to the DropdownMenu container.
             *
             * @param {Object[]} options.items                   - The DropdownMenu items.
             *
             * @param {String}  options.items.text               - The item text. If you want submenu, this will be the submenu item name.
             *                                                     Be sure to specify an `options.items.items` with this item.
             * @param {Array}   [options.items.items]            - In case of sub-menus. This will be an array of `options.items`.
             * @param {Boolean} [options.multiSelect=false]      - In case of sub-menus. True to allow more than one item selection.
             * @param {String}  [options.items.title]            - An optional text that will be shown as a tooltip when hovering this item.
             * @param {String}  [options.items.position='bottom right'] - If both `options.items.items` and `options.items.position`specified.
             *                                                            Will force this new submenu to the given position.
             * @param {Boolean} [options.items.disabled=false]   - Whether to disable this item from start.
             * @param {String}  [options.items.name=text]        - An alternative identifier, useful for finding an item in case of similar items. Defaults to `options.items.text`.
             * @param {String}  [options.items.icon]             - If provided and it is an image file (`toto.jpg`) it will add an <img> with the given path.
             *                                                     Else it will add the icon value as a class on this item element.
             * @param {String}  [options.items.fonticon]         - If provided will prefix the value given by `fonticon-` and add it as a class on this item element.
             * @param {String}  [options.items.className]        - An optional css class name that you can use for customizing this item.
             *                                                     If it is equal to `header` or `divider` > special case.
             * @param {Boolean} [options.items.selectable]       - If provided item will be selectable
             * @param {Boolean} [options.items.selected]         - If provided item will be selectable and selected from start
             * @param {Function} [options.items.handler]         - An optional handler to call when this item is clicked. Will be called after the main `onClick`.
             *                                                     Prefer the main `onClick` event for performance reasons when possible.
             * @param {Object}  [options.items.attributes={}]    - A map of attributes to set to the item container.
             *
             * @param {Object} [options.events]                  - The available events.
             *
             * @param {Function} [options.events.onShow]         - An event dispatched when the DropdownMenu is shown.
             * @param {Function} [options.events.onHide]         - An event dispatched when the DropdownMenu is hidden.
             * @param {Function} [options.events.onClick]        - An event dispatched when the DropdownMenu is clicked.
             * @param {Function} [options.events.onClickOutside] - An event dispatched when a click is received outside of the DropdownMenu.
             * @param {Function} [options.events.onMouseLeave]   - An event dispatched when the cursor leaves the DropdownMenu container.
             *
             * @constructs DropdownMenu
             * @memberof module:DS/UIKIT/DropdownMenu
             * @borrows Dropdown#destroy as #destroy
             * @borrows Dropdown#toggle as #toggle
             * @borrows Dropdown#isVisible as #isVisible
             * @borrows Dropdown#getContent as #getContent
             */
            init: function (options) {

                this.menus = [];
                this.items = [];

                options = options || {};
                if (options.kb == null) options.kb = true;

                this.setupTemplates(options);

                // Will call `buildSkeleton`
                this._parent(options);
            },

            /**
             * Build HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options,
                    mainMenu;

                // Safe check if user called `buildSkeleton` directly
                if (elements.container) {
                    return;
                }

                // Create the dropdown menus and sub-menus
                mainMenu = this.addMenu(options.items, 0, null, options.multiSelect);

                // Attach the main menu container to elements.container
                elements.container = mainMenu.elements.container;
                elements.container.className = this.getClassNames();

                this._handleEvents();
            },

            /**
             * Recursive function for adding menus.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            addMenu: function (items, depth, position, multiSelect) {

                var childMenus = [], indexes = [], currentMenu;

                // Create the current menu
                currentMenu = new ExtendedMenu({
                    kb: this.options.kb,
                    multiSelect: multiSelect,
                    items: items,
                    attributes: this.options.attributes
                });
                currentMenu.position = position || 'bottom right';

                // Store the menu and its items in our reference arrays
                this.menus.push(currentMenu);

                // Recurs if submenu (`item.items`) found
                items.forEach(function (item, index) {
                    if (item.items && depth < this.options.subMenuMaxDepth) {
                        childMenus.push(this.addMenu(item.items, depth + 1, item.position, item.multiSelect));
                        indexes.push(index);
                    }
                }, this);

                this.items = this.items.concat(currentMenu.items);

                // If we found some sub-menus we need to attach them to the current menu
                if (childMenus.length) {

                    childMenus.forEach(function (childMenu, index) {

                        var item = currentMenu.getItem(indexes[index]), nextIcon, divider;

                        // Attach the submenu to the parent item
                        childMenu.inject(item.elements.container);
                        item.elements.container.addClassName(CLS_SUBITEM);
                        divider = UWA.createElement('span', { 'class': 'divider' });
                        nextIcon = UWA.createElement('div', { 'class': 'next-icon' });
                        nextIcon.inject(item.elements.container);
                        divider.inject(nextIcon);
                        UWA.createElement('span', { 'class': 'fonticon fonticon-right-open' }).inject(nextIcon);

                        // Keeping a reference on the parent item controlling the submenu for easy access
                        childMenu.parentItem = item;

                    });
                }

                return currentMenu;
            },

            /**
             * Setup the template used by this DropdownMenu instance.
             *
             * `template.getItem` is called when a click happens inside the select
             * @param  {Object} options - The original options
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            setupTemplates: function (options) {

                this.template = {};

                /**
                 * Called when a click happens inside the select, if the event target
                 * matches your option you should return the parent `item` element
                 *
                 * @param  {Element} element - the event target
                 * @returns {Element}        - Corresponding item element
                 * @private
                 */
                this.template.getItem = function (element) {

                    var parent;

                    if (element.hasClassName(CLS_ITEM)) {
                        return element;
                    } else {
                        parent = element.getParent('.' + CLS_ITEM);
                        return parent;
                    }
                };

                UWA.extend(this.template, options.template);
            },

            /**
             * Add one or many menu item(s).
             * <br><br>
             * Common use cases :
             * <br><br>
             * 1. Add an item in the main menu
             * <br>
             * -> specify at least options.text for the item to add.
             * <br><br>
             * 2. Add items in the main menu
             * <br>
             * -> provide an array as options. For each item, do 1.
             * <br><br>
             * 3. Add a new submenu (parent item and its child) in the main menu
             * -> specify at least options.text for the parent item and options.items for the items to add in its submenu.
             * <br><br>
             * 4. Add an item in a submenu (existing or not) formalized by a given and existing parent item
             * -> specify options.parent for the parent item and at least options.text for the item to add in the submenu.
             * <br><br>
             * 5. Add items in a submenu (existing or not) formalized by a given and existing parent item
             * <br>
             * -> specify options.parent for the parent item and options.items for each item to add in this submenu.
             * <br><br>
             * 6. Add a new submenu in a submenu (existing or not) formalized by a given parent item
             * <br>
             * -> specify options.parent for the parent item, at least options.text for the new submenu parent item and options.items for each item to add in this submenu.
             * <br><br>
             * NB:
             * <br>
             * - Non existing sub-menus for given parents are automatically created.
             * <br>
             * - If the provided parent does not exists, no addition will be performed.
             *
             * @param {Object|Object[]} options                       - Either a single item or an array of items.
             * @param {String}   options.text                         - The item text.
             * @param {Boolean}  [options.disabled=false]             - Whether to disable this item from start.
             * @param {String}   [options.name=text]                  - An alternative identifier, useful for finding an item in case of similar items.
             *                                                          Defaults to `options.items.text`.
             * @param {String}   [options.icon]                       - If provided and it is an image file (`toto.jpg`) it will add an <img> with the given path.
             *                                                          Else it will add the icon value as a class on this item element.
             * @param {String}   [options.fonticon]                   - If provided will prefix the value given by `fonticon-` and add it as a class on
             *                                                          this item element.
             * @param {String}   [options.title]                      - An optional text that will be shown as a tooltip when hovering this item.
             * @param {String}   [options.className]                  - An optional css class name that you can use for customizing this item.
             *                                                          If it is equal to `header` or `divider` > special case.
             * @param {Function} [options.handler]                    - An optional handler to call when this item is clicked.
             *                                                          Will be called after the main `onClick`.
             *                                                          Prefer the main `onClick` event for performance reasons when possible.
             * @param {Boolean}  [options.selectable]                 - If provided item will be selectable
             * @param {Boolean}  [options.selected]                   - If provided item will be selectable and selected from start
             * @param {number|String|Element}  [options.parentItemId] - An item id in case you want to add this menu item to a specific
             *                                                          submenu.
             *                                                          Can be an item Element, an item name or an item index. Defaults to
             *                                                          first dropdown.
             *                                                          Will create the menu with the given options if it does not exist.
             *                                                          If the provided parent does not exists, no addition will be performed.
             * @param {String}   [options.items]                       - In case you want to add items in a submenu.
             *                                                           This is seen as an array of `options`.
             *                                                           If `options.parentItemId`, will add items in the submenu triggered by this parent.
             *                                                           Will automatically create this submenu if not exists yet.
             *                                                           If `options.text`, will create a new parent item for this text, and then add
             *                                                           options.items in a new submenu triggered by this parent item... In first dropdown
             *                                                           by default or in the given options.parent
             *
             * @returns {DropdownMenu}                                  - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            addItem: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that._addItem(option);
                });

                return this;
            },

            /**
             * Return the submenu of an item
             * @param  {String} id      - The item id
             * @returns {DropdownMenu}
             * @private
             * @memberof DropdownMenu#
             */
            _getSubmenuForItem: function (id) {
                var item = this.getItem(id);
                return item && this._getMenuFromParentItem(item.id);
            },

            _addBackItem: function (options) {
                var submenu;

                if (options.parentItemId) {

                    submenu = this._getSubmenuForItem(options.parentItemId);

                    // We're simply adding a back item in this existing submenu
                    submenu && submenu.addBackItem(options);
                }
            },

            /**
             * Add the specified menu item.
             * @param {Object} options - The available options. See `addItem`.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _addItem: function (options) {

                var that = this,
                    item, submenu,
                    parentItem;

                function createSubmenu (item, items, multiSelect) {

                    var newSubmenu = that.addMenu(items, 0, null, multiSelect), divider, nextIcon;
                    // Attach the submenu to the parent item
                    newSubmenu.inject(item.elements.container);
                    item.elements.container.addClassName(CLS_SUBITEM);
                    divider = UWA.createElement('span', { 'class': 'divider' });
                    nextIcon = UWA.createElement('div', { 'class': 'next-icon' });
                    nextIcon.inject(item.elements.container);
                    divider.inject(nextIcon);
                    UWA.createElement('span', { 'class': 'fonticon fonticon-right-open' }).inject(nextIcon);
                    // Keeping a reference on the parent item controlling the submenu for easy access
                    newSubmenu.parentItem = item;
                    // Refresh position for newSubmenu
                    that.updatePosition();

                    return newSubmenu;
                }

                // We're adding something in a provided parentItem
                if (options.parentItemId) {

                    submenu = that._getSubmenuForItem(options.parentItemId);

                    // We're adding something in an existing parentItem that already has a submenu
                    if (submenu) {

                        if (options.items) {

                            // We have an item (options.text or options.name) and items (options.items) in parameter.
                            // We're adding :
                            // - A new item in this existing submenu
                            // - A new submenu from this item containing options.items
                            // (Case 6 from jsdoc for an existing submenu)
                            if (options.text || options.name) {
                                item = submenu._addItem(options);
                                item && this.items.push(item);
                                item && createSubmenu(item, options.items, options.multiSelect);
                            } else {
                                // Else we're simply adding items in this existing submenu (Case 5 from jsdoc for an existing submenu)
                                options.items.forEach(function (item) {
                                    that.items.push(submenu._addItem(item));
                                });
                            }
                        } else {
                            // We're simply adding an item in this existing submenu (Case 4 from jsdoc for an existing submenu)
                            this.items.push(submenu._addItem(options));
                        }

                        // We're adding something in a parentItem that has no submenu yet.
                    } else {

                        parentItem = this.getItem(options.parentItemId);

                        // We're not adding anything because the provided parentItem does not exists.
                        if (!parentItem) { return; }

                        // We have an item (options.text or options.name) and items (options.items) in parameter.
                        // We're adding :
                        // - A new submenu from our existing parentItem,
                        // - A new item inside this submenu
                        // - Another new submenu from this item containing options.items
                        // (Case 6 from jsdoc for a non existing submenu)
                        // NB : addMenu in createSubmenu recursively do the stuff
                        if (options.items && (options.text || options.name)) {
                            submenu = createSubmenu(parentItem, [options], options.multiSelect);

                            // Or, we're adding :
                            // - A new submenu from our existing parentItem,
                            // - One or more (if options.items) items inside this submenu
                            // (Case 4 and 5 from jsdoc for a non existing submenu)
                            // NB : addMenu in createSubmenu recursively do the stuff
                        } else {
                            createSubmenu(parentItem, options.items || [options], options.multiSelect);
                        }
                    }

                    // We're adding something in the main menu (no parentItem provided)
                } else {

                    submenu = this.menus[0];

                    // We're adding a parent item, its submenu and items in the main menu (Case 3 from jsdoc)
                    // NB: this has to be a combination of options.text and options.items because no parent is provided.
                    // So we consider creating a new parentItem with provided options.
                    if (options.items) {
                        parentItem = submenu._addItem(options);
                        parentItem && this.items.push(parentItem);
                        parentItem && createSubmenu(parentItem, options.items, options.multiSelect);
                    } else {
                    // We're simply adding an item in the main menu (Case 1 from jsdoc - Case 2 is a repetition of this)
                        this.items.push(submenu._addItem(options));
                    }
                }
            },

            /**
             * Remove one or many specified item(s) from the menu.
             * @param {number|String|Element} id - Identifier of the item to be removed. Or an array of identifiers to remove.
             *                                     Can be the item Element, the item name, the item index (from `this.items`).
             * @returns {DropdownMenu}           - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            removeItem: function (id) {

                var that = this;

                Utils.splat(id).forEach(function (option) {
                    that._removeItem(option);
                });

                return this;
            },

            /**
             * Removes the specified item from the menu.
             * @param {number|String|Element} id - Identifier of the item to remove. See `removeItem`.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _removeItem: function (id) {

                var that = this,
                    item = this.getItem(id),
                    menu;

                if (!item) return;

                // Check if this item was triggering a menu
                // If it does remove it
                menu = this._getMenuFromParentItem(item.id);

                if (menu) {

                    // Remove the menu items from `this.items`
                    this.items = this.items.filter(function (item) {
                        var itemMenu = that._getMenuFromItem(item.id);

                        // Keep item if is not in a submenu or if not in this one, else remove
                        if (itemMenu && ((!itemMenu.parentItem) || itemMenu.parentItem && itemMenu.parentItem.id !== id)) {
                            return true;
                        } else {
                            menu.removeItem(item);
                            return false;
                        }
                    });

                    // Remove the menu from `this.menus`
                    this.menus.splice(this.menus.indexOf(menu), 1);

                    menu.destroy();
                }

                // Remove the item from its menu items
                menu = this._getMenuFromItem(item.id);
                menu && menu.removeItem(id);

                // Remove item from the dropdown menu items/menus list
                this.items.splice(this.items.indexOf(item), 1);
            },

            /**
             * Update one or many menu item(s).
             *
             * @param {Object|Object[]} options          - Either a single item or an array of items.
             * @param {number|String|Element} options.id - Identifier of the item to update.
             * @param {String} [options.text]            - The new item `text`. (will change item `name` if `name` is not specified)
             * @param {String} [options.disabled]        - The new item `disabled` state.
             * @param {String} [options.name]            - The new item `name`.
             * @param {String} [options.title]           - The new item `title`.
             * @param {String} [options.icon]            - The new item `icon`. If provided and it is an image file (`toto.jpg`) it will add an <img> with the given path.
             *                                             Else it will add the given value for icon as a class for this item.
             * @param {String} [options.fonticon]        - The new item `fonticon`. If provided, will prefix the value given by `fonticon-` and add it as a class on this item.
             * @param {String} [options.className]       - The new `className`. An optional `css` class name that you can use for customizing this item.
             *                                             If it is equal to `header` or `divider` > special case).
             * @param {Function}[options.handler]        - An optional new `handler` to call when this item is clicked. Will be called after the main 'onClick'.
             *                                             Prefer the main `onClick` event for performance reasons.
             * @return {DropdownMenu}                    - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            updateItem: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that._updateItem(option);
                });

                return this;
            },

            /**
             * Updates the specified item from the DropdownMenu.
             * @param {Object} options - The available options. See `updateItem`.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _updateItem: function (options) {

                var menu, item;

                // TODO: update index

                // Need to check if it is an existing item and get its id
                item = this.getItem(options.id);

                if (item) {
                    menu = this._getMenuFromItem(item.id);
                    options.id = item.id;
                    menu && menu.updateItem(options);
                }
            },

            /**
             * Allow an item to be clicked.
             * @param {number|String|Element} id - Identifier of the item to enable.
             * @returns {DropdownMenu}           - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            enableItem: function (id) {
                var item = this.getItem(id);
                item && item.elements.container.removeClassName('disabled');
                return this;
            },

            /**
             * Remove the possibility for an item to be clicked. Giving it a `disabled` state.
             * @param {number|String|Element} id - Identifier of the item to enable.
             * @returns {DropdownMenu}           - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            disableItem: function (id) {
                var item = this.getItem(id);
                item && item.elements.container.addClassName('disabled');
                return this;
            },

            /**
             * Retrieves the specified item from the dropdown menu.
             * @param  {number|String|Element} id - Identifier of the item to retrieve. Can be its index position, id, name or its DOM element.
             * @returns {Object}                  - The item you were looking for
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            getItem: function (id) {

                var i, l, element,
                    item = false;

                // Retrieves the item
                for (i = 0, l = this.items.length; i < l; i++) {
                    item = this.items[i];
                    // If argument is a Node, compare to item's HTML element
                    if (id && id.nodeType) {
                        element = id.hasClassName(CLS_ITEM) ? id : id.getParent();
                        if (item.id === element.id) break;
                        // If argument is a Number, compare to item's index position
                        // If argument is a String, compare to item's unique id or to item name
                    } else if (i === id || item.id === id || item.name === id) {
                        break;
                    }

                    item = false;
                }

                return item;
            },

            /**
             * Update the dropdown position.
             * We do not force the position when space is not big enough.
             * @returns {DropdownMenu} - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            updatePosition: (function () {
                var that, forceResponsive;
                /** Method that find the best position for a menu */
                function findBestPosition (menu) {

                    var x = 'right',
                        y = 'bottom',
                        cls = y + '-' + x,
                        container = menu.getContent(),
                        size = container.getSize(),
                        offsets, parentOffsets;

                    // At each update position, we need to reset the dom.
                    that.options.responsiveMode && that.setNonResponsiveMode(menu);

                    // Remove the previous class name to avoid messing with calculation
                    if (menu._position) {
                        container.removeClassName(menu._position);
                    }

                    // Add default cls for ease of calculation
                    container.addClassName(cls);

                    // Get offset until it reach main dropdown since we have the main dropdown offset inside `that._position.offsets`
                    offsets = container.getPosition(that.getContent());
                    parentOffsets = container.getPosition();

                    // Put to left if right space is not big enough or user specified left and left space is high enough
                    if (that._position.offsets.x + offsets.x + size.width > that._position.viewportWidth || (menu.position && menu.position.indexOf('left') > -1) && that._position.offsets.x + offsets.x - parentOffsets.x - size.width > 0) {
                        x = 'left';
                    }
                    // Put to top if bottom space is not big enough or user specified top and top space is high enough
                    if (that._position.offsets.y + offsets.y + size.height > that._position.viewportHeight + that._position.scrollTop || (menu.position && menu.position.indexOf('top') > -1) && that._position.offsets.y + offsets.y - parentOffsets.y - size.height > that._position.scrollTop) {
                        y = 'top';
                    }

                    // Save it for the next `updatePosition`. This avoid parsing the `className`
                    menu._position = y + '-' + x;

                    // Put the submenu above the parent menu if space is not big enough to put menu and submenu side by side
                    // And return true to force responsive mode. We need this in the case of multiple submenu where all submenu can't be displayed.
                    if (that.options.responsiveMode && ((that._position.offsets.x + offsets.x + size.width > that._position.viewportWidth && that._position.offsets.x - size.width < 0) || forceResponsive)) {
                        that.setResponsiveMode(menu, forceResponsive);
                        if (!forceResponsive) return true;
                    }

                    // Add the proper className if it changed
                    if (cls !== menu._position) {
                        container.removeClassName(cls);
                        container.addClassName(menu._position);
                    }
                }

                return function (event, isResponsive) {
                    that = this;
                    forceResponsive = isResponsive || that.options.forceResponsive;

                    that._parent(event, isResponsive);

                    // Avoid calculation for single or invisible menus
                    if (!that.isVisible || that.menus.length <= 1) return;

                    // This class is needed for calculating sizes
                    that.getContent().addClassName('js-visible');

                    for (var i = 1, l = that.menus.length; i < l; i++) {
                        var breakLoop = findBestPosition(that.menus[i]);
                        if (breakLoop) break;
                    }
                    // This class is needed for calculating sizes
                    that.getContent().removeClassName('js-visible');
                };
            }()),

            /**
             * Change dom to non responsive mode.
             * Put submenu in parent item.
             * @private
             * @memberof DropdownMenu#
             */
            setNonResponsiveMode: function (menu) {
                var parentMenu = menu.parentItem && this._getMenuFromItem(menu.parentItem.id);
                menu.removeBackItem();
                parentMenu && parentMenu.getContent().removeClassName('responsive-menu');
                // check if the submenu is in the parentItem in case of non responsive mode
                if (menu.parentItem && !menu.parentItem.elements.container.getElement('.dropdown-menu')) {
                    parentMenu.elements.container.removeChild(menu.elements.container);
                    menu.inject(menu.parentItem.elements.container);
                }
            },

            /**
             * Change dom to responsive mode.
             * Put submenu in parent menu.
             * @param  {Object} - menu
             * @param  Boolean - force responsive mode
             * @private
             * @memberof DropdownMenu#
             */
            setResponsiveMode: function (menu, forceResponsive) {
                var parentMenu = this._getMenuFromItem(menu.parentItem.id);

                menu._position = 'dropdown-menu-responsive-wrap responsive-menu';
                if (menu._position === 'dropdown-menu-responsive-wrap responsive-menu') {
                    !parentMenu.getContent().hasClassName('responsive-menu') && parentMenu.getContent().addClassName('responsive-menu');
                }

                if (!forceResponsive) {
                    this.updatePosition(null, true);
                } else {
                    parentMenu = this._getMenuFromItem(menu.parentItem.id);
                    // add a title item to manage the hover submenu
                    if (!menu.backItem) {
                        this._addBackItem({ text: menu.parentItem.text, fonticon: 'left-open', className: CLS_ITEM_BACK, index: 1, parentItemId: menu.parentItem.id });
                    }
                    // change dom position for submenu in case of responsive mode
                    if (menu.parentItem.elements.container.getElement('.dropdown-menu')) {
                        menu.parentItem.elements.container.removeChild(menu.elements.container);
                        menu.inject(parentMenu.elements.container);
                    }
                }
            },

            /**
             * Show the DropdownMenu.
             * @param  {Boolean} [silent=false] - Avoid sending `onShow` event if set to true.
             * @returns {DropdownMenu}    - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            show: function (silent, event) {
                var instance;

                // Show only if some items have been added
                if (this.items.length) {
                    instance = this._parent(silent, event);
                    this.activeMenu = this.menus[0];
                    this.activeMenu.keyboardIndex = -1;
                    this.activeMenu.focusIt();
                    this.usingKeyboard = false;
                    return instance;
                }
            },

            /**
             * Hide the DropdownMenu.
             * @param  {Boolean} [silent=false] - Avoid sending `onHide` event if set to true.
             * @returns {DropdownMenu}          - The instance
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            hide: function (silent) {
                this._hideSubmenus();
                return this._parent(silent);
            },

            /**
             * Retrieves the specified menu.
             * @param  {number|String|Element} id - Identifier of the menu to retrieve.
             * @returns {Menu}
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _getMenu: function (id) {

                var i, l,
                    item = false;

                // Retrieves the item
                for (i = 0, l = this.menus.length; i < l; i++) {
                    item = this.menus[i];
                    // If argument is a Node, compare to item's HTML element
                    if (id && id.nodeType && item.elements.container === id) {
                        break;
                        // If argument is a Number, compare to item's index position
                        // If argument is a String, compare to item's unique id or to item name
                    } else if (i === id || item.id === id || item.name === id) {
                        break;
                    }

                    item = false;
                }

                return item;
            },

            /**
             * Retrieves the menu containing the specified item. Pass the item id to avoid DOM comparison.
             * @param  {String} id - Identifier of the item from which we want the parent menu.
             * @returns {Object}
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _getMenuFromItem: function (id) {
                return this.menus.filter(function (menu) {
                    return menu.getItem(id);
                })[0];
            },

            /**
             * Retrieves the menu containing the specified back item. Pass the item id to avoid DOM comparison.
             * @param  {String} id - Identifier of the item from which we want the parent menu.
             * @returns {Object}
             * @private
             * @memberof DropdownMenu#
             */
            _getMenuFromBackItem: function (id) {
                return this.menus.filter(function (menu) {
                    return (menu.backItem && menu.backItem.id === id);
                })[0];
            },

            /**
             * Get the submenu attached to the given item.
             * @param  {String} identifier - id, name or value of the item from which to get the submenu.
             * @return {Menu}
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _getMenuFromParentItem: function (identifier) {
                return this.menus.filter(function (menu) {
                    return (menu.parentItem && (menu.parentItem.id === identifier || menu.parentItem.name === identifier || menu.parentItem.value === identifier));
                })[0];
            },

            /**
             * Hide every visible sub-menus.
             * @param {String} [id] - id of an item. Will take it's parent menu and hide all of it's sub-menus.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _hideSubmenus: (function () {

                var that, menu, item, itemToRemove;

                /** Hide all submenus of a given menu */
                function recursivelyHideMenus (parentMenu) {
                    if (!parentMenu) return ;

                    parentMenu.items.forEach(function (item) {
                        item = item.elements && item.elements.container;
                        if (item && item.hasClassName(CLS_SUBITEM)) {
                            menu = that._getMenuFromParentItem(item.id);
                            item.removeClassName('js-selected');
                            menu && menu._updateKeyboardIndex('reset');
                            menu && menu.hide();
                            recursivelyHideMenus(menu);
                        }
                    });
                }

                return function (id) {
                    that = this;
                    // Avoid calculation for single menus
                    if (this.menus.length <= 1) {
                        // If an item has been js-selected by keyboard
                        this.menus[0].items.forEach(function (item) {
                            item = item.elements && item.elements.container;
                            item.removeClassName('js-selected');
                        });
                        return;
                    }

                    if (id) {
                        recursivelyHideMenus(that._getMenuFromItem(id));
                    } else {
                        this.menus[0].elements.container.removeClassName(CLS_HIDDEN);
                        // Starts at one to avoid hidding main menu
                        for (var i = 1, l = this.menus.length; i < l; i++) {
                            menu = this.menus[i];
                            // Remove the js class name of the parent
                            item = menu.parentItem && this.getItem(menu.parentItem.id);
                            item && item.elements.container.removeClassName('js-selected');
                            // Manage submenu displayed hover parent menu
                            itemToRemove = menu.backItem;
                            if (itemToRemove && itemToRemove.elements.container.hasClassName(CLS_ITEM_BACK)) {
                                this._hideResponsiveMenu(menu, this._getMenuFromItem(menu.parentItem.id));
                            } else {
                                // Hide the current menu
                                menu.hide();
                            }

                        }
                    }
                };
            }()),

            /**
             * Handle an hover / keyboard selection of an item.
             * @param {Object} item - The DOM of the item to select
             * @param {Boolean} [isNextIconClicked] - true if the user click on next icon and not on the item body
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             * @private
             */
            _handleItemSelection: function (item, isNextIconClicked) {

                var menu, parentMenu;

                // Stop current timeout on menu leave if exists
                this.timeoutId && clearTimeout(this.timeoutId);

                if (item.hasClassName(CLS_SUBITEM) || item.hasClassName(CLS_ITEM_TEMPLATE)) {
                    menu = this._getMenuFromParentItem(item.id);

                    // Only try to hide/show if the menu is not already visible
                    if (menu && !menu.isVisible) {
                        // Try to hide all menus at the same level of the new submenu
                        this._hideSubmenus(item.id);

                        // Once all are hidden, show the one under mouse
                        menu = this._getMenuFromParentItem(item.id);
                        !isNextIconClicked && item.addClassName('js-selected');
                        menu && menu.show();
                        parentMenu = this._getMenuFromItem(menu.parentItem.id);
                        if (menu.elements.container.hasClassName('dropdown-menu-responsive-wrap')) {
                            parentMenu.elements.container.addClassName(CLS_HIDDEN);
                        }
                        this.activeMenu = menu;
                    }
                } else if (item.hasClassName(CLS_ITEM_BACK)) {
                    menu = this._getMenuFromBackItem(item.id);
                    parentMenu = this._getMenuFromItem(menu.parentItem.id);
                    this._hideResponsiveMenu(menu, parentMenu);
                } else if (item.hasClassName(CLS_ITEM)) {
                    this._hideSubmenus(item.id);
                }
            },

            /**
             * Hide the submenu and display the parent menu
             * @param  {Object} menu - The current submenu to hide
             * @param  {Object} parentMenu - The parent menu to display
             * @private
             * @memberof DropdownMenu#
             */
            _hideResponsiveMenu: function (menu, parentMenu) {
                menu && menu.hide();
                // Remove item back when we close the submenu
                parentMenu && parentMenu.elements.container.removeClassName(CLS_HIDDEN);
                this.activeMenu = parentMenu;
            },

            /**
             * Handle a click / enter press on an item.
             * @param  {DOMEvent} event - The incoming event
             * @param  {Object} [item]   - The item if already known
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _handleItemClick: function (event, item) {

                var target = Event.getElement(event),
                    isTouch = UWA.Utils.Client.Features.touchEvents,
                    preventClosing = false,
                    isNextIcon = target.classList.contains('next-icon') || target.parentElement.classList.contains('next-icon'),
                    isItemToBack, isResponsiveDesktop, menu, isHiddenMenu;

                if (!item) {

                    item = this.template.getItem(target);
                    // Break if template does not retrieve the item
                    if (!item) { return; }
                    isItemToBack = item.classList.contains(CLS_ITEM_BACK);
                    if (isItemToBack) {
                        menu = this._getMenuFromBackItem(item.id ? item.id : item);
                        item = menu.backItem;
                    } else {
                        item = this.getItem(item.id ? item.id : item);
                    }
                }

                if (item && !checkHeaderDivider(item.elements.container.className)) {

                    if (!menu) {
                        menu = this._getMenuFromParentItem(item.id) || this._getMenuFromItem(item.id);
                    }

                    isHiddenMenu = menu && menu._position && menu._position.contains('dropdown-menu-responsive-wrap');
                    isResponsiveDesktop = menu && menu.getContent().hasClassName('responsive-menu');

                    if (item.selectable) {
                        if (isResponsiveDesktop && (!target.classList.contains('next-icon') && !target.parentElement.classList.contains('next-icon'))
                        || !isResponsiveDesktop) {
                            item.toggleSelection();
                        }
                    }
                    // Open submenu if some on touch devices
                    // or close submenu on click if it's a back item
                    if (isTouch || isItemToBack || isHiddenMenu) {
                        if ((isItemToBack && target.classList.contains('fonticon'))
                        || (isResponsiveDesktop && isNextIcon)
                        || (!isItemToBack && !isResponsiveDesktop)) {
                            this._handleItemSelection(item.elements.container, isNextIcon);
                        }
                        preventClosing = (item.elements.container.hasClassName(CLS_SUBITEM) && isNextIcon) || isItemToBack;
                    }

                    this.dispatchEvent('onClick', [event, item, preventClosing], this);

                    // Call the item handler if it was provided
                    if (UWA.is(item.handler, 'function')) {
                        item.handler.call(this, event);
                    }

                }
            },

            /**
             * Attach main dropdown events.
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _handleEvents: function () {

                var that = this,
                    options = this.options;

                this.events.container = {

                    // The mouse click event handler. Dispatches `onClick` and call the item clicked handler.
                    click: function (event) {
                        that._handleItemClick(event);
                    },

                    // The mouseleave event handler. Simply dispatches `onMouseLeave`
                    mouseleave: this.dispatchEvent.bind(this, 'onMouseLeave'),

                    // The mouseleave event handler. Handles the visibility logic for the Menus
                    mouseover: function (event) {
                        var target = Event.getElement(event),
                            menu = that._getMenuFromParentItem(target.id),
                            isResponsiveDesktop, item;
                        // In responsive mode, actions on mouseout are disabled
                        if (!target.hasClassName(CLS_ITEM_BACK) && !(menu && menu._position.contains('dropdown-menu-responsive-wrap'))) {
                            !that.usingKeyboard && that._handleItemSelection(target);
                        }
                        if (that.options.responsiveMode) {
                            item = target.parentElement.hasClassName('next-icon') ? target.parentElement.parentElement : target.parentElement;
                            menu = that._getMenuFromItem(item.id);
                            item = menu && menu.getItem(item.id);
                            isResponsiveDesktop = menu && menu.getContent().hasClassName('responsive-menu');
                            if (item) {
                                if (isResponsiveDesktop
                                  && (target.classList.contains('next-icon') || target.parentElement.classList.contains('next-icon'))
                                  && !item.elements.container.classList.contains('selected')) {
                                    item.elements.container.addClassName('js-not-selectable');
                                    item.elements.container.removeClassName('js-selected');
                                }
                            }
                        }
                    },

                    // The mouseout event handler
                    mouseout: function (event) {
                        var target = Event.getElement(event),
                            menu = target && that._getMenuFromParentItem(target.id),
                            item, isResponsiveDesktop;
                        // In responsive mode, actions on mouseout are disabled
                        if (!that.usingKeyboard && !target.hasClassName(CLS_ITEM_BACK) && !(menu && menu._position.contains('dropdown-menu-responsive-wrap')) && !(that.elements.container.classList.contains('dropdown-menu-hidden'))) {
                            that.timeoutId = setTimeout(that._hideSubmenus.bind(that), 500);
                        }

                        if (that.options.responsiveMode) {
                            item = target.parentElement.hasClassName('next-icon') ? target.parentElement.parentElement : target.parentElement;
                            menu = that._getMenuFromItem(item.id);
                            item = menu && menu.getItem(item.id);
                            isResponsiveDesktop = menu && menu.getContent().hasClassName('responsive-menu');
                            if (item) {
                                if (isResponsiveDesktop && (target.classList.contains('next-icon') || target.parentElement.classList.contains('next-icon'))) {
                                    item.elements.container.removeClassName('js-not-selectable');
                                }
                            }
                        }
                    }
                };

                if (options.kb) {
                    this.events.container.keydown = function (event) {
                        var activeItem,
                            parentMenu,
                            activeMenu,
                            isResponsiveMode;

                        that.usingKeyboard = true;

                        function closeMenu () {
                            that.activeMenu.hide();
                            isResponsiveMode = that.activeMenu.getContent().hasClassName('dropdown-menu-responsive-wrap');
                            parentMenu = that.activeMenu.parentItem && that._getMenuFromItem(that.activeMenu.parentItem.id);
                            if (parentMenu) {
                                if (isResponsiveMode) {
                                    that._hideResponsiveMenu(that.activeMenu, parentMenu);
                                }
                                that.activeMenu._updateKeyboardIndex();
                                that.activeMenu = parentMenu;
                                that.activeMenu.focusIt();
                            }
                        }

                        function openSubmenu () {
                            activeItem = that._getActiveItem();
                            if (activeItem) {
                                activeItem = activeItem.elements.container;
                                that._handleItemSelection(activeItem);
                            }
                            that.activeMenu._updateKeyboardIndex();
                        }

                        switch (event.which) {

                            case 13:
                                // Enter : choose selected item if some, then close the menu
                                activeItem = that._getActiveItem();
                                if (activeItem) {
                                    that._handleItemClick(event, that._getActiveItem());
                                }
                                if (that.options.closeOnClick) {
                                    that.hide();
                                    options.target.focus();
                                }
                                UWA.Event.preventDefault(event);
                                break;

                            case 27:
                                // Escape : close the menu
                                that.hide();
                                options.target.focus();
                                UWA.Event.preventDefault(event);
                                break;

                            case 37:
                                // Left : close current submenu if it is on right, else open submenu if some
                                activeMenu = that.activeMenu.elements.container;
                                activeItem = that._getActiveItem();
                                if (activeMenu.hasClassName('bottom-left') || activeMenu.hasClassName('top-left')) {
                                    activeItem && activeItem.elements.container.hasClassName('item-submenu') && openSubmenu();
                                } else {
                                    closeMenu();
                                }
                                UWA.Event.preventDefault(event);
                                break;

                            case 38:
                                // Up : go up in current menu
                                that.activeMenu._updateKeyboardIndex('up');
                                UWA.Event.preventDefault(event);
                                break;

                            case 39:
                                // Right : close current submenu if it is on left, else open submenu if some
                                activeMenu = that.activeMenu.elements.container;
                                activeItem = that._getActiveItem();
                                if (activeMenu.hasClassName('bottom-left') || activeMenu.hasClassName('top-left')) {
                                    closeMenu();
                                } else {
                                    activeItem && activeItem.elements.container.hasClassName('item-submenu') && openSubmenu();
                                }
                                UWA.Event.preventDefault(event);
                                break;

                            case 40:
                                // Down : go down in current menu
                                that.activeMenu._updateKeyboardIndex('down');
                                UWA.Event.preventDefault(event);
                                break;

                            default:
                                // ¯\_(ツ)_/¯
                                UWA.Event.preventDefault(event);
                                break;

                        }
                    };
                }

                this.elements.container.addEvents(this.events.container);

                // Attach mouse events for contextual Dropdown
                if (options.contextual) {

                    // Click event on the target to update the Dropdown position
                    this.events.target = {
                        mousedown: function (event) {

                            var target = Event.getElement(event),
                                isRightClick = UWA.Event.whichButton(event) === 2;

                            // updates position if the click happened outside of the container
                            if (!target.isInjected(this.elements.container) && target !== this.elements.container) {

                                if (isRightClick && this.isVisible) {
                                    this.updatePosition(event);
                                }
                            }
                        }.bind(this),
                        // Blocks the contextual menu and display our custom one
                        contextmenu: function (event) {
                            this.show(true, event);
                            Event.stop(event);
                        }.bind(this)
                    };

                    // Add the contextual events
                    addEvents(this.events.target, options.target, true);
                } else if (options.bound) {
                    // If bound will attach a click event for toggling the Dropdown visibility
                    this.events.target = { click: this.toggle.bind(this) };
                    addEvents(this.events.target, options.target, true);
                }
            },

            /**
             * Provide the currently selected item in a keyboard navigation context.
             * @returns {Object} - The keyboard-selected item
             * @private
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            _getActiveItem: function () {

                var index = this.activeMenu.keyboardIndex;

                if (this.activeMenu && index >= 0) {
                    return this.activeMenu.getItem(index);
                } else {
                    return false;
                }

            },

            /**
             * Getter for selected items
             * @returns {Object[]} - The list of selected items in the menu, empty array if none
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            getSelectedItems: function () {

                var selectedItems = [];

                if (this.items) {
                    selectedItems = this.items.filter(function (item) {
                        return item.selected;
                    });
                }

                return selectedItems;

            },

            /**
             * Check if provided item is currently selected
             *
             * @param  {Object}  id - item identifier
             * @returns {Boolean}   - The selected state of an element
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            isSelected: function (id) {

                var item = this.getItem(id);

                return item && item.selected;

            },

            /**
             * Toggle the selected state of a provided item
             * @param  {Object} item The item object
             * @memberof module:DS/UIKIT/DropdownMenu.DropdownMenu#
             */
            toggleSelection: function (item) {
                item && item.selectable && item.toggleSelection();
            }
        };

        return Dropdown.extend(DropdownMenu);
    });

/**
 * A dropdown that can be displayed both in a native context or in a web context.
 * @module DS/UIKIT/Native/Dropdown
 * @requires DS/CefCommunication/CefCommunication
 * @extends DS/UIKIT/DropdownMenu
 */
define('DS/UIKIT/Native/Dropdown', [
    'UWA/Event',
    'UWA/Utils',
    'DS/UIKIT/DropdownMenu',
    'DS/CefCommunication/CefCommunication'
],
function (Event, Utils, DropdownMenu, CefCommunication) {

    'use strict';

    var TYPES = ['command', 'checkbox', 'radio', 'separator'],
        dropdowns = [];

    function globalHandler (eventName) {
        return function (data) {
            if (!data.menuId) return;
            CefCommunication.dispatchEvent(eventName + '-' + data.menuId, data);
        };
    }

    // Only add global handler once for all dropdowns
    if (!CefCommunication.hasEvent('exitMenu')) {
        CefCommunication.addNativeEventListener('exitMenu', globalHandler('exitMenu'));
        CefCommunication.addNativeEventListener('commandFacet', globalHandler('commandFacet'));
    }

    /**
     * @lends module:DS/UIKIT/Native/Dropdown.NativeDropdown#
     */
    var NativeDropdown = {

        /**
         * The component id.
         * @type {String}
         * @readonly
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         */
        id: '',

        /**
         * @property {Object} - The component default options
         * @private
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         */
        defaultOptions: {
            bound: true
        },

        /**
         * A dropdown that can be displayed both in a native context or in a web context.
         * @example
         * var dd = new NativeDropdown({
         *     target: myButton.getContent(),
         *     items: [
         *         { text: 'Item 1' },
         *         { text: 'Item 2' },
         *         { text: 'Sub menu 1',
         *           items: [
         *             { text: 'Sub menu 1 - Item 1' },
         *             { text: 'Sub menu 1 - Item 2' },
         *             { text: 'Sub menu 1 - Item 3' }
         *           ]
         *         },
         *         { text: 'Item 3' }
         *     ]
         * });
         *
         * @param {Object}                         options - The available options.
         * @param {String}                    [options.id] - An optional id for your main menu.
         * @param {Element}               [options.target] - Bind the dropdown to the provided target element.
         *                                                   The `target` will be used for positioning, attaching events and inserting the dropdown DOM.
         *                                                   In case of a contextual dropdown, the dropdown will only be shown when a click happens inside the `target` element.
         *                                                   Defaults to `document.body` for contextual dropdown.
         * @param {Boolean}     [options.contextual=false] - If `true` the dropdown will be contextual (right click).
         * @param {Object[]}                 options.items - The dropdown items.
         *
         * @param {String}              options.items.text - The item text.
         * @param {String}              [options.items.id] - An optional item id for this item.
         * @param {Object[]}         [options.items.items] - An optional sub menu `items`.
         * @param {Boolean} [options.items.disabled=false] - If `true` this item will be disabled.
         * @param {String}            [options.items.icon] - An optional image. Should be an absolute url.
         * @param {String}           [options.items.title] - An optional tooltip text.
         * @param {String}            [options.items.data] - An optional data string to pass along the native.
         * @param {String}  [options.items.type='command'] - An optional type for this item. Only `command` for now.
         * @param {Function}       [options.items.handler] - An optional handler to call when this item is clicked.
         * @param {String}   [options.items.nativeHandler] - An optional handler to call when this item is clicked in a CEF context.
         *                                                   If both `handler` and `nativeHandler` are defined, only one will be called given the context.
         * @constructs NativeDropdown
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         */
        init: function (options) {
            options || (options = {});

            this.id = options.id || 'mnu-' + Utils.getUUID().substr(0, 6);
            this._parent(options);
            this.options.contextual && dropdowns.push(this);
        },

        /**
         * Shows the dropdown. As simple as that.
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         */
        show: function (silent, event) {
            // Hide any previous contextual menus
            if (this.options.contextual && dropdowns.length > 0) {
                dropdowns.forEach(function (menu) { menu.hide(); });
            }

            this._parent(silent, event);

            if (CefCommunication.isAvailable()) {
                this.elements.container.setStyle('display', 'none');
                CefCommunication.dispatchEventToNative('displayMenu', this.getNativeModel());
            }
        },

        /**
         * Hide the dropdown
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         */
        hide: function (silent) {
            this._parent(silent);
            if (CefCommunication.isAvailable()) {
                this.elements.container.setStyle('display', '');
            }
        },

        /**
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         * @private
         */
        _handleEvents: function () {

            this._parent();

            // Handle the logic for when a click event is received
            // from a web event: someone manually triggered a click
            // from the native: someone clicked a native menu item
            // and since no handler was attached natively it is calling the js
            function handleClick (event) {
                var target = Event.getElement(event), item;

                // Handle the case where the native called us with an item id
                if (!target && event.menuId && event.id) target = event.id;
                if (!target) return;

                // Find the proper node and get the clicked menu
                item = this.getItem(target);

                if (item) {
                    this.dispatchEvent('onClick', [event, item], this);

                    // Call the item callback if it was provided
                    if (CefCommunication.isAvailable() && item.nativeHandler) {
                        item.nativeHandler.call(this, event);
                    } else if (typeof item.handler === 'function') {
                        item.handler.call(this, event);
                    }
                    this.hide();
                }
            }

            // Remove unnecessary click event inherited from parent and attach new one
            this.elements.container.removeEvent('click', this.events.container.click);
            this.elements.container.addEvent('click', handleClick.bind(this));

            if (CefCommunication.isAvailable()) {
                CefCommunication.addNativeEventListener('exitMenu-' + this.id, this.hide.bind(this));
                CefCommunication.addNativeEventListener('commandFacet-' + this.id, handleClick.bind(this));
            }
        },

        /**
         * Method to get the native model
         * @returns {Object}
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         * @private
         */
        getNativeModel: function () {
            if (!this.menus.length) return;

            var model = {
                menuId: this.id,
                children: []
            };

            function recursivelyCreateModel (items, newItems) {
                var newItem, parent;

                items.forEach(function (item) {
                    newItem = {};
                    newItem.id = item.id;
                    newItem.type = TYPES.indexOf(item.type) !== -1 ? item.type : TYPES[0];
                    newItem.label = item.text;

                    item.data && (newItem.catcommand = item.data);
                    item.icon && (newItem.icon = item.icon);
                    item.disabled != null && (newItem.disabled = item.disabled);
                    item.title && (newItem.title = item.title);

                    // Only recurs for type command
                    if (item.items && newItem.type === 'command') {
                        parent = this._getMenuFromParentItem(item.id);
                        newItem.children = [];
                        recursivelyCreateModel.call(this, parent.items, newItem.children);
                    }

                    newItems.push(newItem);
                }.bind(this));
            }

            recursivelyCreateModel.call(this, this.menus[0].items, model.children);
            return model;
        },

        /**
         * Remove the dropdown from memory and unbind all events.
         * Should not be used afterwards.
         * @memberof module:DS/UIKIT/Native/Dropdown.NativeDropdown#
         */
        destroy: function () {
            CefCommunication.removeNativeEventListener('exitMenu-' + this.id);
            CefCommunication.removeNativeEventListener('commandFacet-' + this.id);
            if (this.options.contextual && dropdowns.length > -1) {
                this.options.contextual && dropdowns.splice(dropdowns.indexOf(this), 1);
            }
            this._parent();
        }
    };

    return DropdownMenu.extend(NativeDropdown);
});

/**
 * A row of icons triggering actions.
 * @module DS/UIKIT/IconBar
 * @requires DS/UIKIT/Menu
 * @requires DS/UIKIT/Tooltip
 * @requires DS/UIKIT/DropdownMenu
 */
define('DS/UIKIT/Iconbar',
    [
        'UWA/Core',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Menu',
        'DS/UIKIT/Tooltip',
        'DS/UIKIT/DropdownMenu'

    ], function (UWA, Event, Utils, Abstract, Menu, Tooltip, DropdownMenu) {

        'use strict';

        var isTouch = UWA.Utils.Client.Features.touchEvents;

        function debounce (func, wait, immediate) {
            var timeout;
            return function () {
                var that = this, args = arguments, callNow,
                    later = function () {
                        timeout = null;
                        if (!immediate) func.apply(that, args);
                    };
                callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(that, args);
            };
        }

        var isDivider = (function () {
            var r = /^(divider)$/;
            return function (classes) {
                var splitted, i;
                if (!classes) return false;
                splitted = classes.split(' ');
                for (i = 0; i < splitted.length; i++) {
                    if (r.test(splitted[i])) return true;
                }
                return false;
            };
        }());

        var IconbarMenu = Menu.extend({ name: 'iconbar-items' });
        // It could happen that when showing the overflow menu, the overflow trigger
        // overflows. As a consequence the dropdown menu will not be at a proper place.
        // that is because when the dropdown menu is injected into the body a scroll bar appears
        // and changes the visibility of the overflow trigger.
        var OverflowDropdown = DropdownMenu.extend({
            show: function () {
                document.body.style.overflow = 'hidden';
                this._parent();
                document.body.style.overflow = 'auto';
            }
        });

        /** @lends module:DS/UIKIT/IconBar.IconBar# */
        var Iconbar = Abstract.extend({
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            name: 'iconbar',

            /**
             * The visible list of items
             * @type {Menu}
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            menu: null,

            /**
             * The dropdown menu containing items that are no longer visible
             * @type {DropdownMenu}
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            overflowMenu: null,

            /**
             * The overflowMenu target
             * @type {HTMLElement}
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            overflowMenuTrigger: null,

            /**
             * A row of icons triggering actions.
             * @example
             *
             *  require(['DS/UIKIT/Iconbar'], function (Iconbar) {
             *      'use strict';
             *      var iconbar = new Iconbar({
             *          renderTo: document.body
             *      });
             *      // → create an empty Iconbar and append it to the document body.
             *
             *      var iconbar = new Iconbar({
             *         renderTo: document.body,
             *         items: [{
             *             fonticon: 'note',
             *             text: 'Listen to some music'
             *         }, {
             *             fonticon: 'camera',
             *             text: 'Take a picture'
             *         }]
             *      });
             *      // → Create a Iconbar with two icons.
             *
             *      var iconbar = new Iconbar({
             *          renderTo: document.getElementById('my-container'),
             *          items: [{
             *              fonticon: 'note',
             *              text: 'Listen to some music',
             *              innerComponent: {
             *                  type: 'dropdownmenu',
             *                  options: {
             *                      items: [{
             *                          fonticon: 'chart-bar',
             *                          text: 'Trending songs',
             *                          selectable: true
             *                      }, {
             *                          fonticon: 'play',
             *                          text: 'Play a song',
             *                          selectable: true,
             *                          handler: function () {
             *                             console.log('Now playing: Some cool song');
             *                          }
             *                      }]
             *                  }
             *              }
             *          }]
             *      });
             *      // → Create an Iconbar and renders it to the element
             *      // with the id 'my-container'.
             *      // When the icon is clicked, an dropdown menu with two other icons
             *      // is displayed.
             *
             *  });
             *
             * @param {Object}                         options  -  The available options to create a new Iconbar.
             * @param {Element}             [options.renderTo]  -  Where to display the Iconbar.
             * @param {String}             [options.className]  -  An additional CSS class to apply to the Iconbar.
             * @param {Object[]}                 options.items  -  The Iconbar items.
             * @param {String}            [options.items.text]  -  A text to display when hovering the icon. If this is not provided, then no tooltip will be displayed and
             *                                                     no text will be shown for this item in the overflow menu.
             * @param {String}          options.items.fonticon  -  Will prefix the provided value by `fonticon-` and add it as a class on this item element.
             * @param {String}  [options.items.tooltipTrigger]  -  How the tooltip should be triggered for this item.
             *                                                     This will override the iconbar `tooltipsTrigger` option.
             * @param {Object}         [options.items.content]  -  Open a component when the item is clicked.
             * @param {String}    [options.items.content.type]  -  The type of the component to display.
             *                                                     Choose between `icondropdown`, `dropdownmenu` or `dropdown`.
             * @param {Object} [options.items.content.options]  -  The options to create to component.
             *                                                     Please refer to the appropriate documentation.
             * @param {String}       [options.tooltipsTrigger]  -  How an item tooltip display should be triggered.
             *                                                     Please refer to the tooltip trigger documentation.
             *
             * @param {Object}                [options.events]  -  The available events.
             *
             * @param {Function}       [options.events.onShow]  -  An event dispatched when the Iconbar is shown.
             * @param {Function}       [options.events.onHide]  -  An event dispatched when the Iconbar is hidden.
             * @param {Function}      [options.events.onClick]  -  An event dispatched when the Iconbar is clicked.
             *
             * @returns {Iconbar}                               -  Your new Iconbar component.
             * @constructs IconBar
             * @memberof module:DS/UIKIT/IconBar
             */
            init: function (options) {
                var that = this;
                this._parent(options);
                this.buildSkeleton();
                this.handleEvents();

                this.show();

                // handle overflow issue for iconbar not inserted into the DOM via the renderTo option
                if (window.MutationObserver) {
                    this._injectionObserver = new MutationObserver(function (mutations) {
                        // check if any inserted node contains the iconbar container
                        var hasComponentBeenInjected = mutations.some(function (mutation) {
                            // handle the case where the content is injected via a document fragment
                            return that.isInjected() || Array.prototype.indexOf.call(mutation.addedNodes, that.elements.container) !== -1;
                        });
                        hasComponentBeenInjected && that.show();
                    });
                    // since we do not have the information of which node is the component parent
                    // the closest one is the document body, unfortunately
                    this._injectionObserver.observe(document.body, { childList: true, subtree: true });
                }
            },

            /**
             * Build the HTML
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            buildSkeleton: function () {
                var elements = this.elements,
                    options = this.options;

                if (elements.container) return;

                this.menu = new IconbarMenu({});

                this.addItem(options.items); // triggers the overflowMenu creation

                elements.container = this.menu.elements.container;
                elements.container.className = this.getClassNames();

                if (options.renderTo && options.renderTo.nodeType === 1) {
                    elements.container.inject(options.renderTo);
                    delete options.renderTo;
                }
            },

            /**
             * Build the content of the menu which will be displayed
             * when there is not enough room to display the full options.
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            buildOverflowMenu: function () {
                var menuItems = [],
                    dropdownItemOptions,
                    shouldAddToOverflow;

                if (!this.overflowMenuTrigger) {
                    // Create the overflow menu trigger element
                    this.overflowMenuTrigger = UWA.createElement('li', {
                        'class': this.name + '-overflow-menu-trigger item',
                        html: {
                            tag: 'span',
                            'class': 'fonticon fonticon-menu-dot'
                        }
                    });
                }

                // if there is an existing overflow menu, destroy it an rebuild it
                this.overflowMenu && this.overflowMenu.destroy();
                this.overflowMenu = null;

                this.menu.items.forEach(function (item) {
                    // Items with a Dropdown content should not be added in the overflow menu
                    if (item.content && item.content.type === 'dropdown') return;

                    shouldAddToOverflow = true;
                    dropdownItemOptions = {
                        className: (item.id + ' ' + (item.className ? item.className : '')).trim(),
                        fonticon: item.fonticon,
                        text: item.text,
                        handler: item.handler
                    };

                    if (item.content && item.content.options.items && item.content.type !== 'icondropdown') {
                        dropdownItemOptions.items = item.content.options.items.map(function (itm) {
                            itm.className = (item.id + ' ' + (itm.className ? itm.className : '')).trim();
                            return itm;
                        });
                    } else if (item.content && item.content.type === 'icondropdown') {
                        // elements from an icondropdown should not be placed in submemus
                        shouldAddToOverflow = false;
                        item.content.options.items && item.content.options.items.forEach(function (itm) {
                            menuItems.push({
                                className: (item.id + ' ' + (itm.className ? itm.className : '')).trim(),
                                fonticon: itm.fonticon,
                                icon: itm.icon,
                                handler: itm.handler,
                                text: itm.description
                            });
                        });
                    }

                    shouldAddToOverflow &&  menuItems.push(dropdownItemOptions);
                });

                this.overflowMenu = new OverflowDropdown({
                    items: menuItems,
                    target: this.overflowMenuTrigger
                });
            },

            /**
             * Retrieves the specified item from the iconbar.
             * @param  {number|String|Element} id - Identifier of the item to retrieve. Can be its index position, id, name or its DOM element.
             * @returns {Object}                  - The item you were looking for
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            getItem: function (id) {

                var i, l, element,
                    item = false;

                // Retrieves the item
                for (i = 0, l = this.menu.items.length; i < l; i++) {
                    item = this.menu.items[i];
                    // If argument is a Node, compare to item's HTML element
                    if (id && id.nodeType) {
                        element = id.hasClassName('item') ? id : id.getParent();
                        if (item.id === element.id) break;
                    // If argument is a number, compare to item's index position
                    // If argument is a String, compare to item's unique id or to item name
                    } else if (i === id || item.id === id || item.name === id) {
                        break;
                    }

                    item = false;
                }

                return item;
            },

            /**
             * Attach main iconbar events.
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            handleEvents: function () {

                this.events = {
                    container: {
                        click: function (evt) {
                            var target = Event.getElement(evt),
                                item = this.getItem(target);

                            if (item) {
                                if (item.content) window.requestAnimationFrame ? window.requestAnimationFrame(this.displayContent.bind(this, item)) : this.displayContent(item);
                                if (item.tooltip && item.tooltip.isVisible && !isTouch) item.tooltip.hide();

                                this.dispatchEvent('onClick', [evt, item], this);

                                // Call the item handler if it was provided
                                if (typeof item.handler === 'function') {
                                    item.handler.call(this, evt, item);
                                }
                            }
                        }.bind(this)
                    }
                };

                this.elements.container.addEvents(this.events.container);
                this.events.window = { resize: debounce(this.resize, 100).bind(this) };
                window.addEventListener('resize', this.events.window.resize);
            },

            /**
             * Add an item to the icon bar.
             * @param {Object} options - The item's options. See the constructor for the available options.
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            addItem: function (options) {

                Utils.splat(options).forEach(function (option) { this._addItem(option); }, this);

                // rebuild the overflow menu
                this.buildOverflowMenu();

                return this;
            },

            /**
             * Add the specified menu item.
             * @param {Object} options - The available options.
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            _addItem: function (options) {

                var item = this.menu._addItem(options);

                // The content option was previously named innerComponent
                // therefore assure compatibility.
                item.content = item.innerComponent || item.content;

                if (!isDivider(options.className) && item.text) {
                    // When an icon is hovered a tooltip pops to display
                    // additionnal information regarding the possible actions
                    item.tooltip = new Tooltip({
                        target: item.elements.container,
                        body: item.text,
                        trigger: item.tooltipTrigger || this.options.tooltipsTrigger || 'hover focus'
                    });

                    // Remove extra DOM added by the menu component
                    item.elements.container.getElement('.item-text').remove();
                }
            },

            /**
             * Return an array of items which are overflowing within main iconbar container
             * @return {Array}
             * @private
             */
            getOverflowingItems: function () {
                var cRect = this.elements.container.getBoundingClientRect();
                return this.menu.items.filter(function (item) {
                    var iRect = item.elements.container.getBoundingClientRect();
                    return (iRect.top + iRect.height > cRect.bottom) || (iRect.left + iRect.width > cRect.right);
                });
            },

            /**
             * Specifies if given element is overflowing within main iconbar container
             * @return {Boolean}
             * @private
             */
            isElementOverflowing: function (element) {
                var cRect = this.elements.container.getBoundingClientRect();
                var iRect = element.getBoundingClientRect();
                return (iRect.top + iRect.height > cRect.bottom) || (iRect.left + iRect.width > cRect.right);
            },

            /**
             * Has the iconbar has been injected or not into the DOM.
             * @return {Boolean}
             * @private
             */
            isInjected: function () {
                if (!this.elements) return;
                if (!this.elements.container) return;
                return this.elements.container.isInjected();
            },

            /**
             * Make the Iconbar responsive.
             * When there is not enough space to display the content inside
             * the container, then the items not visible are placed inside a
             * dropdown menu.
             * @private
             * @method
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            resize: (function () {

                function toggleOverflowMenuItemVisibility (classes) {
                    var isItemToShow;

                    this.overflowMenu.items.forEach(function (item) {
                        isItemToShow = classes.some(function (cls) {
                            if (!item.className) return false;
                            return item.className && item.className.indexOf(cls) !== -1;
                        });
                        isItemToShow ? item.elements.container.removeClassName('hidden') : item.elements.container.addClassName('hidden');
                    });
                }

                return function () {
                    var overflowingItems,
                        overflowingItemsIds;

                    // prevent overflow menu trigger from showing when resize is too quick
                    this.overflowMenuTrigger  && this.overflowMenuTrigger.isInjected() && this.overflowMenuTrigger.remove();
                    if (this.overflowMenu.isVisible) this.overflowMenu.hide();

                    // grab all the iconbar items hidden due to overflow
                    overflowingItems = this.getOverflowingItems();

                    // If the container is not overflowing do nothing
                    if (this.elements.container && !overflowingItems) return;

                    overflowingItemsIds = overflowingItems.map(function (item) { return item.id; });

                    // reveal them is the overflow menu
                    toggleOverflowMenuItemVisibility.call(this, overflowingItemsIds);

                    if (overflowingItems.length) {
                        // inject the overflow trigger
                        this.menu.elements.wrapper.insertBefore(this.overflowMenuTrigger, overflowingItems[0].elements.container);

                        // swap the overflow trigger with its previous sibling until its visible or has reached the first position
                        while (this.isElementOverflowing(this.overflowMenuTrigger) && this.overflowMenuTrigger.previousSibling) {
                            this.menu.elements.wrapper.insertBefore(this.overflowMenuTrigger, this.overflowMenuTrigger.previousSibling);
                            overflowingItems.push(this.overflowMenuTrigger.nextSibling);
                            this.overflowMenuTrigger.nextSibling.id && overflowingItemsIds.push(this.overflowMenuTrigger.nextSibling.id);
                            // update overflow menu
                            toggleOverflowMenuItemVisibility.call(this, overflowingItemsIds);
                        }
                    }
                };

            }()),

            /**
             * Handle the creation of an item content when the item is clicked.
             * @param  {Element} item - The parent element.
             * @private
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            displayContent: function (item) {
                var options = UWA.clone(item.content.options);

                options.target = item.elements.container;

                if (!item.content.created) {
                    if (item.content.type === 'dropdown') {
                        require(['DS/UIKIT/Dropdown'], function (Dropdown) {
                            item.content.component = new Dropdown(options).show();
                        });
                    } else if (item.content.type === 'icondropdown') {
                        require(['DS/UIKIT/IconDropdown'], function (IconDropdown) {
                            item.content.component = new IconDropdown(options).show();
                        });
                    } else if (item.content.type === 'dropdownmenu') {
                        item.content.component = new DropdownMenu(options).show();
                    } else {
                        return;
                    }
                    item.content.created = true;
                } else {
                    item.content.component && item.content.component.show();
                }

            },

            /**
             * Select or unselect the provided element.
             * @param  {String|DOM}            item - The item to select/unselect.
             * @param  {Boolean}    [selected=true] - If `false`, deselect the item instead of selecting it.
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            select: function () {

                var args = arguments,
                    item, selected, id, children;

                if (args[0] === undefined || args[0] === null) return;

                selected = (args[1] === undefined) ? true : args[1];

                // first remove the style of the previously active item...
                selected && Array.prototype.slice.call(this.elements.container.querySelectorAll('.item-active')).forEach(function (itm) {
                    itm.removeClassName && itm.removeClassName('item-active');
                });

                // ...then remove any selected item in the overflow menu
                selected && this.overflowMenu.getSelectedItems().forEach(function (itm) {
                    this.overflowMenu.menus[0].toggleSelection(itm);
                    itm.elements.container.removeClassName('selectable');
                }, this);

                // ...then handle selection for the provided item in the iconbar...
                item = this.getItem(args[0]);

                // break early if not found or divider
                if (!item || item.elements.container.hasClassName('divider')) return;

                item.elements.container[selected ? 'addClassName' : 'removeClassName']('item-active');
                id = item.elements.container.id;

                // ... finally adapt selection in the overflow menu
                children = this.overflowMenu.items.filter(function (itm) { return itm.elements.container.hasClassName(id); });

                if (children.length === 1)  {
                    this.overflowMenu.menus[0].toggleSelection(children[0]);
                    children[0].elements.container.addClassName('selectable');
                }
            },

            /**
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            show: function () {
                // break early if not yet in the dom
                if (!this.isInjected()) return;
                this._injectionObserver && this._injectionObserver.disconnect();
                this._injectionObserver = null;
                this._parent();
                if (window.requestAnimationFrame) window.requestAnimationFrame(this.resize.bind(this));
                else this.resize();
            },

            /**
             * @memberof module:DS/UIKIT/IconBar.IconBar#
             */
            destroy: function () {
                window.removeEventListener('resize', this.events.window.resize);
                this.overflowMenu && this.overflowMenu.destroy();
                this.overflowMenuTrigger && this.overflowMenuTrigger.destroy();
                this.elements.container.removeEvents(this.events.container);
                // remove all the tooltips
                this.menu.items.forEach(function (item) {
                    item.tooltip && item.tooltip.destroy();
                });

                this._parent();
            }

        });

        return Iconbar;
    }
);

/**
 * Display a Dropdown full if icons
 * @module DS/UIKIT/IconDropdown
 * @extends DS/UIKIT/DropdownMenu
 * @requires DS/UIKIT/Tooltip
 * @requires DS/UIKIT/Menu
 */
define('DS/UIKIT/IconDropdown', [
    'UWA/Core',
    'UWA/Event',
    'DS/UIKIT/DropdownMenu',
    'DS/UIKIT/Tooltip',
    'DS/UIKIT/Menu'
], function (UWA, Event, DropdownMenu, Tooltip, Menu) {

    'use strict';

    var unsupportedOptions = ['parentItemId', 'position', 'items', 'title', 'text', 'selectable'];

    var checkHeaderDivider = (function () {
        var headerDividerRegex = /^(header|divider|disabled)$/;
        return function (classes) {
            var splitted, i = 0;
            if (!classes) return false;
            splitted = classes.split(' ');
            for (; i < splitted.length; i++) {
                if (headerDividerRegex.test(splitted[i])) return true;
            }
            return false;
        };
    }());

    function addEvent (evnt, elem, func, capture) {
        if (elem.addEventListener) // W3C DOM
            elem.addEventListener(evnt, func, capture);
        else if (elem.attachEvent) { // IE DOM
            elem.attachEvent('on' + evnt, func, capture);
        }
    }

    function addEvents (evnts, elem, capture) {
        Object.keys(evnts).forEach(function (evnt) {
            addEvent(evnt, elem, evnts[evnt], capture);
        });
    }

    /** @lends module:DS/UIKIT/IconDropdown.IconDropdown# */
    var IconDropdown = {
        /**
         * Component name used by `Abstract.getClassNames`.
         * Component class name.
         * Component variations class name prefix.
         * @type {String}
         * @readonly
         * @default
         * @constant
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        name: 'icon-dropdown',

        /**
         * The item currently selected.
         * The value is updated when an icon is clicked.
         * @type {Object}
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        _activeItem: null,

        /**
         * Display an IconDropdown with icon items that the user can click.
         *
         * @example
         * require(['DS/UIKIT/IconDropdown', 'DS/UIKIT/Input/Component'], function (IconDropdown, Button) {
         *     'use strict';
         *     var button = new Button({value: 'Click me'}).inject(body);
         *     var idd = new IconDropdown({
         *         target: button.getContent(),
         *         items: [{
         *             fonticon: 'camera',
         *             description: 'Take a picture',
         *             handler: function () {alert('You just took a picture');},
         *             selected: true
         *         }, {
         *             icon: 'path/to/your/icon',
         *             iconActive: 'path/to/your/icon/active/state',
         *             description: 'Description of your action',
         *             handler: function () {//do things}
         *         }]
         *     });
         * });
         *
         * @param {Object}         options                         - The available options.
         *
         * @param {Element}        [options.target]                - Bind the IconDropdown to the provided target element.
         *                                                           The `target` will be used for positioning, attaching events and inserting the IconDropdown DOM.
         * @param {String}         [options.className]             - An optional css class name that you can use for customizing the component easily.
         *
         * @param {Object[]}       options.items                   - The IconDropdown items.
         *
         * @param {Boolean}        [options.items.selected]        - Set to `true` to have the item selected by default.
         * @param {String}         [options.items.description]     - A text that will be shown as a tooltip when hovering this item.
         * @param {String}         [options.items.icon]            - Will add an <img> with the given path.
         *                                                           Else it will add the icon value as a class on this item element.
         * @param {String}         [options.items.iconActive]      - The paths to the active state icon file.
         *                                                           This <img> will be displayed when the item is hovered or selected.
         * @param {String}         [options.items.fonticon]        - If provided will prefix the value given by `fonticon-` and add it as a class on this item element.
         * @param {String}         [options.items.className]       - An optional css class name that you can use for customizing this item.
         *                                                           If it is equal to `header` or `divider` > special case.
         * @param {Function}       [options.items.handler]         - An optional handler to call when this item is clicked. Will be called after the main `onClick`.
         *                                                           Prefer the main `onClick` event for performance reasons when possible.
         * @param {Object}         [options.events]                - The available events.
         *
         * @param {Function}       [options.events.onShow]         - An event dispatched when the IconDropdown is shown.
         * @param {Function}       [options.events.onHide]         - An event dispatched when the IconDropdown is hidden.
         * @param {Function}       [options.events.onClick]        - An event dispatched when the IconDropdown is clicked.
         * @param {Function}       [options.events.onClickOutside] - An event dispatched when a click is received outside of the IconDropdown.
         * @param {Function}       [options.events.onMouseLeave]   - An event dispatched when the cursor leaves the IconDropdown container.
         *
         * @constructs IconDropdown
         * @memberof module:DS/UIKIT/IconDropdown
         */
        init: function (options) {
            this._parent(options);
        },

        /**
         * Build HTML skeleton.
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        buildSkeleton: function () {
            var elements = this.elements,
                options = this.options,
                menu;

            // Safe check if user called `buildSkeleton` directly
            if (elements.container) return;

            menu = new Menu();
            menu.position = options.position || 'bottom right';
            this.menus.push(menu);
            // will call menu.addItem
            this.addItem(options.items);

            // directly point to the list element
            elements.container = menu.elements.wrapper;
            // reset classes to prevent CSS conflicts
            elements.container.className = this.name;

            this.handleEvents();
        },

        /**
         * Attach main icon dropdown events.
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        handleEvents: function () {

            var that = this,
                options = this.options,
                elements = this.elements;

            // Dropdown code without click event to prevent click from being dispatched twice.
            if (options.contextual) {
                // Click event on the target to update the Dropdown position
                this.events.target = {
                    mousedown: function (event) {

                        var target = Event.getElement(event),
                            isRightClick = UWA.Event.whichButton(event) === 2;

                        // Updates position if the click happened outside of the container
                        if (!target.isInjected(this.elements.container) && target !== this.elements.container &&
                            isRightClick && this.isVisible) {
                            this.updatePosition(event);
                        }
                    }.bind(this),
                    // Blocks the contextual menu and display our custom one
                    contextmenu: function (event) {
                        this.show(false, event);
                        Event.stop(event);
                    }.bind(this)
                };

                // Add the contextual events
                addEvents(this.events.target, options.target, true);
            } else if (options.bound) {
                // If bound will attach a click event for toggling the Dropdown visibility
                this.events.target = {
                    click: this.toggle.bind(this)
                };
                addEvents(this.events.target, options.target, true);
            }

            this.events.container = {
                click: function (event) {
                    var target = Event.getElement(event),
                        item = that.getItem(target);
                    if (item && !checkHeaderDivider(item.elements.container.className)) {

                        if (item.tooltip && item.tooltip.isVisible) item.tooltip.hide();
                        // set clicked item to be the active one.
                        that._updateSelected(item);
                        that.dispatchEvent('onClick', [event, item], that);

                        // Call the item handler if it was provided
                        if (typeof item.handler === 'function') {
                            item.handler.call(that, event, item);
                        }
                    }
                }
            };

            elements.container.addEvents(this.events.container);
        },

        /**
         * Add the specified menu item.
         * @param {Object} options - The available options. See `addItem`.
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        _addItem: function (options) {
            var that = this,
                menu = this.menus[0],
                item,
                menuOptions = UWA.clone(options),
                textSpan, events;

            // remove unsupported options
            unsupportedOptions.concat('selected').forEach(function (opt) {
                delete menuOptions[opt];
            });

            item = menu._addItem(menuOptions);

            // remove unnecessary DOM.
            textSpan = item.elements.container.getElement('.item-text');
            textSpan && textSpan.destroy();

            // add a tooltip only if a description is provided.
            if (options.description) {
                item.tooltip = new Tooltip({
                    target: item.elements.container,
                    body: item.description,
                    position: 'bottom'
                });
            }

            // Create a other image if fonticon is not provided.
            // This will prevent fetching image source each time
            // the icon is either hovered or selected.
            if (options.icon && !options.fonticon) {
                item.elements.iconActive = UWA.createElement('img', {
                    src: options.iconActive ? options.iconActive : options.icon,
                    'class': 'item-icon hidden'
                });
                item.elements.iconActive.inject(item.elements.container);
                events = {
                    mouseover: function () {
                        if (!item.elements.container.hasClassName('selected')) {
                            that._toggleIcon(item, true);
                        }
                    },
                    mouseleave: function () {
                        if (!item.elements.container.hasClassName('selected')) {
                            that._toggleIcon(item);
                        }
                    }
                };
            }

            item.elements.container.addEvents(events);

            if (options.selected) {
                this._updateSelected(item);
            }

            this.items.push(item);
        },

        /**
         * Updates the specified item from the Dropdown Menu.
         * @param {Object} options - The available options. See `updateItem`.
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        _updateItem: function (options) {

            var menu = this.menus[0],
                item;

            // Need to check if it is an existing item and get its id
            item = this.getItem(options.id);

            if (item) {
                unsupportedOptions.concat('selected').forEach(function (opt) {
                    delete options[opt];
                });
                options.id = item.id;
                menu && menu.updateItem(options);
                // update icon dropdown specific options.
                if (options.iconActive) {
                    item.iconActive = options.iconActive;
                    item.elements.iconActive.setAttribute('src', options.iconActive);
                }
                if (options.description) {
                    if (item.tooltip) {
                        item.tooltip.setBody(options.description);
                    } else {
                        item.tooltip = new Tooltip({
                            target: item.elements.container,
                            body: item.description,
                            position: 'bottom'
                        });
                    }
                }
            }
        },

        /**
         * Toggle the active icon visibility.
         * @param {Object}  item       - The item owning the icons.
         * @param {Boolean} showActive - `true` if the icon should display its active state.
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        _toggleIcon: function (item, showActive) {
            // break early if there is no item or item is using fonticon.
            if (!item || !item.elements.iconActive) return;
            if (showActive) {
                item.elements.iconActive.removeClassName('hidden');
                item.elements.icon.addClassName('hidden');
            } else {
                item.elements.icon.removeClassName('hidden');
                item.elements.iconActive.addClassName('hidden');

            }
        },

        /**
         * Set the IconDropdown selected item.
         * @param  {Object} item - The new selected item.
         * @private
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        _updateSelected: function (item) {
            if (this._activeItem === item) return;
            this._activeItem && this._activeItem.elements.container.removeClassName('selected');
            this._toggleIcon(this._activeItem);
            this._activeItem = item;
            this._activeItem.elements.container.addClassName('selected');
        },

        /**
         * Get the active item.
         * @returns {Object} - The currently active item.
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        getActiveItem: function () {
            return this._activeItem;
        },

        /**
         * Programmatically set the active item.
         * @param {number|String|Element} id - Identifier of the item to retrieve.
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        setActiveItem: function (id) {
            var item = this.getItem(id);
            if (item) {
                this._updateSelected(item);
            }
        },

        /**
         * Update the dropdown position.
         * We do not force the position when space is not big enough.
         * @returns {IconDropdown} - The instance
         * @memberof module:DS/UIKIT/IconDropdown.IconDropdown#
         */
        updatePosition: function (event) {

            this._parent(event);

            var options = this.options,
                elements = this.elements,
                target, targetWidth, width, left;

            if (options.target && !options.altPosition) {
                target = options.target;
                targetWidth = target.offsetWidth;
                width = elements.container.offsetWidth;
                left = this._position.offsets.x;

                elements.container.setStyles({
                    left: left + (targetWidth / 2) - (width / 2) + options.offset.x
                });
            }
        }
    };

    return DropdownMenu.extend(IconDropdown);
});

/**
 * The text control.
 * @module DS/UIKIT/Input/Text
 * @extends DS/UIKIT/Input
 */
define('DS/UIKIT/Input/Text',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'DS/UIKIT/Input'
    ],
    function (UWA, Element, Event, Client, Input) {

        'use strict';

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) { return; }
            klasses = klasses.split(' ');

            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/xsmall|small|large$/);
                if (match && !match[1]) {
                    if (match[0] === 'small') {
                        klasses[i] = 'input-sm';
                    } else if (match[0] === 'large') {
                        klasses[i] = 'input-lg';
                    } else if (match[0] === 'xsmall') {
                        klasses[i] = 'input-xs';
                    }
                }
            }
            return klasses.join(' ');
        }

        /**
         * @lends module:DS/UIKIT/Input/Text.Text#
         */
        var Text = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            name: 'form-control',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            defaultOptions: {
                className: '',
                multiline: false
            },

            /**
             * The text control.
             *
             * @example
             * require(['DS/UIKIT/Input/Text'], function (Text) {
             *     new Text({ placeholder: "Text input..." }).inject(body);
             * });
             *
             * @param {Object} options                         - Available options.
             *
             * @param {String}  [options.className]            - An optional className to apply to the text input.
             * @param {Object}  [options.attributes]           - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}  [options.value]                - The starting input text value.
             * @param {String}  [options.id]                   - Sets the input text id.
             * @param {String}  [options.name]                 - Sets the input text name.
             * @param {Boolean} [options.disabled=false]       - Whether the input text should be disabled from start.
             * @param {String}  [options.placeholder]          - Set the input text placeholder.
             * @param {number}  [options.maxlength]            - Sets the max length for this input text.
             * @param {number}  [options.rows]                 - Set the rows attribute.
             * @param {Boolean} [options.multiline=false]      - Set the input text as multiline.
             * @param {Boolean} [options.required=false]       - Set the input text as required, only used inside a UIKIT.Form.
             * @param {String}  [options.pattern]              - Set the pattern for this input to test its value against, only used inside a UIKIT.Form.
             * @param {Object}  [options.events]               - The available events.
             *
             * @param {Object}    [options.events.onChange]    - Invoked when the input text value changes.
             * @param {Object}    [options.events.onClick]     - Invoked when the user click on the input text.
             * @param {Object}    [options.events.onMouseDown] - Invoked when the user press the mouse button on the input text.
             * @param {Object}    [options.events.onKeyDown]   - Invoked when the user press a key while focusing the input text.
             *
             * @constructs Text
             * @memberof module:DS/UIKIT/Input/Text
             *
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             * @borrows module:DS/UIKIT/Input.Input#setDisabled as #setDisabled
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#enable as #enable
             * @borrows module:DS/UIKIT/Input.Input#disable as #disable
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             * @borrows module:DS/UIKIT/Input.Input#setValue as #setValue
             */
            init: function (options) {
                options = options || {};

                if (options.className) {
                    options.className = parseClassName(options.className);
                }
                this._parent(options);
            },

            /**
             * Build the native input element.
             * Override UIKIT/Input
             * @returns {Element} - The native input element
             * @private
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            buildInput: function () {

                var attributes = {},
                    options = this.options,
                    element = options.multiline ?
                        UWA.createElement('textarea') :
                        UWA.createElement('input', { type: 'text' });


                // Set attributes if needed
                ['placeholder', 'required', 'pattern', 'rows', 'maxlength'].forEach(function (pref) {
                    if (options[pref]) { attributes[pref] = options[pref]; }
                });
                element.set(attributes);

                return element;
            },

            /**
             * Set the focus on this input.
             * Override UIKIT/Input to show the placeholder when not focus.
             * @param  {Boolean} [focus=true] - If false, remove the focus.
             * @returns {Text}                - The instance.
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            setFocus: function (focus) {
                this._parent(focus);
                this.syncInput();
                return this;
            },

            /**
             * Synchronize the control display with the native input state.
             * Override UIKIT/Input to show the placeholder.
             * @private
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            syncInput: function () {

                var value, showPlaceholder,
                    input = this.elements.input,
                    placeholder = input.getAttribute('placeholder');

                if (placeholder && !Client.Features.inputPlaceholder) {
                    value = this.getValue();

                    // Only show when not focus and value is empty
                    showPlaceholder = input.getDocument().activeElement !== input && !value;

                    if (showPlaceholder !== input.hasClassName('placeholder')) {
                        input.toggleClassName('placeholder', showPlaceholder);
                        input.set(
                            input.getTagName() === 'textarea' ? 'text' : 'value',
                            showPlaceholder ? placeholder : value
                        );
                    }
                }
            },

            /**
             * Get the input value.
             * Override UIKIT/Input to avoid returning placeholder value when empty (ie9+).
             * @returns {String} - The input value.
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            getValue: function () {
                if (this.elements.input.hasClassName('placeholder')) {
                    return '';
                }
                return this._parent();
            },

            /**
             * Set the className for this text input.
             * @param {String} klass - A list of classes or a single class.
             * @returns {Text}       - The instance.
             * @memberof module:DS/UIKIT/Input/Text.Text#
             */
            setClassName: function (klass) {
                this.options.className = parseClassName(klass);
                this.getContent().className = this.getClassNames();
                return this;
            }
        };

        return Input.extend(Text);
    });

/**
 * A minimal Javascript API for creating buttons.
 * @module DS/UIKIT/Input/Button
 * @requires DS/UIKIT/DropdownMenu
 * @extends DS/UIKIT/Input
 */
define('DS/UIKIT/Input/Button',
    [
        'UWA/Core',
        'UWA/Event',
        'DS/UIKIT/Input',
        'DS/UIKIT/DropdownMenu',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],


    function (UWA, Event, Input, DropdownMenu, i18n) {

        'use strict';

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) { return; }
            klasses = klasses.split(' ');

            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/large-icon|xsmall|small|large|default|primary|info|warning|error|success|link|block$/);
                if (match && !match[1]) {
                    if (match[0] === 'small') {
                        klasses[i] = 'btn-sm';
                    } else if (match[0] === 'large-icon') {
                        klasses[i] = 'large-icon-btn';
                    } else if (match[0] === 'large') {
                        klasses[i] = 'btn-lg';
                    } else if (match[0] === 'xsmall') {
                        klasses[i] = 'btn-xs';
                    } else {
                        klasses[i] = 'btn-' + klasses[i];
                    }
                }
            }
            return klasses.join(' ');
        }

        /**
         * @lends module:DS/UIKIT/Input/Button.Button#
         */
        var Button = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            name: 'btn',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            defaultOptions: {
                className: 'btn-default',
                dropdownCaret: true,
                active: false
            },

            /**
             * The dropdown menu is defined by the `options.dropdown`.
             * @property {module:DS/UIKIT/DropdownMenu.DropdownMenu}
             * @private
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            dropdown: null,

            /**
             * A minimal Javascript API for creating buttons.
             *
             * @example
             * require(['DS/UIKIT/Input/Button'], function (Button) {
             *     // Provides extra visual weight and identifies the primary action in a set of buttons
             *     new Button({ value: "A primary button", className: "primary" }).inject(body);
             * });
             *
             * @param {Object} options                                    - Available options.
             *
             * @param {String}  [options.className='btn-default']         - An optional className to apply to the container.
             *                                                              Can be : `primary`, `info`, `default`, `large`, `small`, `xsmall`, `link`, `warning`, `error`, `success`).
             * @param {Object}  [options.attributes]                      - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}  [options.value]                           - The starting button value (the actual text displayed).
             * @param {String}  [options.id]                              - Sets the button id.
             * @param {String}  [options.name]                            - Sets the button name.
             * @param {Boolean} [options.disabled=false]                  - Whether this button should be disabled from start.
             * @param {Boolean} [options.active=false]                    - Whether this button should be active from start (pressed state).
             * @param {String}  [options.icon]                            - The button icon image className. Will get prefixed by `fonticon` whatsoever.
             *                                                              Can specify `right` for positioning the icon on the right.
             * @param {Object}  [options.dropdown]                        - The dropdown options, see the DropdownMenu component options.
             * @param {Boolean} [options.dropdownCaret=true]              - Whether to display a caret for visual clue that the button has a dropdown. Only available when dropdown.
             * @param {Object}  [options.events]                          - The available events.
             *
             * @param {Object}    [options.events.onClick]                - Invoked when the user click on button.
             * @param {Object}    [options.events.onMouseDown]            - Invoked when the user press the mouse button on the button.
             * @param {Object}    [options.events.onKeyDown]              - Invoked when the button is focused and the user press a key.
             * @param {Object}    [options.events.onDropdownShow]         - Invoked when dropdown is shown (only available when dropdown).
             * @param {Object}    [options.events.onDropdownHide]         - Invoked when dropdown is hidden (only available when dropdown).
             * @param {Object}    [options.events.onDropdownClick]        - Invoked when dropdown is clicked (only available when dropdown).
             * @param {Object}    [options.events.onDropdownClickOutside] - Invoked when the user click outside of dropdown (only available when dropdown).
             * @param {Object}    [options.events.onDropdownMouseLeave]   - Invoked when the user mouse moves outside of dropdown (only available when dropdown).
             *
             * @constructs Button
             * @memberof module:DS/UIKIT/Input/Button
             *
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Input#setFocus as #setFocus
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             * @borrows module:DS/UIKIT/Input.Input#setDisabled as #setDisabled
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#enable as #enable
             * @borrows module:DS/UIKIT/Input.Input#disable as #disable
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             * @borrows module:DS/UIKIT/Input.Input#getValue as #getValue
             */
            init: function (options) {
                options = options || {};

                if (options.className) {
                    options.className = parseClassName(options.className);
                }

                this._parent(options);

                // Handle the active option
                this.options.active && this.setActive(this.options.active);

                // Handle the icon option
                this.options.icon && this.setIcon(this.options.icon);

                // Special case when button has no label (exemple : button with fonticon only)
                if (!options.value || options.value === '') {
                    this.elements.container.addClassName('btn-without-label');
                }

            },

            /**
             * Build the native input element.
             * @returns {Element} - The native input element
             * @private
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            buildInput: function () {
                return UWA.createElement('button', { type: 'button' });
            },

            /**
             * Post injection hook to handle the dropdown creation.
             * @private
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            onPostInject: function () {
                this.options.dropdown && this.setDropdown(this.options.dropdown);
            },

            /**
             * Set the button dropdown.
             * @param  {Object}  options       - The DropdownMenu options.
             * @param  {Boolean} [caret=false] - Whether to display a caret for visual clue that the button has a dropdown.
             * @returns {Button}               - The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            setDropdown: function (options, caret) {

                var that = this, defaultOptions;

                function dispatch (event) {
                    return function () {
                        that.dispatchEvent.call(that, event, arguments);
                    };
                }

                function onClick () {
                    that.setActive(that.dropdown.isVisible);
                    that.dispatchEvent.call(that, 'onDropdownClick', arguments);
                }

                function onClickOutside () {
                    var target = Event.getElement(arguments[0]),
                        button = that.getContent();

                    if (target !== button && target.getParent() !== button) {
                        that.setActive(that.dropdown.isVisible);
                    }

                    that.dispatchEvent.call(that, 'onDropdownClickOutside', arguments);
                }

                if (!this.events.dropdown) {
                    this.events.dropdown = {
                        onShow: dispatch('onDropdownShow'),
                        onHide: dispatch('onDropdownHide'),
                        onClick: onClick,
                        onClickOutside: onClickOutside,
                        onMouseLeave: dispatch('onDropdownMouseLeave')
                    };

                    this.events.dropdownButton = {
                        click: function () { that.setActive(that.dropdown.isVisible); }
                    };
                }

                defaultOptions = {
                    events: this.events.dropdown,
                    target: this.getContent()
                };

                // Destroy any previous dropdown
                if (this.dropdown) {
                    this.dropdown.destroy();
                }

                // Special switch for adding a caret
                if (caret || (!UWA.is(caret) && this.options.dropdownCaret)) {
                    this.elements.caret = UWA.createElement('span', { 'class': 'caret' }).inject(this.getContent());

                    // Special case for when no value
                    this.getContent().toggleClassName('dropdown-toggle', !this.getValue());
                }

                // Create the dropdown and append it
                this.dropdown = new DropdownMenu(UWA.merge(options, defaultOptions));

                // Add the toggle event
                this.getContent().addEvents(this.events.dropdownButton);

                return this;
            },

            /**
             * Set the button icon using a font face icon.
             * @example
             * button.setIcon('star')
             * // => `<span class = "fonticon fonticon-star"></span>`
             * @param  {String} klasses - The icon class name.
             * @returns {Button}        - The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            setIcon: function (klasses) {

                var elements = this.elements;

                klasses = klasses.split(' ');

                // Format icon and check for position
                for (var i = 0, l = klasses.length; i < l; i++) {

                    if (klasses[i] === 'left' || klasses[i] === 'right') {
                        continue;
                    }

                    // Caret is a special fonticon because made of border css
                    if (!klasses[i].match('fonticon-') && klasses[i] !== 'caret') {
                        klasses[i] = 'fonticon-' + klasses[i];
                    }
                }

                klasses = klasses.join(' ');

                // Handle left/right incompatibilities with fonticon-left / fonticon-right
                if (klasses === 'left' || klasses === 'left left') {
                    // User wants a fonticon-left on the left
                    klasses = 'fonticon-left';
                } else if (klasses === 'left right' || klasses === 'right left') {
                    // User wants a fonticon-left on the right
                    klasses = 'fonticon-left right';
                } else if (klasses === 'right') {
                    // User wants a fonticon-right (on the left)
                    klasses = 'fonticon-right';
                } else if (klasses === 'right right') {
                    // User wants a fonticon-right on the right
                    klasses = 'fonticon-right right';
                }

                // Create the icon element or change the class
                if (!elements.icon) {
                    elements.icon = UWA.createElement('span', {
                        'class': 'fonticon ' + klasses
                    }).inject(elements.input, 'top');
                } else {
                    elements.icon.className = 'fonticon ' + klasses;
                }

                // If there's an icon, change the min-width.
                elements.icon && this.elements.container.addClassName('btn-with-icon');

                return this;
            },

            /**
             * Remove the icon.
             * @returns {Button} - The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            removeIcon: function () {
                if (this.elements.icon) {
                    this.elements.icon.destroy();
                }
                // Get back to the normal min-width.
                this.elements.container.removeClassName('btn-with-icon');
                return this;
            },

            /**
             * Set the input value.
             * Override UIKIT/Input to avoid removing icon / label.
             * @param {String} value - The new value.
             * @returns {Button} - The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            setValue: function (value) {

                var input = this.elements.input,
                    textNode;

                // Special case if we have an icon
                // To avoid removing icon
                if (this.elements.icon || this.elements.caret) {
                    textNode = this.getContent().firstChild;

                    if (textNode === this.elements.caret) {
                        input.insertBefore(document.createTextNode(value), textNode);
                    } else {
                        // If icon, text should be on next sibling
                        textNode = textNode.nodeType === 3 ? textNode : textNode.nextSibling;
                        input.insertBefore(document.createTextNode(value), textNode);
                        textNode && textNode.nodeType === 3 && input.removeChild(textNode);
                    }
                } else {
                    input.setText(value);
                }

                // Special case for empty button with caret
                if (this.elements.caret) {
                    this.getContent().toggleClassName('dropdown-toggle', !this.getValue());
                }

                // Special case when button has no label (exemple : button with fonticon only)
                if (!value || value === '') {
                    this.elements.container.addClassName('btn-without-label');
                }

                return this;
            },

            /**
             * Set the button as active (giving him a pressed state).
             * @param {Boolean} [active=true] - If false, remove the active.
             * @returns {Button}              -The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            setActive: function (active) {
                if (typeof active === 'undefined') {
                    active = true;
                }
                this.getContent().toggleClassName('active', active);
                return this;
            },

            /**
             * Toggle the active state of the button.
             * @returns {Button} - The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            toggleActive: function () {
                return this.setActive(!this.isActive());
            },

            /**
             * Get if this input is active.
             * @returns {Boolean}
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            isActive: function () {
                return this.getContent().hasClassName('active');
            },

            /**
             * @memberof module:DS/UIKIT/Input/Button.Button#
             * @deprecated in favor of `load()`.
             */
            loading: function () {
                console.info('The method `Button.loading()` is deprecated. Please use `Button.load()` instead.');
                this.load.apply(this, arguments);
            },

            /**
             * Set a loading state for this button.
             * @param  {Boolean} [loading=true]      - If false, remove the loading state.
             * @param  {String}  [text='Loading...'] - The loading string to display.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            load: function (loading, text) {
                var value;

                if (typeof loading === 'undefined') {
                    loading = true;
                }

                if (loading && !this.previousValue) {
                    this.previousValue = this.getValue();
                }

                value = loading ? text || i18n.loading : this.previousValue;
                value && this.setValue(value);
                this.setDisabled(loading);

                if (!loading) {
                    delete this.previousValue;
                }
            },

            /**
             * Set the className for this button.
             * @param  {String} klass - A list of classes or a single class.
             * @returns {Button}      - The instance.
             * @memberof module:DS/UIKIT/Input/Button.Button#
             */
            setClassName: function (klass) {
                this.options.className = parseClassName(klass);
                this.getContent().className = this.getClassNames();
                return this;
            }
        };

        return Input.extend(Button);
    });

/**
 * Collapses content grouped by sections.
 * @module DS/UIKIT/Accordion
 * @requires DS/UIKIT/Input/Button
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Accordion',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Input/Button'
    ],

    function (UWA, Element, Event, Utils, Abstract, Button) {

        'use strict';

        /**
         * @lends module:DS/UIKIT/Accordion.Accordion#
         */
        var Accordion = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            name: 'accordion',

            /**
             * Class name for accordion items.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            ITEM_CLASSNAME: 'accordion-item',

            /**
             * Class name for accordion titles.
             * @type {String}
             * @readonly
             * @default
             * @readonly
             * @constant
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            TITLE_CLASSNAME: 'accordion-title',

            /**
             * The default options.
             * @property {Object}
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            defaultOptions: {
                buttons: false, // true to display buttons to trigger collapsing.
                arrows: true, // true to show arrows on the left.
                exclusive: true, // false to allow more than one content opened.
                animated: false, // true to animate arrows transitions and hover.
                styled: false // true if bordered.
            },

            /**
             * The accordion items.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            items: null,

            /**
             * The accordions containers and properties.
             * Internal usage only.
             * @type {Object[]}
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            subAccordions: null,

            /**
             * Currently selected items.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            selectedItems: null,

            /**
             * Currently un-selected items.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            unselectedItems: null,

            /**
             * Used to count the number of embedded items i.e. not triggered by externals elements.
             * Internal usage only.
             * @type {number}
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            embeddedItems: 0,

            /**
             *  Collapses content grouped by sections.
             *
             *  @example
                require(['DS/UIKIT/Accordion'], function (Accordion) {

                    var divAccordion =  document.querySelector('#accordion-div');

                    new Accordion({
                        items: [
                            {  title: "First item",
                               content: "Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate." },
                            {  title: "Second item",
                               content: "Sed non urna. Donec et ante. Phasellus eu ligula. Vestibulum sit amet purus. Vivamus hendrerit, dolor at aliquet laoreet, mauris turpis porttitor velit, faucibus interdum tellus libero ac justo. Vivamus non quam. In suscipit faucibus urna." },
                            {  title: "Third item",
                               content: "Cras dictum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean lacinia mauris vel est." },
                            {  title: "Fourth item",
                               content: "Dies illa, dies tribulationis et angustiæ, dies calamitatis et miseriæ, dies tenebrarum et caliginis, dies nebulæ et turbinis, dies tubæ et clangoris super civitates munitas et super angulos excelsos. " }
                        ]
                    }).inject(divAccordion);

                });
             *
             * @param {Object[]}    options                         - The available options.
             *
             * @param {Boolean}     [options.exclusive=true]        - True to allow only one section opened.
             * @param {String}      [options.className]             - One or more optional class names. Accordion.css provide filled, styled and divided
             * @param {Object[]}    options.items                   - Every accordion and nested accordions items.
             *
             * @param {String}      [options.items.title]           - The accordion item title, showed from beginning. Could be plain text or HTML.
             * @param {String}      [options.items.name]            - Name identifier for the item to select.
             * @param {Element}     [options.items.trigger]         - Element that will trigger item's content on click.
             * @param {String}      [options.items.content]         - The accordion item content, showed when clicking on the corresponding title. Could be plain text or HTML.
             * @param {Function}    [options.items.handler]         - Function to be called on item click.
             * @param {Boolean}     [options.items.selected=false]  - True to select item on accordion startup.
             *
             * @param {Object}      [options.events]                - The available events.
             *
             * @param {Function}    [options.events.onClick]        - Invoked when the accordion is clicked. Returns the clicked item if some.
             * @param {Function}    [options.events.onOpen]         - Invoked when an accordion item is opened. Returns the opened item and every selected items array.
             * @param {Function}    [options.events.onClose]        - Invoked when an accordion item is closed. Returns the closed item and every unselected items array.
             * @param {Function}    [options.events.onChange]       - Invoked when an accordion item is selected. Returns the selected item if some, every selected items array and every unselected items array.
             *
             * @constructs Accordion
             * @memberof module:DS/UIKIT/Accordion
             *
             */
            init: function (options) {

                var i, l = options.items.length,
                    mainAccordionId,
                    itemOptions, globalOptions;

                this._parent(options);

                // Initialiaze mandatory variables.
                this.items = [];
                this.subAccordions = [];
                this.selectedItems = [];
                this.unselectedItems = [];

                this.buildSkeleton();

                // Add nested accordions in main accordion (the first subAccordion) if some.
                if (this.subAccordions[0] && l) {

                    mainAccordionId = this.subAccordions[0].id;
                    itemOptions = [];
                    itemOptions.globalOptions = [];
                    // Need to keep these information for subAccordion global preferences like arrows display, exclusiveness...
                    globalOptions = this.subAccordions[0].options;

                    for (i = 0; i < l; i++) {
                        itemOptions = options.items[i];
                        itemOptions.accordionId = mainAccordionId;
                        itemOptions.globalOptions = globalOptions;
                        this.addItem(itemOptions);
                    }
                }

                this.options.styled = this.elements.container.hasClassName('styled');

                // Do not active styled mode if there is no embedded items while there is nothing to show.
                if (this.options.styled && this.embeddedItems === 0) {
                    this.elements.container.removeClassName('styled');
                }
            },

            /**
             * Build HTML skeleton.
             * @private
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    mainAccordion;

                // Safe check if user called buildSkeleton directly.
                if (elements.container) {
                    return;
                }

                // Build container
                this.options.className = this.getClassNames();
                mainAccordion = this._addSubAccordion(this.options);
                elements.container = mainAccordion.container;

                this.handleEvents();
            },

            /**
             * Constructs model and build DOM Element for an accordion element. Accordion is added to subAccordions list.
             *
             * @param {Object[]} options                - The available options.
             *
             * @param {number} [options.parentItemId]   - Reference to the item where the accordion is nested. -1 for a main accordion.
             * @param {String} [options.className]      - Full class name to properly display the accordion + optional classNames.
             *
             * @returns {Object[]}                      - The accordion options, container, and references.
             *
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _addSubAccordion: function (options) {

                var accordion = [];

                accordion.id = Utils.getUUID().substr(0, 6);

                // Keep a reference of parent item.
                accordion.parentItemId = (options.parentItemId) ? (options.parentItemId) : (-1);

                // Keep every accordion options - exclusiveness, animation... Merged with defaultOptions
                accordion.options = UWA.merge(options, this.defaultOptions);

                if (accordion.parentItemId !== -1) {
                    accordion.options.className = options.className + ' sub-accordion';
                }

                // Build container
                accordion.container = this._buildAccordion(accordion.options);

                this.subAccordions.push(accordion);

                return accordion;
            },

            /**
             * Get an accordion from subAccordions for a given id.
             *
             * @param {String} id - Reference to the accordion.
             * @return {Object}   - The accordion if founded, otherwise false.
             *
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _getSubAccordion: function (id) {

                var accordion = [], itemPosition, itemsLength;

                if (this.subAccordions) {

                    for (itemPosition = 0, itemsLength = this.subAccordions.length; itemPosition < itemsLength; itemPosition += 1) {

                        accordion = this.subAccordions[itemPosition];
                        if (accordion && accordion.id && accordion.id === id) {
                            return accordion;
                        }
                    }
                }

                return false;
            },

            /**
             * Build accordion container.
             *
             * @param {Object[]} options - The available options.
             * @param {String}  [options.className]  - Full class name to properly display the accordion + optional classNames.
             * @param {Boolean} [options.animated]   - True if have to add animation CSS rules.
             *
             * @return {Element} - DOM element for the accordion.
             *
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _buildAccordion: function (options) {
                // If the className if not set, will use default classNames.
                var classNames = (options.className) ? (options.className) : (this.getClassNames());

                var container = UWA.createElement('div', {
                    'class': classNames
                });

                // Animate arrows if required
                if (options.animated) {
                    container.addClassName('animated');
                }

                return container;
            },

            /**
             * Build item container.
             *
             * @param {Object[]} item                   - Item instance requiring a container.
             * @param {Object[]} options                - Available options.
             * @param {String}  [options.globalOptions] - Global options from the parent accordion.
             * @param {String}  [options.title]         - Title for this item.
             * @param {String}  [options.content]       - The accordion item content, showed when clicking on the corresponding title.
             * @param {Boolean} [options.arrow]         - True if require an arrow.
             * @param {Boolean} [options.button]        - True if require a button.
             *
             * @param {String} classNames               - The classNames to consider.
             *
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _buildAccordionItem: function (item, options, classNames) {

                // Create item container
                item.elements = {
                    container: UWA.createElement('div', {
                        'class': this.ITEM_CLASSNAME + ' ' + classNames,
                        id: item.id
                    })
                };

                // Create content container if required
                if (options.title) {

                    item.title = UWA.createElement('div', {
                        'class': this.TITLE_CLASSNAME + ' ',
                        html: options.title || ''
                    });

                    // Add arrow on left if required : look at global preferences if some (default if none) and give priority to local preference
                    if ((options.arrow !== false && ((options.globalOptions && options.globalOptions.arrows) || (!options.globalOptions && this.defaultOptions.arrows))) || options.arrow) {
                        UWA.createElement('i', {
                            'class': 'caret-left '
                        }).inject(item.title, 'top');
                    }

                    item.title.inject(item.elements.container);

                    // Add abutton on right if required : look at global preferences and give priority to local preference
                    if ((options.button !== false && options.globalOptions && options.globalOptions.buttons) || options.button) {
                        item.button = new Button();
                        item.button.setIcon('plus');
                        item.button.inject(item.title);
                    }

                    this.embeddedItems++;
                }

                // Create content container
                item.elements.wrapper = UWA.createElement('div', {
                    'class': 'content-wrapper'
                });

                item.elements.content = UWA.createElement('div', {
                    'class': 'content ' + classNames
                });

                options.content && item.elements.content.setContent(options.content);

                options.globalOptions && options.globalOptions.animated && item.elements.content.toggleClassName('accordion-animated-content');

                item.elements.content.inject(item.elements.wrapper);

                item.elements.wrapper.inject(item.elements.container);

            },

            /**
             * Allow to know from a subAccordion id if it is in exclusive mode or not.
             *
             * @param {String} id - Reference to the accordion.
             * @return {Boolean} - True if given accordion is in exclusive mode, otherwise false.
             *
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _isExclusive: function (id) {
                var accordion = this._getSubAccordion(id);
                return accordion && accordion.options.exclusive;
            },

            /**
             * Do the proper modifications to validate the selection of an item.
             *
             * @param {Object[]} options      - The item itself or just its name.
             * @param {String} [options.name] - Name identifier for the item to select.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            selectItem: function (options) {

                var item, index, selectedItem = [];

                // Check if the input is the item itself
                if (options.name) {
                    item = options;
                } else {
                    // Or try to get it
                    item = this.getItem(options);
                    if (!item) {
                        return;
                    }
                }

                if (!item.isSelected) {

                    item.isSelected = true;
                    item.elements.container.addClassName('active');
                    index = this._getSelectedItemPosition(item.accordionId, item.id);

                    // Add item to selected items
                    if (index === -1) {
                        selectedItem.id = item.id;
                        selectedItem.accordionId = item.accordionId;
                        this.selectedItems.push(selectedItem);
                        this.dispatchEvent('onOpen', [item, this.selectedItems], this);
                    }

                    index = this._getUnselectedItemPosition(item.accordionId, item.id);

                    // Remove item from unselected items
                    if (index > -1) {
                        this.unselectedItems.splice(index, 1);
                    }

                    if (item.button) {
                        item.button.setIcon('minus');
                    }
                }
            },

            /**
             * Do the proper modifications to validate the un-selection of an item.
             *
             * @param {Object[]} options        - the item itself or just its name.
             * @param {String}   [options.name] - Name identifier for the item to select.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            unselectItem: function (options) {

                var item, index, unselectedItem = [];

                // Check if the input is the item itself
                if (options.name) {
                    item = options;
                } else {
                    // Or try to get it
                    item = this.getItem(options);
                    if (!item) {
                        return;
                    }
                }

                if (item.isSelected) {

                    item.isSelected = false;
                    item.elements.container.removeClassName('active');
                    index = this._getSelectedItemPosition(item.accordionId, item.id);

                    // Remove item from selected items
                    if (index > -1) {

                        this.selectedItems.splice(index, 1);
                    }

                    index = this._getUnselectedItemPosition(item.accordionId, item.id);

                    // Add item to unselected items.
                    if (index === -1) {

                        unselectedItem.id = item.id;
                        unselectedItem.accordionId = item.accordionId;
                        this.dispatchEvent('onClose', [item, this.unselectedItems], this);
                        this.unselectedItems.push(unselectedItem);
                    }

                    if (item.button) {
                        item.button.setIcon('plus');
                    }
                }
            },

            /**
             * Enable an item (enable clicking).
             *
             * @param {number|String|Element} id  - Identifier of the item to enable.
             * @returns {Accordion} - The instance
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            enableItem: function (id) {

                var item = this.getItem(id);

                item && item.elements.container.removeClassName('disabled');
                item.disabled = false;
                return this;
            },

            /**
             * Disable an item (disable clicking).
             *
             * @param {number|String|Element} id - Identifier of the item to enable.
             *
             * @return {this}
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            disableItem: function (id) {

                var item = this.getItem(id);

                item && item.elements.container.addClassName('disabled');
                item.disabled = true;
                return this;
            },

            /**
             * Unselect every currently selected items
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            unselectAll: function () {
                while (this.selectedItems.length > 0) {
                    this.unselectItem(this.selectedItems[0].id);
                }
            },

            /**
             * Select every currently unselected items.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            selectAll: function () {
                while (this.unselectedItems.length > 0) {
                    this.selectItem(this.unselectedItems[0].id);
                }
            },

            /**
             * Toggle the specified item.
             *
             * @param {Object[]} options       - the item itself or just its name.
             * @param {String} [options.name]  - Name identifier for the item to select.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            toggleItem: function (options) {

                var item = false,
                    previousItem;

                if (options.name) {
                    item = options;
                } else {
                    item = this.getItem(options);
                }

                if (!item) {
                    this.dispatchEvent('onClick', [item], this);
                    return;
                }

                // Toggle only if the item is enabled
                if (!item.disabled) {
                    if (item.isSelected) {
                        this.unselectItem(item);
                    } else {
                        this.selectItem(item);
                    }
                    // If the current mode allows only one section shown simultaneously, hide the element currently displayed
                    if (item.accordionId && this._isExclusive(item.accordionId)) {
                        previousItem = this._getSelectedItemsByAccordion(item.accordionId)[0];

                        if (previousItem && previousItem !== item.id) {
                            this.unselectItem(previousItem);
                        }
                    }

                    this.dispatchEvent('onChange', [item, this.selectedItems, this.unselectedItems], this);
                    this.dispatchEvent('onClick', [item], this);

                    // Need to remove border in style mode when there are no embedded items
                    if (this.options.styled && this.embeddedItems === 0) {
                        if (this.selectedItems.length === 0) {
                            this.elements.container.removeClassName('styled');
                        } else {
                            this.elements.container.addClassName('styled');
                        }
                    }
                }

            },

            /**
             * Adds one or many item(s).
             *
             * @param {Object[]}    options                         - The available options.
             * @param {String}      [options.title]                 - The accordion item title, showed from beginning.
             * @param {String}      [options.name]                  - Name identifier for the item to select.
             * @param {Element}     [options.trigger]               - Element that will trigger item's content on click.
             * @param {String}      [options.content]               - The accordion item content, showed when clicking on the corresponding title.
             * @param {Function}    [options.handler]               - Function to be called on item click.
             * @param {String}      [options.accordionId]           - Id of the existing parent accordion where we want to add the item. Default main accordion.
             * @param {Boolean}     [options.accordion]             - True if the item will contain a nested accordion.
             * @param {Boolean}     [options.disabled=false]        - True if the item is disabled by default.
             * @param {Boolean}     [options.items.selected=false]  - True to select item on accordion startup.
             *
             * @returns {this}
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            addItem: function (options) {

                var that = this;

                Utils.splat(options).forEach(function (option) {
                    that._addItem(option, that.elements.container);
                });

                return this;
            },

            /**
             * Adds an accordion item.
             *
             * @param {Object}      options                         - The available options.
             *
             * @param {String}      [options.title]                 - The accordion item title, showed from begining.
             * @param {String}      [options.name]                  - Name identifier for the item to select.
             * @param {Element}     [options.trigger]               - Element that will triger item's content on click.
             * @param {String}      [options.content]               - The accordion item content, showed when clicking on the corresponding title.
             * @param {Function}    [options.handler]               - Function to be called on item click.
             * @param {String}      [options.accordionId]           - Id of the existing parent accordion where we want to add the item. Default main accordion.
             * @param {Boolean}     [options.accordion]             - True if the item will contain a nested accordion.
             * @param {Boolean}     [options.disabled=false]        - True if the item is disabled by default.
             * @param {Boolean}     [options.items.selected=false]  - True to select item on accordion startup.
             *
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _addItem: function (options) {

                var parentAccordion,
                    cls = options.className || '',
                    item = {},
                    handler = options.handler,
                    nestedAccordion, nestedAccordionContainer,
                    that = this,
                    unselectedItem = [];

                // Will add in main accordion by default; or in the specified subAccordion if some
                if (options.accordionId) {
                    parentAccordion = this._getSubAccordion(options.accordionId);
                    parentAccordion = (parentAccordion) ? (parentAccordion) : (this.subAccordions[0]);
                } else {
                    parentAccordion = this.subAccordions[0];
                }

                if (!parentAccordion || !parentAccordion.container) {
                    return;
                }

                // Keep a reference to the accordion containing this item
                item.accordionId = parentAccordion.id;

                item.id = Utils.getUUID().substr(0, 6);

                if (!options.name) {
                    item.name = 'item-' + item.id;
                } else {
                    item.name = options.name;
                }

                if (options.disabled) {
                    cls += ' disabled';
                    item.disabled = true;
                } else {
                    item.disabled = false;
                }

                // Attached content to a trigger if some
                if (options.trigger) {
                    options.trigger.addEvent('onClick', function () {
                        that.toggleItem(item.id);
                    });
                }

                item.isSelected = false;

                this._buildAccordionItem(item, options, cls);

                // Specific event on item
                if (handler && UWA.is(handler, 'function')) {
                    item.elements.container.addEvent('click', function () {
                        handler();
                    });
                }

                if (options.accordion) {
                    // Add a new accordion to inject in item's content
                    options.accordion.parentItemId = item.id;
                    options.accordion.className = (options.accordion.className) ? (options.accordion.className + ' ' + this.name) : (this.name);
                    nestedAccordion = this._addSubAccordion(options.accordion);

                    if (nestedAccordion && nestedAccordion.container) {

                        nestedAccordionContainer = nestedAccordion.container;

                        if (options.accordion.items) {
                            options.accordion.items.forEach(function (itemOptions) {
                                itemOptions.accordionId = nestedAccordion.id;
                                itemOptions.globalOptions = nestedAccordion.options;
                                that._addItem(itemOptions);
                            });
                        }

                        nestedAccordionContainer.inject(item.elements.content);
                    }
                }

                // Add item in parent DOM and save it in our array
                this.items.push(item);
                item.elements.container.inject(parentAccordion.container);

                // If selected on start, display content, else mark as unselected.
                if (options.selected) {
                    this.toggleItem(item);
                } else {
                    unselectedItem.id = item.id;
                    unselectedItem.accordionId = item.accordionId;
                    this.unselectedItems.push(unselectedItem);
                }
            },

            /**
             * Removes one or many specified item(s) from the accordion.
             *
             * @param {Object[]} options - The item itself or just its name.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            removeItem: function (options) {

                var item = false, index;

                if (options.name) {
                    item = options;
                } else {
                    item = this.getItem(options);
                }

                if (!item) {
                    return;
                }

                item.elements.container.destroy();
                item.elements.container = null;

                index = this.items.indexOf(item);
                if (index > -1) {
                    this.items.splice(index, 1);
                }

                index = this._getUnselectedItemPosition(item.accordionId, item.id);
                if (index > -1) {
                    this.unselectedItems.splice(index, 1);
                }

                index = this._getSelectedItemPosition(item.accordionId, item.id);
                if (index > -1) {
                    this.selectedItems.splice(index, 1);
                }

            },

            /**
             * Retrieves the specified item from the accordion.
             *
             * @param {number|String|Element} id - Identifier of the item to retrieve. Could be position, id, or name.
             * @returns {Object} - Item object if retrieved, otherwise false.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            getItem: function (id) {

                var itemPosition, itemsLength,
                    item = false;

                // Retrieves the item
                for (itemPosition = 0, itemsLength = this.items.length; itemPosition < itemsLength; itemPosition += 1) {
                    item = this.items[itemPosition];
                    // If argument is a Node, compare to item's HTML element
                    if (id && id.nodeType && (item.elements.container === id)) {
                        break;
                        // If argument is a number, compare to item's index position
                        // If argument is a String, compare to item's unique id or tab's name
                    } else if (itemPosition === id || item.id === id || item.name === id) {
                        break;
                    }

                    item = false;
                }

                return item;
            },

            /**
             * Change the content of the specified item.
             *
             * @param {number|String|Element} id - Identifier of the item to retrieve.
             * @param {String} content           - The new content.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            setContent: function (id, content) {

                var oldContent,
                    item = this.getItem(id);

                if (item) {
                    oldContent = item.elements.container.getElementsByClassName('content-wrapper')[0];
                    oldContent.destroy();

                    item.elements.wrapper = UWA.createElement('div', {
                        'class': 'content-wrapper'
                    });

                    item.elements.content = UWA.createElement('div', {
                        'class': 'content',
                        html: content || ''
                    });

                    item.elements.content.inject(item.elements.wrapper);

                    item.elements.wrapper.inject(item.elements.container);
                }

            },

            /**
             * Change the title of the specified item.
             *
             * @param {number|String|Element} id - Identifier of the item to retrieve.
             * @param {String} title             - The new title.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            setTitle: function (id, title) {

                var oldTitle,
                    item = this.getItem(id);

                if (item) {
                    oldTitle = item.elements.container.getElementsByClassName(this.TITLE_CLASSNAME)[0];

                    oldTitle.destroy();

                    item.title = UWA.createElement('div', {
                        'class': this.TITLE_CLASSNAME + ' ',
                        html: title || ''
                    });

                    item.title.inject(item.elements.container, 'top');
                }

            },

            /**
             * Give the status of the specified item.
             *
             * @param {number|String|Element} id - Identifier of the item to retrieve.
             * @returns {Boolean}                - `true` if the specified item is selected, otherwise `false`.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            isSelected: function (id) {
                var item = this.getItem(id);
                return item && item.isSelected;
            },

            /**
             * Provide the currently selected items.
             * @returns {Object[]} this.selectedItems
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            getSelectedItems: function () {
                return this.selectedItems;
            },

            /**
             * Retrieves every selected items that belongs to th given accordion.
             *
             * @param {String} accordionId - Accordion identifier.
             * @returns {Object[]}         - Selected items that belongs to the given accordion.
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _getSelectedItemsByAccordion: function (accordionId) {

                var accordionItems = [];

                this.selectedItems.forEach(function (selectedItem) {
                    if (selectedItem.accordionId === accordionId) {
                        accordionItems.push(selectedItem.id);
                    }
                });

                return accordionItems;
            },

            /**
             * Retrieves the position of the given item in the selected items list.
             *
             * @param {String} accordionId - Identifier of the subAccordion containing this item.
             * @param {String} itemId      - Identifier of the item.
             * @returns {number}           - The position of the item if present, -1 otherwise.
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _getSelectedItemPosition: function (accordionId, itemId) {

                var i, l,
                    item;

                for (i = 0, l =  this.selectedItems.length; i < l; i++) {
                    item = this.selectedItems[i];
                    if (item.accordionId === accordionId && item.id === itemId) {
                        return i;
                    }
                }

                return -1;
            },

            /**
             * Provide the currently unselected items.
             * @returns {Object[]} this.unselectedItems
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            getUnselectedItems: function () {
                return this.unselectedItems;
            },

            /**
             * Retrieves the position of the given item in the unselected items list.
             *
             * @param {String} accordionId - Identifier of the subAccordion containing this item.
             * @param {String} itemId      - Identifier of the item.
             * @returns {number} - The position of the item if present, -1 otherwise.
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            _getUnselectedItemPosition: function (accordionId, itemId) {

                var i, l,
                    item;

                for (i = 0, l =  this.unselectedItems.length; i < l; i++) {
                    item = this.unselectedItems[i];
                    if (item.accordionId === accordionId && item.id === itemId) {
                        return i;
                    }
                }

                return -1;
            },

            /**
             * Show the accordion only if has items.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            show: function () {
                this.items && this._parent();
            },

            /**
             * Main event handler for item click.
             * @param {Event} event - The event.
             * @private
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             */
            eventHandler: function (event) {

                var element = Event.getElement(event),
                    aboveTitle = (element.hasClassName(this.TITLE_CLASSNAME) && element) || element.getParent('.' + this.TITLE_CLASSNAME),
                    aboveItem = aboveTitle && aboveTitle.getParent(),
                    item;

                if (aboveItem && aboveItem.id) {
                    item = this.getItem(aboveItem.id);
                    // If clicked on button with button enabled or if it's not with a click anywhere on title
                    if (!item.button || (item.button && (element.hasClassName('btn') || element.getParent().hasClassName('btn')))) {
                        this.toggleItem(item);
                    }
                }
            },

            /**
             * Main method for handling events.
             * @memberof module:DS/UIKIT/Accordion.Accordion#
             * @private
             */
            handleEvents: function () {
                // Handle events once for every accordion / nested accordion.
                this.elements.container.addEvent('click', this.eventHandler.bind(this));
            }
        };

        return Abstract.extend(Accordion);

    });

/**
 * A generic toggle control, can be checkbox, radio or switches.
 * @module DS/UIKIT/Input/Toggle
 * @extends DS/UIKIT/Input
 */
define('DS/UIKIT/Input/Toggle',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'DS/UIKIT/Input'
    ],
    function (UWA, Element, Event, Utils, Input) {

        'use strict';

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) { return; }
            klasses = klasses.split(' ');

            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/(toggle-)?(xsmall|small|large|default|primary|info|warning|error|success|switch|inline)$/);

                if (match && !match[1]) {
                    if (match[0] === 'small') {
                        klasses[i] = 'toggle-sm';
                    } else if (match[0] === 'large') {
                        klasses[i] = 'toggle-lg';
                    } else if (match[0] === 'xsmall') {
                        klasses[i] = 'toggle-xs';
                    } else {
                        klasses[i] = 'toggle-' + klasses[i];
                    }
                }
            }
            return klasses.join(' ');
        }

        /**
         * @lends module:DS/UIKIT/Input/Toggle.Toggle#
         */
        var Toggle = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            name: 'toggle',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            defaultOptions: {
                type: 'radio',
                className: '',
                checked: false
            },

            /**
             * A generic toggle control, can be checkbox, radio or switches.
             *
             * @example
             * require(['DS/UIKIT/Input/Toggle'], function (Toggle) {
             *     new Toggle({ name: "optionsRadios", id:"optionsRadios1", value: "option1", label: "...", checked: true }).inject(body);
             *     new Toggle({ name: "optionsRadios2", value: "male", className: "primary"}).check().inject(body);
             *     new Toggle({ type: "checkbox", id:"optionCheckbox1", value: "", label: "...", checked: true }).inject(body);
             *     new Toggle({ type: "checkbox" }).setValue("female").setClassName("primary").inject(body);
             *     new Toggle({ type: "switch", id:"optionSwitch1", value: "", label: "..." }).check().inject(body);
             * });
             *
             * @param {Object} options                         - Available options.
             *
             * @param {String}  [options.className]            - An optional className to apply to the container.
             * @param {Object}  [options.attributes]           - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}  [options.value]                - The toggle input value.
             * @param {String}  [options.id]                   - Sets the input toggle id.
             * @param {String}  [options.name]                 - Sets the input toggle name.
             * @param {Boolean} [options.disabled=false]       - Whether the input toggle should be disabled from start.
             * @param {String}  [options.type='toggle']        - Set the toggle type. Available options: 'radio', 'checkbox', 'switch'.
             * @param {Boolean} [options.checked=false]        - Whether the toggle input should be checked from start.
             * @param {String}  [options.label]                - The toggle label in case you don't want the value to be displayed as a label.
             *                                                   If set, will not be overwritten by a setValue afterward.
             * @param {Boolean} [options.required=false]       - Set the input toggle as required, only used inside a UIKIT.Form.
             * @param {Object}  [options.events]               - The available events.
             *
             * @param {Object}    [options.events.onChange]    - Invoked when the input toggle state changes.
             * @param {Object}    [options.events.onClick]     - Invoked when the user click on the input toggle.
             * @param {Object}    [options.events.onMouseDown] - Invoked when the user press the mouse button on the input toggle.
             *
             * @constructs Toggle
             * @memberof module:DS/UIKIT/Input/Toggle
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Input#setFocus as #setFocus
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             * @borrows module:DS/UIKIT/Input.Input#setDisabled as #setDisabled
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#enable as #enable
             * @borrows module:DS/UIKIT/Input.Input#disable as #disable
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             * @borrows module:DS/UIKIT/Input.Input#setValue as #setValue
             * @borrows module:DS/UIKIT/Input.Input#getValue as #getValue
             */
            init: function (options) {
                options = options || {};

                if (!options.id) {
                    options.id = 'radio-' + Utils.getUUID().substring(0, 6);
                }

                this._parent(options);

                // Override the previously added classes
                this.setClassName(options.className);
            },

            /**
             * Build the native input element.
             * @returns {Element} - The native input element
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             * @private
             */
            buildInput: function () {
                var element = UWA.createElement('input', { type: this.options.type === 'radio' ? 'radio' : 'checkbox' });
                if (this.options.required) {
                    element.setAttribute('required', true);
                }
                return element;
            },

            /**
             * Builds the input skeleton.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             * @private
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options;

                elements.content = elements.input = this.buildInput().set(options.attributes);
                elements.input.id = this.options.id;
                elements.label = UWA.createElement('label', {
                    text: options.label,
                    'class': 'control-label',
                    attributes: { 'for': this.options.id }
                });

                elements.container = UWA.createElement('div', {
                    html: [
                        elements.input,
                        elements.label
                    ]
                });

                elements.container.addClassName(this.getClassNames());

                // Handle checked option
                this.setCheck(options.checked);

                // This will call handleEvents
                this.setDisabled(options.disabled);
            },

            /**
             * Main function for handling events.
             * Override UIKIT/Input because of how we handle label clicking.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             * @private
             */
            handleEvents: function () {

                var that = this,
                    elements = this.elements;

                function dispatch (event) {
                    return that.dispatchEvent.bind(that, event);
                }

                /** Custom dispatcher to prevent the double onClick fired when clicking label */
                function customDispatch (event) {
                    return function (e) {
                        var target = Event.getElement(e);
                        if (target === this.elements.label && event !== 'onClick') {
                            this.dispatchEvent(event, e);
                        } else if (target === this.elements.input) {
                            this.dispatchEvent(event, e);
                        }
                    }.bind(that);
                }

                if (!this.events) {
                    this.events = {
                        container: {
                            click: customDispatch('onClick'),
                            mousedown: customDispatch('onMouseDown')
                        },
                        input: {
                            change: dispatch('onChange'),
                            keydown: dispatch('onKeyDown'),
                            focus: this.setFocus.bind(this, true),
                            blur: this.setFocus.bind(this, false)
                        }
                    };
                }

                if (this.isDisabled()) {
                    elements.input.removeEvents(this.events.input);
                    elements.container.removeEvents(this.events.container);
                } else {
                    // Only add state classes if it is a custom input
                    elements.container.addEvents(this.events.container);
                    elements.input.addEvents(this.events.input);
                }
            },

            /**
             * Set the focus on this input.
             * Override UIKIT/Input for ie.
             * @param  {Boolean} [focus=true] - If false, remove the focus.
             * @returns {Toggle}              - The instance.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            setFocus: function () {
                // When clicking on a <label> handling this input, the input state
                // can change. On IE8 (and maybe other browsers), the onChange and
                // onClick events are not fired by clicking on the <label>, but the
                // onBlur and onFocus are. So we sync the input here.
                // This should not harm other browsers
                this.syncInput();
                return this;
            },

            /**
            * Get if this input is checked.
            * @returns {Boolean} True if is checked
            * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
            */
            isChecked: function () {
                return this.elements.input.checked;
            },

            /**
             * Check or uncheck the input.
             * @param  {Boolean} [checked=true] - If `false`, uncheck the input.
             * @returns {Toggle}                - The instance.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            setCheck: function (checked) {
                this.elements.input.checked = checked !== false;
                return this;
            },

            /**
             * Synchronize the control display value and label.
             * Override UIKIT/Input to sync the label.
             * @private
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            syncInput: function () {
                if (!UWA.is(this.options.label)) {
                    this.elements.label.setText(this.getValue());
                }
            },

            /**
             * Set the radio label.
             * @param  {String} text - The new label.
             * @returns {Toggle}     - The instance.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            setLabel: function (text) {
                this.options.label = text;
                this.elements.label.setText(text);
                return this;
            },

            /**
             * Returns the text of the label.
             * @returns {String} The label content
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            getLabel: function () {
                return this.elements.label.getText();
            },

            /**
             * Shorthand for setCheck.
             * @returns {Toggle} - The instance.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            check: function () {
                return this.setCheck();
            },

            /**
             * Shorthand for setCheck.
             * @returns {Toggle} - The instance.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            uncheck: function () {
                return this.setCheck(false);
            },

            /**
             * Set the className for this radio.
             * @param  {String} klasses - A list of classes or a single class.
             * @returns {Toggle}        - The instance.
             * @memberof module:DS/UIKIT/Input/Toggle.Toggle#
             */
            setClassName: function (klasses) {
                if (this.options.type === 'switch') {
                    klasses = klasses ? klasses + ' switch' : 'switch';
                }

                this.options.className = parseClassName(klasses);
                this.getContent().className = this.getClassNames();
                return this;
            }
        };

        return Input.extend(Toggle);
    });

/**
 * The password control.
 * @module DS/UIKIT/Input/Password
 * @extends DS/UIKIT/Input/Text
 */
define('DS/UIKIT/Input/Password',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'DS/UIKIT/Input/Text'
    ],


    function (UWA, Element, Event, Client, Text) {

        'use strict';

        /**
         * @lends module:DS/UIKIT/Input/Password.Password#
         */
        var Password = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Input/Password.Password#
             */
            name: '',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Input/Password.Password#
             */
            defaultOptions: {
                className: '',
                multiline: false
            },

            /**
             * The password control.
             *
             * @example
             * require(['DS/UIKIT/Input/Password'], function (Password) {
             *     new Password({ placeholder: "Enter your password..." }).inject(body);
             * });
             *
             * @param {Object} options                       - Available options.
             *
             * @param {String}  [options.className]          - An optional className to apply to the container.
             * @param {Object}  [options.attributes]         - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}  [options.value]              - The starting input value.
             * @param {String}  [options.id]                 - Sets the input password id.
             * @param {String}  [options.name]               - Sets the input password name.
             * @param {Boolean} [options.disabled=false]     - Whether the input password should be disabled from start.
             * @param {String}  [options.placeholder]        - Set the input password placeholder.
             * @param {number}  [options.maxlength]          - Sets the maxlength for this input text.
             * @param {Boolean} [options.required=false]     - Set the input text as required, only used inside a UIKIT.Form.
             * @param {String}  [options.pattern]            - Set the pattern for this input to test its value against, only used inside a UIKIT.Form.
             * @param {Object}  [options.events]             - The available events.
             *
             * @param {Object}    [options.events.onChange]    - Invoked when the input password value changes.
             * @param {Object}    [options.events.onClick]     - Invoked when the user click on the input password.
             * @param {Object}    [options.events.onMouseDown] - Invoked when the user press the mouse button on the input password.
             * @param {Object}    [options.events.onKeyDown]   - Invoked when the user press a key while focusing the input password.
             *
             *
             * @constructs Password
             * @memberof module:DS/UIKIT/Input/Password
             *
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input/Text.Text.#setFocus as #setFocus
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             * @borrows module:DS/UIKIT/Input.Input#setDisabled as #setDisabled
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#enable as #enable
             * @borrows module:DS/UIKIT/Input.Input#disable as #disable
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             * @borrows module:DS/UIKIT/Input.Input#setValue as #setValue
             * @borrows module:DS/UIKIT/Input/Text.Text#getValue as #getValue
             * @borrows module:DS/UIKIT/Input/Text.Text#setClassName as #setClassName
             */
            init: function (options) {
                this._parent(options);
            },

            /**
             * Build the native input element.
             * Override UIKIT/Input
             * @returns {Element} - The native input element
             * @private
             * @memberof module:DS/UIKIT/Input/Password.Password#
             */
            buildInput: function () {

                var attributes = {},
                    options = this.options,
                    element = UWA.createElement('input', { type: 'password' });

                // Set attributes if needed
                ['placeholder', 'required', 'pattern', 'maxlength'].forEach(function (pref) {
                    if (options[pref]) { attributes[pref] = options[pref]; }
                });
                element.set(attributes);

                return element;
            }
        };

        return Text.extend(Password);
    });

/**
 * The button group control.
 * @module DS/UIKIT/Input/ButtonGroup
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Input/ButtonGroup',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Input/Button'
    ],


    function (UWA, Element, Event, Client, Abstract, Button) {

        'use strict';

        function parseClassName (klasses) {

            var i, l, match;

            if (klasses) {

                klasses = klasses.split(' ');

                for (i = 0, l = klasses.length; i < l; i++) {
                    match = klasses[i].match(/(btn-grp-)?(xsmall|small|large|vertical)$/);

                    if (match && !match[1]) {
                        if (match[0] === 'small') {
                            klasses[i] = 'btn-grp-sm';
                        } else if (match[0] === 'large') {
                            klasses[i] = 'btn-grp-lg';
                        } else if (match[0] === 'xsmall') {
                            klasses[i] = 'btn-grp-xs';
                        } else {
                            klasses[i] = 'btn-grp-' + klasses[i];
                        }
                    }
                }
                klasses = klasses.join(' ');
            }

            return klasses;
        }

        /**
         * @lends module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
         */
        var ButtonGroup = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            name: 'btn-grp',

            /**
             * @property {Object} - The component default options
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             * @private
             */
            defaultOptions: {
                className: '',
                disabled: false
            },

            /**
             * @property {Button[]} - The inner buttons
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             * @private
             */
            buttons: null,

            /**
             * The button group control.
             *
             * @example
             * require(['DS/UIKIT/Input/ButtonGroup'], function (ButtonGroup) {
             *     new ButtonGroup({
             *         buttons: [
             *             new Button({ value: "Left" }),
             *             new Button({ value: "Middle" }),
             *             new Button({ value: "Right" })
             *         ],
             *         events: {
             *             onClick: function (e, button) { console.log(button); }
             *         }
             *     }).inject(body);
             * });
             *
             * @param {Object} options                      - Available options.
             * @param {String}   [options.className='']     - Class names to apply on dom elements built by this control. 'Vertical' for alternate button position.
             * @param {String}   [options.disabled=false]   - Set the input disabled immediatly.
             * @param {String}   [options.type='none']      - Set the underlining button behaviour. Available options are 'checkbox', 'radio', 'none'
             * @param {Button[]|Object[]} options.buttons   - Either UIKIT.Button array or an array of UIKIT.Button config.
             * @param {Object}   [options.events]           - Available events.
             *
             * @param {Object}     [options.events.onClick] - When the user click on the input.
             *
             * @constructs ButtonGroup
             * @memberof module:DS/UIKIT/Input/ButtonGroup
             */
            init: function (options) {

                if (options.className) {
                    options.className = parseClassName(options.className);
                }

                this._parent(options);

                this.events = null;
                this.buttons = [];

                this.getContent();
            },

            /**
             * Returns control content.
             * @returns {Element} - Control container.
             * @private
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            getContent: function () {
                if (!this.elements.container) {
                    this.buildSkeleton();
                }
                return this.elements.container;
            },

            /**
             * Builds the input skeleton.
             * @private
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            buildSkeleton: function () {

                var that = this,
                    elements = this.elements,
                    options = this.options;

                elements.container = UWA.createElement('div', {
                    'class': this.getClassNames()
                });

                options.buttons.forEach(function (button) {
                    var btn;

                    if (button instanceof Button === false) {
                        btn = new Button(UWA.clone(button));
                    } else {
                        btn = button;
                    }

                    btn.inject(elements.container);
                    that.buttons.push(btn);
                });

                this.setDisabled(options.disabled);
            },

            /**
             * Main function for handling events.
             * @private
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            handleEvents: function () {

                var that = this;

                if (!this.events) {
                    this.events = {
                        click: function (event) {

                            var target = Event.getElement(event),
                                button = that.getButton(target) || that.getButton(target.getParent());

                            if (button) {
                            // Special case for keeping dropdown button pressed
                                if (!button.dropdown) {
                                    that.toggleActive(button);
                                }
                                that.dispatchEvent.call(that, 'onClick', [event, button]);
                            }
                        }
                    };
                }

                if (this.isDisabled()) {
                    this.elements.container.removeEvents(this.events);
                } else {
                    this.elements.container.addEvents(this.events);
                }
            },

            /**
             * Set the input as disabled.
             * @param {Boolean} [disabled=true] - If false, enable the input.
             * @returns {ButtonGroup}           - The instance.
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            setDisabled: function (disabled) {
                if (typeof disabled === 'undefined') {
                    disabled = true;
                }

                // Set the buttons to disable
                this.buttons.forEach(function (button) {
                    button.setDisabled(disabled);
                });

                // Add / remove a 'disabled' class
                this.elements.container.toggleClassName('disabled', disabled);
                this.handleEvents();
                return this;
            },

            /**
             * Get if this button group is disabled.
             * @returns {Boolean}
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            isDisabled: function () {
                return this.buttons.every(function (button) {
                    return button.isDisabled();
                });
            },

            /**
             * Retrieves the specified Button from the Button.
             * @param  {Button|number|Element} id - A button identifier.
             * @returns {Button}                  - Button instance if retrieved, otherwise false.
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            getButton: function (id) {

                var i, l,
                    button = false;

                if (id instanceof Button) {
                    button = id;
                } else {
                    // Retrieves the button
                    for (i = 0, l = this.buttons.length; i < l; i += 1) {
                        button = this.buttons[i];
                        // If argument is a Node, compare to button's HTML element
                        if (id && id.nodeType && button.getContent() === id) {
                            break;
                            // If argument is a number, compare to button's index position
                        } else if (i === id) {
                            break;
                        }

                        button = false;
                    }
                }

                return button;
            },

            /**
             * Set the specified button as active (giving him a pressed state).
             * @param {Button|number|Element} id - A button identifier.
             * @param {Boolean} [active=true]    - If false, remove the active.
             * @return {ButtonGroup}             - The instance.
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            setActive: function (id, active) {

                var button = this.getButton(id);

                if (typeof active === 'undefined') {
                    active = true;
                }

                if (this.options.type === 'checkbox') {
                    button.setActive(active);
                } else if (this.options.type === 'radio') {
                    if (active) {
                        this.getActive().forEach(function (button) {
                            button.setActive(false);
                        });

                        button.setActive(true);
                    }
                }

                return this;
            },

            /**
             * Get all active buttons from the button group.
             * @returns {Button[]}
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            getActive: function () {
                return this.buttons.filter(function (button) {
                    if (button.isActive()) {
                        return true;
                    }
                });
            },

            /**
             * Toggle the active state for a specified button (giving / removing the pressed state).
             * @param {Button|number|Element} id - A button identifier.
             * @returns {Buttongroup}            - The instance.
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            toggleActive: function (id) {
                var button = this.getButton(id);
                if (button) { this.setActive(button, !button.isActive()); }
                return this;
            },

            /**
             * Get if a specified button is active.
             * @param {Button|number|Element} id - A button identifier.
             * @returns {Boolean}
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            isActive: function (id) {
                var button = this.getButton(id);
                if (button) { return button.isActive(); }
            },

            /**
             * Set the className for this button group.
             * @param {String} klass  - A list of classes or a single class.
             * @returns {ButtonGroup} - The instance.
             * @memberof module:DS/UIKIT/Input/ButtonGroup.ButtonGroup#
             */
            setClassName: function (klass) {
                this.options.className = parseClassName(klass);
                this.getContent().className = this.getClassNames();
                return this;
            }
        };

        return Abstract.extend(ButtonGroup);
    });

/**
 * A javascript file input.
 * @module DS/UIKIT/Input/File
 * @extends module:DS/UIKIT/Input
 */
define('DS/UIKIT/Input/File',
    [
        'UWA/Core',
        'UWA/Utils',
        'DS/UIKIT/Input',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],

    function (UWA, Utils, Input, i18n) {

        'use strict';

        var VARIATION_CLASSES = ['small', 'large', 'block', 'primary', 'success', 'default', 'info', 'warning', 'error'],
            REGEXP = new RegExp('^(' + VARIATION_CLASSES.join('|') + ')$');

        /**
         * Will look for specific REGEXP pattern in the classes passed
         * and will perform some transformation on it. (e.g. small > input-sm)
         */
        function parseClassName (classes) {

            // Return empty string if no valid classes
            if (!classes) return '';

            var parsed = [],
                split = classes.split(' ');

            split.forEach(function (klass, i) {
                var match = klass.match(REGEXP);

                if (match) {
                    if (match[0] === 'small') {
                        parsed[i] = 'input-group-sm';
                    } else if (match[0] === 'large') {
                        parsed[i] = 'input-group-lg';
                    } else {
                        parsed[i] = 'btn-' + klass;
                    }
                } else {
                    parsed[i] = klass;
                }
            });

            return parsed.join(' ');
        }

        /**
         * @lends module:DS/UIKIT/Input/File.File#
         */
        var File = {

            /**
             * @property {Object} defaultOptions - The default file input options.
             * @private
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            defaultOptions: {
                input: true,
                buttonBefore: true,
                buttonText: i18n.browse,
                placeholder: i18n.selectFile
            },

            /**
             * A javascript file input.
             * @example
             * require(['DS/UIKIT/Input/File'], function (File) {
             *     new File({
             *         name: 'file-input',
             *         placeholder: 'Pick a file...'
             *     }).inject(body);
             * });
             *
             * @param {Object} options                              - Available options.
             *
             * @param {String}  [options.className='']              - An optional className to apply to the file input container in case you want to apply
             *                                                        custom styles through your stylesheet. Special values are: `small` `large`.
             * @param {Object}  [options.attributes]                - A set of attributes to set on the file input element (see UWA.Element.set).
             * @param {String}  [options.id]                        - Sets the file input id.
             * @param {String}  [options.name]                      - Sets the file input name. Useful when playing with form.
             * @param {Boolean} [options.disabled=false]            - The starting disabled state for the file input.
             * @param {String}  [options.placeholder]               - Sets the file input placeholder. Only used when `options.input` is `true`.
             * @param {Boolean} [options.required=false]            - Set the input text as required, only used inside a UIKIT.Form.
             * @param {Boolean} [options.input=true]                - Whether this file input should display a text input next to him for showing the files picked or not.
             * @param {Boolean} [options.multiple=false]            - Does the input accepts multiple file ?
             * @param {String}  [options.buttonText='Browse...']    - Sets the file input button initial text.
             * @param {String}  [options.buttonClassName='default'] - Sets the file input button class name.
             *                                                        Special values are: `primary` `success` `default` `info` `warning` `error`
             * @param {Boolean} [options.buttonBefore=true]         - Whether the button should be place before or after the text input.
             * @param {Object}  [options.events]                    - The file input events you can subscribe to.
             *
             * @param {Object} [options.events.onChange]            - Invoked when the input file value changes.
             * @param {Object} [options.events.onClick]             - Invoked when the user click on the input.
             * @param {Object} [options.events.onMouseDown]         - Invoked when the user press the mouse button on the input.
             * @param {Object} [options.events.onKeyDown]           - Invoked when the user press a key while focusing the input.
             *
             * @constructs File
             * @memberof module:DS/UIKIT/Input/File
             *
             * @borrows module:DS/UIKIT/Input.Input#inject as #inject
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Input#destroy as #destroy
             * @borrows module:DS/UIKIT/Input.Input#remove as #remove
             *
             * @borrows module:DS/UIKIT/Input.Input#dispatchEvent as #dispatchEvent
             * @borrows module:DS/UIKIT/Input.Input#addEvent as #addEvent
             * @borrows module:DS/UIKIT/Input.Input#addEvents as #addEvents
             * @borrows module:DS/UIKIT/Input.Input#addEventOnce as #addEventOnce
             * @borrows module:DS/UIKIT/Input.Input#removeEvent as #removeEvent
             * @borrows module:DS/UIKIT/Input.Input#hasEvent as #hasEvent
             *
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             *
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#enable as #enable
             * @borrows module:DS/UIKIT/Input.Input#disable as #disable
             *
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             */
            init: function (options) {
                options = options || {};
                options.className = parseClassName(options.className);
                options.buttonClassName = parseClassName(options.buttonClassName || 'default');
                this._parent(options);
            },

            /**
             * Builds the file input skeleton.
             * @private
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options;

                elements.container = UWA.createElement('div', {
                    'class': 'input-file input-group ' + options.className
                });

                // The replacing file button (has to be a span thanks to ie)
                elements.button = UWA.createElement('span', {
                    'class': 'btn btn-file ' + options.buttonClassName,
                    text: options.buttonText
                });

                // The hidden file input
                elements.input = UWA.createElement('input', {
                    type: 'file',
                    id: options.id || '',
                    attributes: options.attributes
                });
                // UWA seems to stringify so has to do it separately
                elements.input.multiple = !!options.multiple;

                elements.buttonGroup = UWA.createElement('span', {
                    'class': 'input-group-btn'
                });

                elements.button.inject(elements.buttonGroup);
                elements.buttonGroup.inject(elements.container);
                elements.input.inject(elements.button);

                if (options.input) {
                    elements.textfield = UWA.createElement('input', {
                        type: 'text',
                        'class': 'form-control',
                        placeholder: options.placeholder,
                        required: options.required,
                        attributes: { readonly: true }
                    });
                    elements.textfield.inject(elements.container, options.buttonBefore ? '' : 'top');
                }

                // This will call handleEvents
                this.setDisabled(options.disabled);
            },

            /**
             * Main function for handling events.
             * @memberof module:DS/UIKIT/Input/File.File#
             * @private
             */
            handleEvents: function () {

                var that = this,
                    elements = this.elements;

                this._parent();

                if (!this.fileEvents) {
                    this.fileEvents = {};
                    // IE does not support readonly attribute. blur on focus to prevent text selection seems to be the ---hardest woooord--- best solution.
                    // http://stackoverflow.com/questions/17319228/use-readonly-attribute-in-input-without-changing-the-cursor
                    if (Utils.Client.Engine.ie) {
                        this.fileEvents.textfield = {
                            focus: function () {
                                that.elements.textfield.blur();
                            }
                        };
                    }
                }

                if (this.isDisabled()) {
                    this.fileEvents.textfield && elements.textfield && elements.textfield.removeEvents(this.fileEvents.textfield);
                } else {
                    this.fileEvents.textfield && elements.textfield && elements.textfield.addEvents(this.fileEvents.textfield);
                }
            },


            /**
             * Synchronize the control display with the native input state.
             * @private
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            syncInput: function () {

                var elements = this.elements,
                    options = this.options,
                    filesCount;

                // Sync the input file value with the text field if it exists
                if (options.input) {
                    // In case of multiple, display the number of files selected
                    filesCount = options.multiple && elements.input.files ? elements.input.files.length : 1;
                    elements.textfield.value = filesCount > 1 ? filesCount + ' ' + i18n.selectedFiles : this.getValue();
                    if (this.getValue().length) {
                        this.elements.textfield.addClassName('files-uploaded');
                    } else {
                        this.elements.textfield.removeClassName('files-uploaded');
                    }
                }
            },

            /**
             * We can not set value other than empty with file input.
             * @private
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            setValue: function () {
                this.elements.input.value = '';
                this.syncInput();
            },

            /**
             * Set the textfield input value.
             * @param {String} value - The textfield value.
             * @private
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            setText: function (value) {
                this.options.input && this.elements.textfield.setText(value);
            },

            /**
             * Get the input value. In case of multiple, will return the files separated by a `;`.
             * @returns {String} - The input value.
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            getValue: function () {

                var value;

                function removeGibberish (path) {
                    return path.replace(/\\/g, '/').replace(/.*\//, '') || '';
                }

                if (this.options.multiple) {
                    value = [].map.call(this.elements.input.files, function (file) {
                        return file.name;
                    }).join(';');
                } else {
                    value = removeGibberish(this.elements.input.value);
                }

                return value;
            },

            /**
             * Set the input as disabled. Will remove events.
             * Overrides UIKIT/Input to also set the button and text as disabled.
             * @param {Boolean} [disabled=true] - If false, enable the input.
             * @returns {File}                  - The instance
             * @private
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            setDisabled: function (disabled) {
                this._parent(disabled);
                this.elements.button.toggleClassName('disabled', this.isDisabled());
                this.options.input && (this.elements.textfield.disabled = this.isDisabled());
                return this;
            },

            /**
             * Clear selected files.
             * @returns {File} - The instance
             * @memberof module:DS/UIKIT/Input/File.File#
             */
            clear: function () {
                this.setValue();
                return this;
            }
        };

        return Input.extend(File);
    });

/**
 * An easy way to show additional content without altering the page layout.
 * @module DS/UIKIT/Modal
 * @requires DS/UIKIT/Tooltip
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Modal',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Tooltip',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],


    function (UWA, Element, Event, Client, Abstract, Tooltip, i18n) {

        'use strict';

        function isInsideIframe () {
            try {
                return window.self !== window.top;
            } catch (e) { return true; }
        }

        function addEvent (evnt, elem, func, capture) {
            if (elem.addEventListener)  // W3C DOM
                elem.addEventListener(evnt, func, capture);
            else if (elem.attachEvent) { // IE DOM
                elem.attachEvent('on' + evnt, func, capture);
            }
        }

        function addEvents (evnts, elem, capture) {
            Object.keys(evnts).forEach(function (evnt) {
                addEvent(evnt, elem, evnts[evnt], capture);
            });
        }

        /**
         * @lends module:DS/UIKIT/Modal.Modal#
         */
        var Modal = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            name: 'modal',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            defaultOptions: {
                className: '',
                animate: false,
                closable: true,
                overlay: true,
                visible: false,
                escapeToClose: true
            },

            /**
             * Modal visibility state.
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            isVisible: false,

            /**
             * An easy way to show additional content without altering the page layout.
             *
             * @example
             * require(['DS/UIKIT/Modal'], function (Modal) {
             *     var myButton = new Button({ value: "Click me"}).inject(body);
             *     var myModal = new Modal({
             *         closable: true,
             *         header: "<h4>Modal title</h4>",
             *         body:   "<p>One fine body</p>",
             *         footer: "<button type='button' class='btn btn-default'>Annuler</button> " +
             *                 "<button type='button' class='btn btn-primary'>OK</button>"
             *     }).inject(body);
             *     myButton.addEvent("onClick", function () {
             *         myModal.show();
             *     });
             * });
             *
             * @param {Object} options                         - The available options.
             *
             * @param {String}   [options.className]           - An optional class name. If 'fancy' will have special look.
             * @param {Boolean}  [options.animate=false]       - Should the modal be animated.
             * @param {Boolean}  [options.closable=false]      - Should the modal have a cross at top right.
             * @param {Boolean}  [options.escapeToClose=true]  - Whether to hide the dialog when `ESC` is pressed or not.
             * @param {Boolean}  [options.overlay=true]        - Should the modal display an overlay behind itself.
             * @param {Boolean}  [options.visible=false]       - Start the modal as visible after DOM injection.
             * @param {Element}  [options.renderTo]            - If specified will inject the modal inside this Element. If not will have to be injected manually.
             * @param {Element|String|Object} [options.header] - The header to append.
             * @param {Element|String|Object} [options.body]   - The body to append.
             * @param {Element|String|Object} [options.footer] - The footer to append.
             * @param {Object}   [options.events]              - The available events.
             *
             * @param {Function}   [options.events.onShow]     - Invoked when the modal is shown.
             * @param {Function}   [options.events.onHide]     - Invoked when the modal is hide.
             *
             * @constructs Modal
             * @memberof module:DS/UIKIT/Modal
             */
            init: function (options) {

                options = options || {};

                this._parent(options);
                this.options.animate = Client.Features.transitionsCSS && this.options.animate;
                this.buildSkeleton();
                this.handleEvents();

                // Handle renderTo option
                if (options.renderTo) {
                    this.inject(options.renderTo);
                }


            },

            /**
             * Get the modal header content.
             * @returns {Element} content - The header content.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            getHeader: function () {
                if (!this.elements.header) {
                    this.elements.header = UWA.createElement('div', {
                        'class': this.name + '-header'
                    }).inject(this.elements.content, 'top');
                }
                return this.elements.header;
            },

            /**
             * Get the modal body content.
             * @returns {Element} content - The body content.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            getBody: function () {
                return this.elements && this.elements.body;
            },

            /**
             * Get the modal footer content.
             * @returns {Element} content - The footer content.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            getFooter: function () {
                if (!this.elements.footer) {
                    this.elements.footer = UWA.createElement('div', {
                        'class': this.name + '-footer'
                    }).inject(this.elements.content);
                }
                return this.elements.footer;
            },

            /**
             * Change the modal header content.
             * @param {Element|String|Object} content - The new content.
             * @returns {Modal}                       - The instance.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            setHeader: function (content) {

                var that = this,
                    header = this.getHeader(),
                    options = this.options,
                    elements = this.elements;

                header.empty();

                // Make sure the closable stays due to the barbaric empty()
                if (options.closable) {
                    elements.close = UWA.createElement('span', {
                        'class': 'close fonticon fonticon-cancel',
                        events: {
                            click: function () { that.hide(); }
                        }
                    }).inject(header, 'top');

                    elements.closeTooltip = new Tooltip({ position: 'bottom', target: elements.close, body: i18n.close });
                }

                if (content) {
                    header.addContent(content);
                }

                return this;
            },

            /**
             * Change the modal body content.
             * @param {Element|String|Object} content - The new content.
             * @returns {Modal}                       - The instance.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            setBody: function (content) {
                if (this.elements.body) {
                    this.elements.body.empty();
                    this.elements.body.addContent(content);
                }
                return this;
            },

            /**
             * Change the modal footer content.
             * @param {Element|String|Object} content - The new content.
             * @returns {Modal} - The instance.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            setFooter: function (content) {
                var footer = this.getFooter();
                footer.empty();
                if (content) {
                    footer.addContent(content);
                }
                return this;
            },

            /**
             * Build HTML skeleton.
             * @protected
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            buildSkeleton: function () {

                var createElement = UWA.createElement,
                    elements = this.elements,
                    options = this.options;

                // Safe check if user called buildSkeleton directly
                if (elements.container) {
                    return;
                }

                // Build container
                elements.container = createElement('div', {
                    'class': this.getClassNames()
                });

                // Build wrapper
                elements.wrapper = createElement('div', {
                    'class': this.name + '-wrap'
                }).inject(elements.container);

                // Build content
                elements.content = createElement('div', {
                    'class': this.name + '-content'
                }).inject(elements.wrapper);

                // Build header
                if (UWA.is(options.header)) {

                    // Try to append `<h4>` if it is a string and not an html string
                    if (UWA.is(options.header, 'string') && !/<[\s\S]*>/i.test(options.header)) {
                        this.setHeader({ tag: 'h4', text: options.header });
                    } else {
                        this.setHeader(options.header);
                    }
                } else if (options.closable) {
                    this.setHeader();
                }

                // Build body
                elements.body = createElement('div', {
                    'class': this.name + '-body',
                    html: options.body
                }).inject(elements.content);

                // Build footer
                if (UWA.is(options.footer)) {
                    this.getFooter().addContent(options.footer);
                }

                // Handle overlay option
                if (options.overlay) {
                    elements.overlay = createElement('div', {
                        'class': this.name + '-overlay'
                    });
                }

                // Handle animate option
                if (options.animate) {
                    elements.container.addClassName('fade');
                    elements.overlay && elements.overlay.addClassName('fade');
                }

                // In case a DOM element was passed
                options.header = null;
                options.body = null;
                options.footer = null;
            },

            /**
             * Post injection hook to handle the visible option.
             * @protected
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            onPostInject: function (element) {
                // Keep reference for injecting overlay
                this.options.renderTo = element;

                if (this.options.visible || this.isVisible) {
                    this.isVisible = false;
                    this.show();
                }
            },

            /**
             * Toggle the modal.
             * @returns {Modal} - The instance.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            toggle: function () {
                return this[this.isVisible ? 'hide' : 'show']();
            },

            /**
             * Show the modal.
             * @returns {Modal} - The instance.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            show: function () {

                var that = this,
                    options = this.options,
                    elements = this.elements,
                    timeoutDuration = 50;

                // Safe check for destroyed modal
                if (!elements.container) { return; }

                if (!this.isVisible) {

                    // Update semaphore
                    this.isVisible = true;

                    if (elements.container.isInjected()) {
                        // Add the margin on body to avoid content movement
                        !isInsideIframe() && Element.addClassName.call(document.body, this.name + '-open');

                        elements.overlay && elements.overlay.inject(options.renderTo || document.body);
                        elements.container.setStyle('display', 'block');

                        if (options.animate) {
                            // A set timeout is needed to prevent batch of style with display property
                            setTimeout(function () {
                                // Check for elements is required in case a destroy was called right after a hide / show
                                // Check for isVisible in case someone called hide right after show
                                if (that.elements.container && that.isVisible) {
                                    that.elements.container.addClassName('in');
                                    that.elements.overlay && that.elements.overlay.addClassName('in');
                                    that.dispatchEvent('onShow');
                                }
                            }, timeoutDuration); // Cannot setTimeout 0 as it bugs in FF
                        } else {
                            that.elements.overlay && that.elements.overlay.addClassName('in');
                            that.dispatchEvent('onShow');
                        }
                    }
                }

                return this;
            },

            /**
             * Hide the modal.
             * @returns {Modal} - The instance.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            hide: function () {

                var that = this,
                    options = this.options,
                    elements = this.elements,
                    timeoutDuration = 150;

                function animating () {
                    // Needed to avoid removing modal if someone called show right after hide
                    if (!that.isVisible) {
                        // Check for elements is required in case a destroy was called right after a hide / show
                        if (that.elements.container) {
                            that.elements.container.setStyle('display', '');
                            that.elements.overlay && that.elements.overlay.remove();
                        }
                        // Remove the margin on body to avoid content movement
                        !isInsideIframe() && Element.removeClassName.call(document.body, that.name + '-open');
                        that.dispatchEvent('onHide');
                    }
                }

                // Safe check for destroyed modal
                if (!elements.container) { return; }

                if (this.isVisible) {

                    // Update semaphore
                    this.isVisible = false;

                    if (elements.container.isInjected()) {
                        elements.overlay && elements.overlay.removeClassName('in');
                        if (options.animate) {
                            elements.container.removeClassName('in');

                            setTimeout(function () {
                                animating();
                            }, timeoutDuration);
                        } else {
                            animating();
                        }
                    }
                }

                return this;
            },

            /**
             * Attach main modal events.
             * @protected
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            handleEvents: function () {
                var key, ESCAPE_KEY = 27;

                if (!this.events) {
                    this.events = {};
                    if (this.options.escapeToClose) {
                        this.events.document = {};
                        this.events.document.keyup = function (evt) {
                            key = evt.keyCode ? evt.keyCode : evt.which;
                            if (this.isVisible && key === ESCAPE_KEY) this.hide();
                        }.bind(this);
                        addEvents(this.events.document, document, true);
                    }
                }
            },

            /**
             * Destroy the modal.
             * @memberof module:DS/UIKIT/Modal.Modal#
             */
            destroy: function () {
                // To prevent the animation delay when hiding
                this.options && (this.options.animate = false);
                this.hide();
                this._parent();
            }
        };

        return Abstract.extend(Modal);
    });

/**
 * @module DS/UIKIT/Input/Select
 * @extends DS/UIKIT/Input
 */
define('DS/UIKIT/Input/Select',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'DS/UIKIT/Input',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],

    function (UWA, Element, Event, Utils, Input, i18n) {

        'use strict';

        // Since native UI is only for mobile devices sadly
        var isTouch = UWA.Utils.Client.Platform.name.test('ios|android') && Utils.Client.Features.touchEvents,
            isAndroid = UWA.Utils.Client.Platform.name.test('android');

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) return;
            klasses = klasses.split(' ');

            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/small|large$/);
                if (match && !match[1]) {
                    if (match[0] === 'small') {
                        klasses[i] = 'input-sm';
                    } else if (match[0] === 'large') {
                        klasses[i] = 'input-lg';
                    }
                }
            }
            return klasses.join(' ');
        }

        /** @lends module:DS/UIKIT/Input/Select.Select# */
        var Select = {

            /**
             * @property {Object} defaultOptions - The default select input options.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            defaultOptions: {
                placeholder: i18n.selectDefaultPlaceholder,
                options: []
            },

            /**
             * A javascript select control. Can be used to create an HTML control, or an improved one.
             *
             * @example
             * require(['DS/UIKIT/Input/Select'], function (Select) {
             *     new Select({
             *         placeholder: 'Select an option...',
             *         options: [
             *             { value: '1', selected: true },
             *             { value: '2' },
             *             { value: '3', label: 'Option 3' },
             *             { value: 'disabled', label: 'Option disabled', disabled: true }
             *         ]
             *     }).inject(body);
             * });
             *
             * @param {Object} options                          - The available options.
             *
             * @param {String}  [options.className='']          - An optional className to apply to the select input in case you want to apply
             *                                                    custom styles through your stylesheet. Special values are: `small` and `large`.
             * @param {Object}  [options.attributes]            - A set of attributes to set on the select input element (see UWA.Element.set).
             * @param {String}  [options.value]                 - If specified, will select the provided value by default and show it to the user.
             * @param {String}  [options.id]                    - Sets the select input id. Useful when playing with form.
             * @param {String}  [options.name]                  - Sets the select input name. Useful when playing with form.
             * @param {Boolean} [options.required=false]        - Whether this select is required. Useful when playing with form.
             * @param {Boolean} [options.disabled=false]        - Whether to disable this select from the start.
             * @param {Boolean|String} [options.placeholder=''] - The placeholder text for this select input.
             *                                                    If `false` there will be no placeholder eg. the first option will be selected by default.
             *                                                    If `''` will add a blank option to the list of options.
             *                                                    Else it will add an option with the text provided.
             * @param {Boolean} [options.multiple=false]        - Whether to allow multiple value to be selected ?
             * @param {number}  [options.size]                  - Sets the number of options visible at the same time.
             * @param {Boolean} [options.custom=true]           - If `false` will use the default HTML select instead of the improved one.
             * @param {Array|Object|String} [options.options]   - The option(s) to add. Can be a string (e.g. `'option 1'`)
             *                                                    an object with the attributes below or an array of the previous type.
             *
             * @param {String}  [options.options.value]          - This option value. If not provided will take the `options.options.label` value.
             * @param {String}  [options.options.label]          - This option label. If not provided will take the `options.options.value` value.
             * @param {Object}  [options.options.attributes]     - A set of DOM attributes to add to the option
             * @param {Boolean} [options.options.selected=false] - Whether to select this option from the start.
             * @param {Boolean} [options.options.disabled=false] - Whether to disable this option from the start.
             * @param {String}  [options.options.group]          - If specified, will try to attach this option to the given group.
             *                                                     If the group does not exists, it will create it with the provided label.
             *
             * @param {Object} [options.events]                  - Available events.
             *
             * @param {Object} [options.events.onChange]         - Invoked when the select input value changes.
             * @param {Object} [options.events.onClick]          - Invoked when the user click on the select input.
             * @param {Object} [options.events.onMouseDown]      - Invoked when the user press the mouse button on the select input.
             *
             * @constructs Select
             * @memberof module:DS/UIKIT/Input/Select
             *
             * @borrows module:DS/UIKIT/Input.Input#inject as #inject
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Input#destroy as #destroy
             *
             * @borrows module:DS/UIKIT/Input.Input#dispatchEvent as #dispatchEvent
             * @borrows module:DS/UIKIT/Input.Input#addEvent as #addEvent
             * @borrows module:DS/UIKIT/Input.Input#addEvents as #addEvents
             * @borrows module:DS/UIKIT/Input.Input#addEventOnce as #addEventOnce
             * @borrows module:DS/UIKIT/Input.Input#removeEvent as #removeEvent
             * @borrows module:DS/UIKIT/Input.Input#hasEvent as #hasEvent
             *
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             *
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             *
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             */
            init: function (options) {
                options = options || {};

                if (options.className) {
                    options.className = parseClassName(options.className);
                }

                // Handle the new custom option else fall back to nativeSelect
                this.custom = options.nativeSelect !== true;
                this.custom = UWA.is(options.custom) ? options.custom !== false : this.custom;
                this.custom && this.setupTemplates(options);

                this._parent(options);
            },

            /**
             * Builds the select input skeleton.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            buildSkeleton: function () {

                var elements = this.elements,
                    options = this.options,
                    selection,
                    attributes = {};

                // Applying id, required, multiple and other attributes
                UWA.is(options.id) && (attributes.id = options.id);
                options.required && (attributes.required = options.required);
                options.multiple && (attributes.multiple = options.multiple);
                UWA.is(options.size) && (attributes.size = options.size);
                UWA.merge(options.attributes, attributes);

                elements.container = UWA.createElement('div', {
                    'class': 'select ' + options.className
                });

                elements.input = UWA.createElement('select', {
                    'class': 'form-control',
                    attributes: options.attributes
                }).inject(elements.container);

                if (!this.custom) {
                    elements.content = elements.input;
                    elements.container.addClassName('select-native');
                } else {
                    elements.input.addClassName('select-hidden');

                    // Selection placeholder
                    elements.choices = UWA.createElement('ul', {
                        'class': 'select-choices form-control'
                    });

                    // Dropdown containing results
                    elements.dropdown = UWA.createElement('div', {
                        'class': 'select-dropdown'
                    });

                    // <ul> inside the dropdown results
                    elements.content = UWA.createElement('ul', {
                        'class': 'select-results'
                    });

                    // Inject them all
                    elements.choices.inject(elements.container);
                    elements.content.inject(elements.dropdown);
                    elements.dropdown.inject(elements.container);
                }

                if (options.multiple) {
                    elements.container.addClassName('select-multiple');
                }

                // Handle placeholder option
                if (options.placeholder !== false) {
                    options.options.unshift({
                        label: options.placeholder,
                        value: ''
                    });
                    this.getContent().addClassName('select-placeholder');
                }

                // Add the options now
                this.add(options.options);

                // Initial selection
                if (options.placeholder !== false) {
                    selection = this.getSelection();

                    // Occurs if their was no `selected` in the options added
                    if (!selection.length) {
                        this.select(0, true, true);
                    }

                    // Making sure the css class is here
                    this.ensureClassForPlaceholder();
                }

                // This will call handleEvents
                this.setDisabled(options.disabled);
            },

            /**
             * Get an `<option>` element or an `<optiongroup>`.
             * @param  {String|number|Object} option - The option value, label, position index or an object with a value property.
             * @param  {String}  [tag]               - INTERNAL USE ONLY - A tag to filter results (e.g. `optgroup`).
             * @param  {Boolean} [custom]            - INTERNAL USE ONLY - If `false` will return the HTML `<option>`. If `true` will return the custom HTML option.
             *                                         In case you want to get the custom/non-custom element equivalent of your `option` passed.
             * @returns {Element}                    - The option found or null.
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            getOption: function (option, tag, custom, avoidLabel) {

                var options = this.getOptions(true, this.custom && UWA.is(custom) ? !custom : false),
                    value = option,
                    current;

                // In case an element was passed - INTERNAL USE ONLY
                if (UWA.is(option, 'element')) {
                    if (/optgroup|option/.test(option.getTagName())) {
                        // Break early if non-custom select or if we are not asking for a custom/non-custom element equivalent
                        if (!this.custom || this.custom && !UWA.is(custom)) return option;
                    } else if (!this.custom || !UWA.is(custom)) {
                        // Break early if non-custom select
                        // or we are not asking for a custom/non-custom element equivalent
                        return null;
                    }
                } else if (UWA.is(option.value)) {
                    value = option.value;
                }

                return options.some(function (opt, i) {
                    current = opt;
                    if (opt.value === value || (!avoidLabel && opt.label === value) || i === value || opt === value) {
                        if (!tag || opt.getTagName() === tag) {
                            // Make the element swap based on the `custom` parameter if exist
                            UWA.is(custom) && (current = this.getOptions(true, custom)[i]);
                            return true;
                        }
                    }
                }.bind(this)) ? current : null;
            },

            /**
             * Used to retrieve all `<options>`. Will return the `<optgroup>` if any.
             * @param  {Boolean} [placeholder=true] - Whether to include the placeholder (if any) in the options returned.
             * @param  {Boolean} [custom=false]     - INTERNAL USE ONLY - If `false` will return the HTML `<option>`s. If `true` will return the custom HTML options.
             * @returns {Element[]}                 - An array of `<options>`.
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            getOptions: function (placeholder, custom) {

                var response, elements;
                custom = custom === true;

                if (this.custom && custom) {
                    response = this.elements.content.getElements('.result-group, .result-option');
                } else {
                    elements = this.elements.input.getElementsByTagName('*');
                    response = Array.prototype.map.call(elements, function (element) {
                        return UWA.extendElement(element);
                    });
                }

                // Remove the placeholder if any
                if (this.options.placeholder !== false && placeholder === false) {
                    response.shift();
                }

                return response;
            },

            /**
             * Remove option(s) from the select input.
             * If no `<options>` are provided, will remove all the select `<options>`.
             * @param  {Array|Object|String|number} [options] - The option(s) to remove are represented by
             *                                                  their value, label, position, index or an object with a value property.
             *                                                  You can also pass an array of the above types.
             *                                                  If you pass an `<optgroup>`, it will remove the whole group.
             *                                                  If no option(s) are passed, will remove all options.
             * @returns {Select}                              - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            remove: function (options) {

                var previous = this.getSelection();

                if (!UWA.is(options)) {
                    options = this.getOptions();
                }

                Utils.splat(options).forEach(function (option) {
                    this.removeOption(option);
                }, this);

                // In case we remove a select item
                if (!this.getSelection().equals(previous)) {
                    this.dispatchOnChange();
                }

                return this;
            },

            /**
             * Remove a single `<option>`. If it's a `<optgroup>`, it will remove the whole group.
             * @param  {String|number|Object} option - The option value, label, position index or an object with a value property.
             * @returns {Select}                     - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#s
             * @private
             */
            removeOption: function (option) {

                option = this.getOption(option);

                // Do not remove placeholder ever
                if (option && (this.options.placeholder === false || option !== this.elements.input.firstChild)) {
                    if (this.custom) {
                        var customOption = this.getOption(option, undefined, true);
                        customOption && customOption.remove();
                    }
                    option.remove();
                }

                return this;
            },

            /**
             * Add option(s) to the select input.
             * If the option exists, will update it with the new values.
             * @param  {Array|Object|String} options - The option(s) to add. Can be a string (e.g. `'option 1'`),
             *                                         an object with the attributes below or an array of the previous type.
             * @param  {String}  [options.value]    - The option value. If not provided will take the `options.label` value.
             * @param  {String}  [options.label]    - The option label. If not provided will take the `options.value` value.
             * @param  {Boolean} [options.selected] - Whether to select this option from the start.
             * @param  {Boolean} [options.disabled] - Whether to disable this option from the start.
             * @param  {String}  [options.group]    - If specified, will try to add this option to the given group.
             *                                        If the group does not exists, it will create it with the provided label.
             * @returns {Select}                    - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            add: function (options) {

                var previous = this.getSelection();

                Utils.splat(options).forEach(function (option) {
                    this.addOption(option);
                }, this);

                // In case we added a select item
                if (!this.getSelection().equals(previous)) {
                    this.dispatchOnChange();
                }

                return this;
            },

            /**
             * Add a single option to the select input.
             * If the option already exists, will update it (update the group, selected, disabled, label, value).
             * @param  {Object|String} option - The option to add.
             *
             * @param  {String}  [option.value]    - The option value. If not provided will take the `option.label` value.
             * @param  {String}  [option.label]    - The option label. If not provided will take the `option.value` value.
             * @param  {Boolean} [option.selected] - Whether to select this option from the start.
             * @param  {Boolean} [option.disabled] - Whether to disable this option from the start.
             * @param  {String}  [option.group]    - If specified, will try to add this option to the given group.
             *                                       If the group does not exists, it will create it with the provided label.
             * @returns {Select}                   - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             * @private
             */
            addOption: function (option, position) {

                var elements = this.elements,
                    parent = elements.input,
                    customParent = elements.content,
                    element, customElement, exists;

                // Fallback to label if value not provided
                if (UWA.is(option, 'object')) {
                    UWA.is(option.value) || (option.value = option.label);
                } else {
                    // Force string otherwise
                    option = '' + option;
                }

                // Only play with object, easier
                if (!UWA.is(option, 'object')) {
                    option = { value: option };
                }

                // Casting to string
                option.value = '' + option.value;

                // Avoid checking for label
                element = this.getOption(option, 'option', undefined, true);
                exists = !!element;

                // Create element and custom element if /= exist
                if (!exists) {
                    element = UWA.createElement('option');
                    if (this.custom) {
                        customElement = UWA.createElement('li', {
                            'class': 'result-option'
                        });
                    }
                }

                // Create group and custom group if not exist
                if (option.group) {
                    parent = this.getOption(option.group, 'optgroup');

                    if (!parent) {
                        parent = UWA.createElement('optgroup', {
                            label: option.group
                        }).inject(elements.input);

                        if (this.custom) {
                            customParent = UWA.createElement('li', {
                                'class': 'result-group',
                                html: [
                                    { tag: 'span', 'class': 'result-group-label', text: option.group },
                                    { tag: 'ul', 'class': 'result-group-sub' }
                                ]
                            }).inject(elements.content).getElement('ul');
                        }
                    } else if (this.custom) {
                        customParent = this.getOption(parent, undefined, true).getElement('ul');
                    }
                }

                // In case we only wanted to create a group
                if (!UWA.is(option.label) && !UWA.is(option.value)) return this;

                // Update/set <option> attributes
                Element.set.call(element, {
                    text: UWA.is(option.label)  ? option.label : option.value,
                    value: UWA.is(option.value) ? option.value : option.label,
                    selected: option.selected,
                    disabled: option.disabled,
                    attributes: option.attributes
                });


                // Update/set 'result-option' value
                if (this.custom) {
                    if (!customElement) {
                        customElement = this.getOption(element, undefined, true);
                    }

                    // replicate the attributes if any to the customElement since
                    // that is what the user will see
                    option.attributes && Object.keys(option.attributes).forEach(function (attribute) {
                        customElement.setAttribute(attribute, option.attributes[attribute]);
                    });

                    // To display an empty input when placeholder or empty values
                    if (option.label === '' || !option.value && !option.label) {
                        this.template.setOption(customElement, '&nbsp;', true);
                    } else {
                        this.template.setOption(customElement, UWA.is(option.label) ? option.label : option.value);
                    }

                    customElement.toggleClassName('result-option-disabled', !!option.disabled);
                    // Inject customElement (avoid re-injecting if same parent)
                    if (!(exists && customParent === customElement.getParent())) {
                        customElement.inject(customParent, position);
                    }
                }

                // Inject element (avoid re-injecting if same parent)
                if (!(exists && parent === element.getParent())) {
                    element.inject(parent, position);
                }

                return this;
            },

            /**
             * Setup the template used by this Select instance.
             * `template.setOption` is called when a result needs its value changed
             * `template.getOption` is called when a click happens inside the select
             * `template.setChoice` is called when a choice is added to the select
             * @param  {Object} options - The original options
             * @memberof module:DS/UIKIT/Input/Select.Select#
             * @private
             */
            setupTemplates: function (options) {
                this.template = {};

                /**
                 * Called when a result needs its value changed, you should apply the value
                 * and maybe change the DOM here.
                 * @param  {Element} element - the element having its value changed
                 * @param  {String} value    - the new value to set
                 */
                this.template.setOption = (function () {
                    var custom = !!options.template;
                    return function (element, value, isHtml) {
                        var obj = {};
                        obj[(custom || isHtml) ? 'html' : 'text'] = value;
                        Element.set.call(element, obj, value);
                    };
                }());

                /**
                 * Called when a click happens inside the select, if the event target
                 * matches your option you should return the parent `result-option` element
                 * @param  {Element} element - the event target
                 * @return {Element}
                 */
                this.template.getOption = function (element) {
                    if (element.hasClassName('result-option')) return element;
                };

                /**
                 * Called when a choice is added to the select, you should apply the value
                 * and maybe change the DOM here.
                 * @param  {Element} element       - the choice element
                 * @param  {String}  value         - the new value to set
                 * @param  {Boolean} isPlaceholder - whether it is the placeholder or not
                 * @return {Element}
                 */
                this.template.setChoice = function (element, value, isPlaceholder) {
                    Element.set.call(element, { text: value });
                };

                UWA.extend(this.template, options.template);
            },

            /**
             * @param  {Array|Object|String|number} [options] - Enable the option(s) passed. The option(s) are represented by
             *                                                  their value, label, position, index or an object with a value property.
             *                                                  You can also pass an array of the above types.
             *                                                  If you pass an `<optgroup>`, it will enable the whole group.
             *                                                  If no option(s) are passed, will enable the Select.
             * @returns {Select}                              - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            enable: function (options) {
                if (UWA.is(options)) {
                    Utils.splat(options).forEach(function (option) {
                        this.setDisabled(false, option);
                    }, this);
                } else {
                    this.setDisabled(false);
                }

                return this;
            },

            /**
             * @param  {Array|Object|String|number} [options] - Disable the option(s) passed. The option(s) are represented by
             *                                                  their value, label, position, index or an object with a value property.
             *                                                  You can also pass an array of the above types.
             *                                                  If you pass an `<optgroup>`, it will disable the whole group.
             *                                                  If no option(s) are passed, will disable the Select.
             * @returns {Select}                              - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            disable: function (options) {
                if (UWA.is(options)) {
                    Utils.splat(options).forEach(function (option) {
                        this.setDisabled(true, option);
                    }, this);
                } else {
                    this.setDisabled(true);
                }

                return this;
            },

            /**
             * Enable/disable the option passed. If no option is passed, will enable/disable the Select itself.
             * @param  {Boolean} [disabled=true]       - Enable on `true`, disable on `false`. Pretty basic stuff.
             * @param  {Object|String|number} [option] - Disable the option passed. The option is represented by
             *                                           its value, label, position, index or an object with a value property.
             *                                           If you pass an `<optgroup>`, it will disable the whole group.
             *                                           If no option is passed, will enable/disable the Select.
             * @returns {Select}                       - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             * @private
             */
            setDisabled: function (disabled, option) {

                var elements = this.elements;
                UWA.is(disabled) || (disabled = true);

                if (UWA.is(option)) {
                    option = this.getOption(option);
                    if (!option) return this;

                    // Updating disabled for <option> and <optgroup>
                    option.disabled = disabled;
                    this.custom && this.getOption(option, undefined, true).toggleClassName('result-option-disabled', disabled);
                } else {
                    elements.container.toggleClassName('select-disabled', disabled);
                    elements.input.disabled = disabled;
                    // Hide the dropdown if needed and it was opened
                    this.setFocus(false);
                    this.custom && this.toggleDropdown(false);
                    this.handleEvents();
                }

                return this;
            },

            /**
             * Update or add a placeholder to the select.
             * @param {Boolean|String} [placeholder=''] - The new placeholder text for this select input.
             *                                            If `false` there will be no placeholder.
             *                                            If `''` will add a blank option to the list of options.
             *                                            Else it will add an option with the text provided.
             * @returns {Select}                        - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            setPlaceholder: function (placeholder) {

                var options = this.options,
                    previous = options.placeholder;

                // If user wants to remove the placeholder and we had one previously
                if (placeholder === false && previous !== false) {
                    // Put to false before removing to bypass the remove restriction on existing placeholder
                    options.placeholder = false;

                    this.remove(previous);
                    this.getContent().removeClassName('select-placeholder');
                    this.getContent().removeClassName('select-not-chosen');
                } else if (placeholder !== false) {
                    options.placeholder = placeholder;
                    // If we had a previous placeholder change it's text
                    if (previous !== false) {
                        this.addOption({ value: '', label: placeholder });
                        this.syncInput();
                    } else {
                        this.addOption({ label: placeholder, value: '' }, 'top');
                        this.getContent().addClassName('select-placeholder');
                    }
                }

                return this;
            },

            /**
             * Get the current selected item(s).
             * @param  {Boolean} [placeholder=true] - Whether we should return the placeholder as well.
             * @returns {Element[]}                 - An array of the selected `<options>`.
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            getSelection: function (placeholder) {

                var options = this.options,
                    opts = this.getOptions(placeholder),
                    selectedIndex = this.elements.input.selectedIndex,
                    response = [];

                // Remove an index in case of no placeholder
                options.placeholder !== false && placeholder === false && selectedIndex--;

                response = opts.filter(function (opt, index) {
                    if (opt.getTagName() !== 'optgroup') {
                        if (options.multiple && opt.selected || selectedIndex === index) {
                            return true;
                        }
                    } else {
                        selectedIndex++;
                    }
                });

                return response;
            },

            /**
             * Clear the input selection (the user actual selection).
             * @param  {Boolean} [silent=false] - Should we dispatch an `onChange` event.
             * @returns {Select}                - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            clear: function (silent) {
                return this.select(this.getSelection(false), false, silent);
            },

            /**
             * Select/deselect one or many `<options>` (many only available if `options.multiple` is `true`).
             * If you pass an `<optgroup>`, it will select/deselect the whole group for `options.multiple`
             * or the last one of the group otherwise.
             * @param  {Array|Object|String|number} options - The option(s) to select/deselect are represented by
             *                                                their value, label, position, index or an object with a value property.
             *                                                You can also pass an array of the above types.
             *                                                If you pass an `<optgroup>`, it will select/deselect the whole group.
             * @param  {Boolean} [selected=true]            - If `false`, deselect the option(s) instead of selecting them.
             * @param  {Boolean} [silent=false]             - Should we dispatch an `onChange` event.
             * @param  {Boolean} [clear=false]              - Should we clear the input before.
             * @returns {Select}                            - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            select: function (opts, selected, silent, clear) {

                var previous = this.getSelection();

                // Clear before selecting if needed
                clear && this.clear(true);

                Utils.splat(opts).forEach(function (opt) {
                    this.setSelection(opt, selected !== false);
                }, this);

                // If the selection changed, notify the user and sync the input
                if (!this.getSelection().equals(previous)) {
                    if (silent !== true) {
                        this.dispatchOnChange();
                    }
                }

                this.syncInput();

                return this;
            },

            /**
             * Alias to [select(option, true)]{@link module:DS/UIKIT/Input.Select#select}.
             * The only difference is that this method will always [clear()]{@link module:DS/UIKIT/Input.Select#clear} the input beforehand.
             * @param  {Array|Object|String|number} options - The option(s) to select are represented by
             *                                                their value, label, position, index or an object with a value property.
             *                                                You can also pass an array of the above types.
             *                                                If you pass an `<optgroup>`, it will select the whole group.
             * @return {Select}                             - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            setValue: function (options) {
                return this.select(options, true, false, true);
            },

            /**
             * Get the selected value(s) from the select input.
             * @returns {Array} - An array of selected value(s) as string.
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            getValue: function () {
                return this.getSelection().map(function (option) {
                    return option.value;
                });
            },

            /**
             * Set the className for this select.
             * @param {String} klass - A list of classes or a single class.
             *                           Special values are: `small` and `large`.
             * @returns {Select}     - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            setClassName: function (klass) {
                this.options.className = parseClassName(klass);
                this.getContent().className = this.getClassNames();
                return this;
            },

            /**
             * Select/deselect a single `<option>`.
             * If you pass an `<optgroup>`, it will select/deselect the whole group for `options.multiple`
             * or the last one of the group otherwise.
             * @param  {String|number|Object} option - The option value, label, position index or an object with a value property.
             * @param  {Boolean} [selected=true]     - If `false`, deselect the option instead of selecting it.
             * @returns {Select}                     - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             * @private
             */
            setSelection: function (option, selected) {

                option = this.getOption(option);

                // Break early if no valid <option>
                if (!option) return this;

                if (option.getTagName() === 'optgroup') {
                    // Select full group
                    this.select(option.getChildren(), selected);
                } else {
                    // Select single <option>
                    option.selected = selected;
                }

                return this;
            },

            /**
             * Synchronize the displayed selected values with the underlining `<select>`.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            syncInput: function () {

                var isPlaceholder = false,
                    options = this.options,
                    selection = this.getSelection(),
                    contentOptions;

                // Re-select placeholder if no selection and
                // Remove placeholder from possible values in case of multiple
                // and the user chose an option
                if (options.placeholder !== false) {

                    if (selection.length === 0) {
                        this.elements.input.firstChild.selected = true;
                        selection.push(this.elements.input.firstChild);
                    }

                    if (options.multiple && selection.length > 1 && this.elements.input.firstChild.selected) {
                        this.elements.input.firstChild.selected = false;
                        selection.shift();
                    }
                }

                this.ensureClassForPlaceholder();
                isPlaceholder = this.getContent().hasClassName('select-not-chosen');

                if (this.custom) {

                    selection = this.getSelection();

                    // Remove all selected values inside the dropdown
                    this.getOptions(true, true).forEach(function (option) {
                        option.removeClassName('result-option-selected');
                    });

                    // Remove the current selection
                    this.elements.choices.empty();
                    contentOptions = Array.prototype.slice.call(this.elements.content.querySelectorAll('.result-option'));

                    // Synchronize the text choices (displayed in the textfield) and the <select>
                    // TODO: keep order of selected items
                    selection.forEach(function (option) {

                        var customOption, element, originalOption, attributes;

                        customOption = this.getOption(option, undefined, true);
                        customOption.addClassName('result-option-selected');

                        // find the associated attributes in the options
                        if (options.options instanceof Array) {
                            originalOption = options.options[contentOptions.indexOf(customOption)];
                        }

                        // Create the value shown as selected inside the choices field
                        element = UWA.createElement('li', { 'class': 'select-choice' });

                        if (originalOption) {
                            attributes = originalOption.attributes || {};
                            Object.keys(attributes).forEach(function (attribute) {
                                element.setAttribute(attribute, attributes[attribute]);
                            });
                        }

                        this.template.setChoice(element, option.getText(), isPlaceholder);

                        // If we are in multiple mode, we need to add different DOM
                        if (isPlaceholder) {
                            element.className = 'select-choice-default';
                        } else if (options.multiple) {
                            UWA.createElement('span', {
                                'class': 'close',
                                html: '&times;'
                            }).inject(element);
                        }

                        // Inject the new choice
                        element.inject(this.elements.choices);
                    }, this);
                    // scroll to selected element if needed
                    this.ensureSelectedInView();
                }
            },

            /**
             * Sets the focus on this select input.
             * @param  {Boolean} [focus=true] - If `false`, will remove the focus.
             * @param  {Object}  [e]          - The DOM event.
             * @returns {Select}              - The instance
             * @memberof module:DS/UIKIT/Input/Select.Select#
             * @private
             */
            setFocus: function (focus, e) {

                var elements = this.elements;
                UWA.is(focus) || (focus = focus !== false);

                // Break early because ie dispatch unwanted focus event
                if (this._preventIEFocusLost) return this;

                elements.container.toggleClassName('select-focus', focus);

                // Break early since focus and blur is handled by the device himself
                if (isTouch && !isAndroid) return this;

                // Only try to focus if it was done through the API
                !e && elements.input[focus ? 'focus' : 'blur']();

                // Hide dropdown on blur
                if (this.custom && !focus) {
                    this.toggleDropdown(false);
                }

                return this;
            },

            /**
             * In charge of toggling the dropdown visibility.
             * @param {Boolean} [toggle] - If `true` will show the dropdown. Will hide it if `false`.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            toggleDropdown: function (toggle) {

                var top, height, viewportHeight, scrollTop,
                    visible = this.getContent().hasClassName('dropdown-visible');

                if (!UWA.is(toggle)) {
                    toggle = !visible;
                }

                if (toggle !== visible) {

                    if (toggle) {
                        top = this.getContent().getOffsets().y;
                        height = this.elements.dropdown.getSize().height;
                        viewportHeight = window.innerHeight || document.documentElement.clientHeight;
                        scrollTop = window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop;

                        this.getContent().addClassName('dropdown-visible');

                        if (top + height > viewportHeight + scrollTop) {
                            this.getContent().addClassName('dropup');
                        } else {
                            this.getContent().removeClassName('dropup');
                        }

                    } else {
                        this.getContent().removeClassName('dropdown-visible');
                    }
                }

                this.ensureSelectedInView();
            },

            /**
             * Makes sure to have the placeholder class if placeholder is active.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            ensureClassForPlaceholder: function () {
                if (this.options.placeholder !== false) {
                    var toggle = this.getSelection().length === 1 && this.elements.input.firstChild.selected;
                    this.getContent().toggleClassName('select-not-chosen', toggle);
                }
            },

            /**
             * Ensure that the selected element is inside the viewport.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            ensureSelectedInView: function () {

                var selection = this.getSelection(),
                    content = this.elements.content,
                    option, offsetTop,
                    optionRect,
                    contentRect = content.getBoundingClientRect();

                if (selection.length > 0) {
                    option = this.getOption(selection[selection.length - 1], undefined, true);
                    offsetTop = option.offsetTop - parseInt(content.getStyle('margin-top'), 10);
                    optionRect = option.getBoundingClientRect();
                    // Ensure visibility only if not already visible
                    if (optionRect.bottom > contentRect.bottom || optionRect.top < contentRect.top) {
                        this.elements.content.scrollTop = offsetTop;
                    }
                }
            },

            /**
             * Extending base `handleEvents()` for select purpose.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            handleEvents: function () {

                var elements = this.elements;
                this._parent();

                if (!this.custom) return;

                if (!this.events.content) {
                    this.events.content = {
                        // Prevents scrolling the main window
                        mousewheel: function (event) {

                            var scrollTop = this.scrollTop,
                                scrollHeight = this.scrollHeight,
                                height = this.getSize().height,
                                delta = (event.type === 'DOMMouseScroll' ? event.detail * -40 : event.wheelDelta),
                                up = delta > 0;

                            if (!up && -delta > scrollHeight - height - scrollTop) {
                                this.scrollTop = scrollHeight;
                                Event.stop(event);
                            } else if (up && delta > scrollTop) {
                                this.scrollTop = 0;
                                Event.stop(event);
                            }
                        },
                        mouseover: function () {
                            // Remove all selected values inside the dropdown if in single select
                            if (!this.options.multiple) {
                                this.getOptions(true, true).forEach(function (option) {
                                    option.removeClassName('result-option-selected');
                                });
                            }
                        }.bind(this)
                    };
                }

                // Attach/remove above events
                elements.content[this.isDisabled() ? 'removeEvents' : 'addEvents'](this.events.content);
            },

            /**
             * Default select `onMouseDown` handler.
             * Order: mousedown > focus > click
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            onMouseDown: function (event) {

                var target;

                if (this.custom) {
                    target = Event.getElement(event);

                    // This is just for handling the scroll bar clicks quirks
                    if (target === this.elements.content) {
                        this._preventIEFocusLost = true;
                    }

                    // Avoid text selection and popping dropdown!
                    Event.preventDefault(event);
                }

                // In case the underlining input was set to disabled
                if (this.elements.input.disabled) {
                    this.setDisabled();
                    this._dispatchers && this._dispatchers.onMouseDown.halt();
                    Event.stop(event);
                }
            },

            /**
             * Default select `onClick` handler.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            onClick: function (event) {

                if (!this.custom) return;

                var target = Event.getElement(event),
                    options = this.options,
                    disabled = false,
                    isOption = this.template.getOption(target),
                    selection, index, parent;

                // An `<option>` was clicked
                if (isOption) {
                    target = this.getOption(isOption, undefined, false);

                    // Clear the input when clicking the placeholder in multiple
                    if (options.multiple && options.placeholder !== false && target === this.elements.input.firstChild) {
                        this.clear();
                    } else {
                        parent = target.getParent();
                        // Can only deselect disabled selected item
                        if (target.selected && (target.disabled || parent.disabled)) {
                            this.select(target, false);
                        // Select only if not disabled and parent is not disabled
                        } else if (parent.disabled || target.disabled) {
                            disabled = true;
                        } else {
                            this.select(target, options.multiple ? !target.selected : true);
                        }
                    }

                    // Avoid closing dropdown on multiple and disabled items
                    if (!options.multiple && !disabled) {
                        this.toggleDropdown(false);
                    }
                } else if (target.hasClassName('close')) {
                    // A cross button was clicked (in case of multiple)
                    target = target.getParent();
                    selection = this.getSelection(true);
                    index = this.elements.choices.getChildren().indexOf(target);
                    this.select(selection[index], false);
                } else if (!target.hasClassName('result-group-label') && (!options.multiple || options.multiple && !target.hasClassName('select-choice'))) {
                    // The container was clicked
                    // Avoid closing when clicking on a multiple item
                    // Avoid closing when clicking a group label
                    this.elements.input.focus();
                    if (!isTouch || isAndroid) {
                        this.toggleDropdown();
                    }
                }

                this._preventIEFocusLost = false;
            },

            /**
             * Default select `onChange` handler.
             * When the input value changes, sync the input.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            onChange: function (event) {
                this.syncInput();
                event && this.bubbleOnChange(event);
            },

            /**
             * Dispatch the 'change' event in the input. Used internally to fire
             * the event when the custom input is driven by the control.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            dispatchOnChange: function () {
                if (!this.isDisabled()) {
                    Event.dispatchEvent(this.elements.input, 'change');
                } else {
                    // Disable input do not fire change events
                    this.dispatchEvent('onChange');
                }
            },

            /**
             * Default select `onKeyDown` handler.
             * Handle proper space and enter control on dropdown.
             * @private
             * @memberof module:DS/UIKIT/Input/Select.Select#
             */
            onKeyDown: function (e) {

                var key = Event.whichKey(e),
                    retain = true;

                if (this.custom) {
                    if (key === 'space') {
                        this.toggleDropdown(true);
                    } else if (key === 'return') {
                        this.toggleDropdown();
                    } else if (key === 'esc') {
                        this.toggleDropdown(false);
                    } else {
                        retain = false;
                    }

                    if (retain) {
                        Event.preventDefault(e);
                    }
                }
            }
        };

        return Input.extend(Select);
    });

/**
 * A simple date input with a date picker instance.
 * @module DS/UIKIT/Input/Date
 * @extends module:DS/UIKIT/Text
 * @requires DS/UIKIT/DatePicker
 */
define('DS/UIKIT/Input/Date',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'DS/UIKIT/Input/Text',
        'DS/UIKIT/DatePicker'
    ],

    function (UWA, Element, Event, Client, Text, DatePicker) {

        'use strict';

        /**
         * @lends module:DS/UIKIT/Input/Date.Date#
         */
        var Date = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            name: 'input-date',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            defaultOptions: {
                className: '',
                yearRange: 20,
                firstDay: 0
            },

            /**
             * A simple date input with a date picker instance.
             *
             * @example
             * require(['DS/UIKIT/Input/Date'], function (DateInput) {
             *     new DateInput({ placeholder: "Date input..." }).inject(body);
             * });
             *
             * @param {Object} options                              - Available options.
             *
             * @param {String}  [options.className]                 - An optional class name to apply on the text input.
             * @param {Object}  [options.attributes]                - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}  [options.value]                     - The starting input date value.
             * @param {String}  [options.id]                        - Sets the input date id.
             * @param {String}  [options.name]                      - Sets the input date name.
             * @param {Boolean} [options.disabled=false]            - Whether the input date should be disabled from start.
             * @param {Boolean} [options.allowTextEdition=false]    - Whether the text in input can be manually set.
             * @param {String}  [options.placeholder]               - Set the input date placeholder.
             * @param {Date}    [options.min]                       - The minimum/oldest date that can be selected.
             * @param {Date}    [options.max]                       - The maximum/latest date that can be selected.
             * @param {number|number[]} [options.yearRange=20]      - Maximum number of years visible in years select, either side, or array of upper/lower range.
             * @param {Element} [options.renderTo]                  - If specified will inject the datepicker inside this Element, else will inject it in document.body.
             * @param {number}  [options.firstDay]                  - Optional. Specifies which day starts the week. Default is 0: Sunday, other values: 1: Monday, 2: Tuesday, 3: Wednesday, 4: Thursday, 5: Friday, 6: Saturday
             * @param {Object}  [options.events]                    - The available events.
             *
             * @param {Object}    [options.events.onChange]         - Invoked when the input text value changes.
             * @param {Object}    [options.events.onClick]          - Invoked when the user click on the input text.
             * @param {Object}    [options.events.onMouseDown]      - Invoked when the user press the mouse button on the input text.
             * @param {Object}    [options.events.onKeyDown]        - Invoked when the user press a key while focusing the input text.
             *
             * @constructs Date
             * @memberof module:DS/UIKIT/Input/Date
             *
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Text#setFocus as #setFocus
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             * @borrows module:DS/UIKIT/Input.Input#setDisabled as #setDisabled
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#enable as #enable
             * @borrows module:DS/UIKIT/Input.Input#disable as #disable
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             * @borrows module:DS/UIKIT/Input.Input#setValue as #setValue
             * @borrows module:DS/UIKIT/Input.Text#getValue as #getValue
             */
            init: function (options) {
                this._parent(options);
                this.elements.picker = new DatePicker({
                    field: this.elements.container,
                    renderTo: this.options.renderTo,
                    firstDay: this.options.firstDay,
                    minDate: this.options.min,
                    maxDate: this.options.max,
                    yearRange: this.options.yearRange
                });
            },

            /**
             * Build the native input element.
             * Override UIKIT/Input
             * @returns {Element} - The native input element.
             * @private
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            buildInput: function () {

                var options = this.options,
                    attributes = {},
                    element = UWA.createElement('input', { type: 'text' });

                // Do not allow free input if required (enabled and not editable)
                if (!this.options.disabled && !this.options.allowTextEdition) {
                    element.readOnly = true;
                }

                // Set attributes if needed
                ['placeholder', 'required'].forEach(function (pref) {
                    if (options[pref]) { attributes[pref] = options[pref]; }
                });
                element.set(attributes);

                return element;
            },

            /**
             * Return a Date object of the current selected date.
             * @returns {Date} date - The current selected date
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            getDate: function () {
                return this.elements.picker.getDate();
            },

            /**
             * Set the current date selection.
             * This will be restricted within the bounds of minDate and maxDate options if they're specified.
             * You can optionally pass a boolean as the second parameter to prevent triggering of the onSelect callback (true), allowing the date to be set silently.
             * @param {String|Date} date                - The new date.
             * @param {Boolean} [preventOnSelect=false] - Make it a silent update.
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            setDate: function (date, preventOnSelect) {
                return this.elements.picker.setDate(date, preventOnSelect);
            },

            /**
             * Change the minDate.
             * Set to false to reset the minDate.
             * @param {Date} date - The new minDate.
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            setMinDate: function (date) {
                return this.elements.picker.setMinDate(date);
            },

            /**
             * Change the maxDate.
             * Set to false to reset the maxDate.
             * @param {Date} date - The new maxDate.
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            setMaxDate: function (date) {
                return this.elements.picker.setMaxDate(date);
            },

            /**
             * Clear both min and max dates.
             * @memberof module:DS/UIKIT/Input/Date.Date#
             */
            clearDates: function () {
                return this.elements.picker.clearDates();
            }
        };

        return Text.extend(Date);
    });

/**
 * The generic number control.
 * @module DS/UIKIT/Input/Number
 *
 */
define('DS/UIKIT/Input/Number',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'DS/UIKIT/Input',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],
    function (UWA, Element, Event, Utils, Input, i18n) {

        'use strict';

        var navigationKeyCodes = [9, 13, 27, 37, 38, 39, 40];
        var commandKeyNames = ['Home', 'End', 'Control', 'v', 'V', 'c', 'C', 'Shift'];
        var acceptedCharacters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '.', ','];
        var decimalCommmaSeparatedLangs = ['fr', 'de', 'ru'];

        /**
         * @lends module:DS/UIKIT/Input/Number.Number#
         */
        var Number = {

            /**
             * @property {String} - The component name
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            name: 'number',

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            defaultOptions: {
                min: 0,
                max: 10,
                step: 1,
                value: 0,
                nativeNumber: false,
                decimalPrecision: 100000,
                decimalSeparator: null,
            },

            /**
             * The generic number control.
             *
             * @example
             * require(['DS/UIKIT/Input/Number'], function (Number) {
             *     new Number({
             *         placeholder: "Pick a number...",
             *         min: 0,
             *         max: 100,
             *         step: 10
             *     }).inject(body);
             * });
             * @param {Object} options                           - Available options.
             *
             * @param {String}   [options.className]             - An optional className to apply to the container.
             * @param {Object}   [options.attributes]            - A set of attributes to set on the input element (see UWA.Element.set).
             * @param {String}   [options.value]                 - The starting input value to be selected.
             * @param {String}   [options.id]                    - Sets the input number id.
             * @param {String}   [options.name]                  - Sets the input number name.
             * @param {Boolean}  [options.disabled=false]        - Whether the input number should be disabled from start.
             * @param {String}   [options.placeholder='']        - The input number placeholder text. If `false` no placeholder. If '' will add a blank option.
             * @param {Boolean}  [options.nativeNumber=false]    - If `true` will use a native number instead of a custom one.
             * @param {Number}   [options.min=0]                 - Set the input number minimum value.
             * @param {Number}   [options.max=10]                - Set the input number maximum value.
             * @param {Number}   [options.step=1]                - Set the input number step value.
             * @param {Number}   [options.decimalPrecision='100000']  - Sets decimal rounding. Use 1 to accept integers only
             * @param {Number}   [options.decimalSeparator='.']  - Sets the decimal separator to use. If not provided will default to . unless current language is fr, de or ru
             *
             * @param {Object}  [options.events]                 - Available events.
             *
             * @param {Object}    [options.events.onChange]      - Invoked when the input number value change.
             * @param {Object}    [options.events.onClick]       - Invoked when the user click on the input number.
             * @param {Object}    [options.events.onMouseDown]   - Invoked when the user press the mouse button on the input number.
             *
             * @constructs Number
             * @memberof module:DS/UIKIT/Input/Number
             *
             * @borrows module:DS/UIKIT/Input.Input#getContent as #getContent
             * @borrows module:DS/UIKIT/Input.Input#focus as #focus
             * @borrows module:DS/UIKIT/Input.Input#blur as #blur
             * @borrows module:DS/UIKIT/Input.Input#isDisabled as #isDisabled
             * @borrows module:DS/UIKIT/Input.Input#setName as #setName
             * @borrows module:DS/UIKIT/Input.Input#getName as #getName
             * @borrows module:DS/UIKIT/Input.Input#setId as #setId
             * @borrows module:DS/UIKIT/Input.Input#getId as #getId
             */
            init: function (options) {
                options = options || {};
                this._parent(options);

                if ([',', '.'].indexOf(this.options.decimalSeparator) === -1) {
                    if (UWA.is(i18n._lang)) {
                        this.options.decimalSeparator = (decimalCommmaSeparatedLangs.indexOf(i18n._lang) > -1) ? ',' : '.';
                    } else {
                        this.options.decimalSeparator = '.';
                    }
                }

                if (UWA.owns(this.options, 'value')) {
                    this.setValue(this.options.value);
                } 

                this.intMaxLength = Math.max((Math.abs(this.options.min).toFixed(0) + '').length, (Math.abs(this.options.max).toFixed(0) + '').length) + 1;
                this.decimalMaxLength = (this.options.decimalPrecision + '').length - 1;
            },

            /**
             * Builds the input skeleton.
             * @private
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            buildSkeleton: function () {

                var options = this.options,
                    elements = this.elements,
                    attributes = options.attributes,
                    commonClassName = 'input-' + this.name;

                options.id && (attributes.id = options.id);
                options.required && (attributes.required = options.required);
                attributes.min = options.min;
                attributes.max = options.max;
                attributes.step = options.step;
                options.placeholder && (attributes.placeholder = options.placeholder);

                elements.container = UWA.createElement('div', {
                    'class': commonClassName + ' ' + options.className
                });

                elements.input = UWA.createElement('input', {
                    type: 'text',
                    'class': 'form-control',
                    attributes: attributes
                }).inject(elements.container);

                if (this.options.nativeNumber) {
                    this.getContent().removeClassName('input-' + this.name);
                } else {
                    elements.leftButton = UWA.createElement('button', {
                        'type': 'button',
                        'class': commonClassName + '-button ' + commonClassName + '-button-left btn btn-default'
                    });
                    elements.rightButton = UWA.createElement('button', {
                        'type': 'button',
                        'class': commonClassName + '-button ' + commonClassName + '-button-right btn btn-default'
                    });

                    elements.leftButton.inject(elements.input, 'before');
                    elements.rightButton.inject(elements.input, 'after');
                }

                // This will call handleEvents
                this.setDisabled(options.disabled);
            },

            /** @inheritdoc */
            setValue: function (value) {
                if (this.options.decimalSeparator === ',') {
                    value = (value + '').replace(',', '.');
                }
                var previousValue = this.getValue();

                this._parent(value);
                if (previousValue !== value) this.dispatchOnChange();
            },

            /**
             * Set a new range definition for the number input.
             * @deprecated Since component now use a proper input number.
             * @returns {Number} - The instance.
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            add: function () { return this; },

            /**
             * Remove all options.
             * @deprecated Since component now use a proper input number.
             * @returns {Number} - The instance.
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            remove: function () { return this; },

            /**
             * Decrement current value regarding stepper.
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            decrement: function () {
                var currentValue = this.parseInput(this.elements.input.value),
                    min = this.options.min,
                    decimalPrecision = this.options.decimalPrecision,
                    newValue;

                // prevent multiple set min value that will invoke onChange event
                if (currentValue <= min) return;

                if (currentValue > min) {
                    newValue = (currentValue * decimalPrecision - this.options.step * decimalPrecision) / decimalPrecision;
                    newValue = (newValue < min) ? min : newValue;
                    this.setValue(newValue);
                } else {
                    this.setValue(min);
                }
            },

            /**
             * Increment current value regarding stepper.
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            increment: function () {
                var currentValue = this.parseInput(this.elements.input.value),
                    max = this.options.max,
                    decimalPrecision = this.options.decimalPrecision,
                    newValue;

                // prevent multiple set max value that will invoke onChange event
                if (currentValue >= max) return;

                if (currentValue < max) {
                    newValue = (currentValue * decimalPrecision + this.options.step * decimalPrecision) / decimalPrecision;
                    newValue = (newValue > max) ? max : newValue;
                    this.setValue(newValue);
                } else {
                    this.setValue(max);
                }
            },

            /**
             * @memberof module:DS/UIKIT/Input/Number.Number#
             * @private
             */
            syncInput: function () {
                var decimalPrecision = this.options.decimalPrecision;
                if (this.elements.input.value !== null) {
                    var value = Math.round(this.parseInput(this.elements.input.value) * decimalPrecision) / decimalPrecision;

                    if (value > this.options.max) {
                        return this.setValue(this.options.max);
                    } else if (value < this.options.min || value === null || value === undefined || isNaN(value)) {
                        return this.setValue(this.options.min);
                    }
                        
                    // Display with the correct separator
                    if (this.options.decimalSeparator === ',') value = (value + '').replace('.', ',');
                    this.elements.input.value = value;
                }
            },

            /**
             * Event handler for keypress event on the input
             * Allows to filter characters not filtered by browser
             * @memberof module:DS/UIKIT/Input/Number.Number#
             * @private
             */
            onKeyDown: function (event) {

                var selection = { 
                    start: this.elements.input.selectionStart, 
                    end: this.elements.input.selectionEnd,
                    length: this.elements.input.selectionEnd - this.elements.input.selectionStart
                };

                var val = this.elements.input.value.split('');
                var keyCode = event.which || event.keyCode;
                var input = event.key;

                // Allow navigation or command key
                if (navigationKeyCodes.indexOf(keyCode) > -1 || commandKeyNames.indexOf(input) > -1) {
                    return;
                }

                var isCharRemoval = input === 'Delete' || input === 'Del' || input === 'Backspace';
                if (!isCharRemoval && acceptedCharacters.indexOf(input) === -1) {                
                    Event.preventDefault(event);
                    return;
                }

                // Reject anything else than accepted characters
                // Reject - if not at beginning
                // Reject decimal separator if unsupported
                if ((!isCharRemoval && acceptedCharacters.indexOf(input) === -1)
                   || (input === '-' && (selection.start !== 0 || this.options.min >= 0))
                   || ((input === ',' || input === '.') && this.options.decimalPrecision === 1)) {           
                    Event.preventDefault(event);
                    return;
                }

                // Simulate operation on the text
                if (isCharRemoval) {
                    // Replace text
                    if (input === 'Backspace' && selection.start > 0 && !selection.length) {
                        selection.start -= 1;
                    }
                    // Remove selected text or previous/next character
                    val.splice(selection.start, selection.length || 1, '');
                } else if (selection.length) {
                    // Remove selected text then add character
                    val.splice(selection.start, selection.length, '');
                    val.splice(selection.start, 1, input);
                } else {
                    // Add character
                    val.splice(selection.start, 0, input);
                }

                // Do not accept numbers before minus sign.
                if (val.indexOf('-') > 0) return;

                val = val.join('');

                var newValue = this.parseInput(val);
                var decimals = newValue - Math.floor(newValue);
                var decimalPlaces = (newValue + '').split('.').slice(-1)[0].length;

                // Reject too long decimal part
                // Reject too long entire part (with +1 char tolerance)
                if ((decimals && decimalPlaces > this.decimalMaxLength) 
                   || (Math.abs(newValue.toFixed(0)) + '').length > this.intMaxLength) {
                    Event.preventDefault(event);
                    return;
                }
                
            },

            /**
             * Default event handler on paste to the input.
             * Prevents non-numeric entry.
             * @memberof module:DS/UIKIT/Input/Number.Number#
             * @private
             */
            onPaste: function (event) {
                var pastedText = event.clipboardData.getData('text/plain');
                if (!/^-?[0-9]+\.?,?[0-9]+/.test(pastedText)) {
                    Event.preventDefault(event); 
                }
            },

            /**
             * Calls parseFloat function with decimal separator replacement when needed
             * @param  {String}    - The value to parse
             * @memberof module:DS/UIKIT/Input/Number.Number#
             * @private
             */
            parseInput: function (value) {
                // Reproduce chrome and firefox behavior for input[type]===text 
                // when reading input.value to avoid regression
                if (value !== undefined && value !== null) {
                    if (this.options.decimalSeparator === ',') {
                        return parseFloat((value + '').replace(',', '.'));
                    } else { 
                        return parseFloat(value); 
                    }
                }
                return NaN;
            },

            /**
             * Enable/disable the number input.
             * @param  {Boolean} [disabled=true] - Enable on `true`, disable on `false`. Pretty basic stuff.
             * @returns {Number}                 - The instance
             * @memberof module:DS/UIKIT/Input/Number.Number#
             * @private
             */
            setDisabled: function () {

                var elements = this.elements,
                    disabled = arguments[0] !== false;

                elements.leftButton.toggleClassName(this.name + '-disabled', disabled);
                elements.leftButton.disabled = disabled;
                elements.input.disabled = disabled;
                elements.rightButton.disabled = disabled;

                this.handleEvents();

                return this;
            },

            /**
             * Main function for handling events.
             * Override UIKIT/Input because of how we handle left and right buttons clicking.
             * @private
             * @memberof module:DS/UIKIT/Input/Number.Number#
             */
            handleEvents: function () {

                var elements = this.elements;

                this._parent();

                // Below code only concerns custom number inputs.
                if (this.options.nativeNumber) { return; }

                if (!this.events.buttons) {
                    this.events.buttons = {
                        leftButton: {
                            click: this.decrement.bind(this)
                        },
                        rightButton: {
                            click: this.increment.bind(this)
                        }
                    };
                }

                this.events.input.keydown = this.onKeyDown.bind(this);
                this.events.input.paste = this.onPaste.bind(this);

                if (this.isDisabled()) {
                    elements.leftButton.removeEvents(this.events.buttons.leftButton);
                    elements.rightButton.removeEvents(this.events.buttons.rightButton);
                    elements.input.removeEvents(this.events.input);
                } else {
                    elements.leftButton.addEvents(this.events.buttons.leftButton);
                    elements.rightButton.addEvents(this.events.buttons.rightButton);
                    elements.input.addEvents(this.events.input);
                }
            }
        };

        return Input.extend(Number);
    });

/**
 * A text input that shows matching suggestions.
 * @module DS/UIKIT/Autocomplete
 * @extends UWA/Controls/Abstract
 * @requires DS/UIKIT/Spinner
 * @requires DS/UIKIT/Scroller
 * @requires DS/UIKIT/Badge
 */
define('DS/UIKIT/Autocomplete',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Json',
        'UWA/Controls/Abstract',
        'UWA/Promise',
        'UWA/Data',
        'UWA/Utils/Client',
        'DS/UIKIT/Spinner',
        'DS/UIKIT/Scroller',
        'DS/UIKIT/Badge',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],

    /**
     * Display a search input with autocomplete system.
     *
     * @module DS/UIKIT/Autocomplete
     *
     * @requires DS/UIKIT/Spinner
     * @requires DS/UIKIT/Scroller
     * @requires DS/UIKIT/Badge
     *
     * @extends UWA/Controls/Abstract
     *
     */
    function (UWA, Element, Event, Utils, Json, Abstract, Promise, Data, Client, Spinner, Scroller, Badge, i18n) {

        'use strict';

        function addEvent (event, elem, func, capture) {
            if (elem.addEventListener)  // W3C DOM
                elem.addEventListener(event, func, capture);
            else if (elem.attachEvent) { // IE DOM
                elem.attachEvent('on' + event, func, capture);
            }
        }

        function removeEvent (event, elem, func) {
            if (elem.removeEventListener) { // W3C DOM
                elem.removeEventListener(event, func, false);
            } else if (elem.detachEvent) {  // IE DOM
                elem.detachEvent('on' + event, func);
            }
        }

        var keyCodes = {
            8: 'backspace',
            9: 'tab',
            13: 'enter',
            27: 'escape',
            37: 'left-arrow',
            38: 'up-arrow',
            39: 'right-arrow',
            40: 'down-arrow',
            46: 'del'
        };

        /**
         * @lends module:DS/UIKIT/Autocomplete.Autocomplete#
         */
        var Autocomplete = {
            /**
             * Component name used by `Abstract.getClassNames`.
             * Component class name.
             * Component variations class name prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            name: 'autocomplete',

            /**
             * Every suggestions datasets with own configurations.
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            datasets: null,

            /**
             * Timeout trace for suggestions retrieve delay after typing
             * Internal usage only.
             * @type {number}
             * @private
             */
            typeTimeout: null,

            /**
             * The autocomplete items currently selected.
             * @type {Object[]}
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @readonly
             */
            selectedItems: null,

            /**
             * The autocomplete current badges of selected items.
             * @type {Badge[]}
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @readonly
             */
            badges: null,

            /**
             * The autocomplete inputs between badges.
             * @type {Object[]}
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @readonly
             */
            innerInputs: null,

            /**
             * The current position of the cursor / keyboard in the item badges
             * @type {number}
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @readonly
             */
            currentPosition: -1,

            /**
             * Badge currently selected
             * @type {Badge}
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            currentBadge: null,

            /**
             * Suggestions currently shown
             * @type {Object[]}
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            currentSuggestions: [],

            /**
             * Selected index position in a keyboard navigation context.
             * @type {number}
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            keyboardIndex: -1,

            /**
             * Instance of scroller used in suggestion list.
             * Internal usage only.
             * @type {Object}
             * @private
             */
            scroller: null,

            /**
             * CSS class for suggestions elements
             * @type {String}
             * @constant
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            CLS_ITEM: 'autocomplete-item',

            /**
             * Additional CSS class for parents elements
             * @type {String}
             * @constant
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            CLS_PARENT_ITEM: 'autocomplete-parent-item',

            /**
             * Additional CSS class for suggestions being hovered through JS code
             * @type {String}
             * @constant
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            CLS_HOVERED_ITEM: 'js-selected',

            /**
             * CSS class for when autocomplete is filled
             * @type {String}
             * @constant
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            CLS_FILLED: 'autocomplete-filled',

            /**
             * Maximum height of suggestions container
             * @type {number}
             * @constant
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            SUGGESTIONS_MAX_HEIGHT: 200,

            /**
             * Easy way to know if suggestions list is currently displayed
             * @type {Boolean}
             * @readonly
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            suggestsDisplayed: false,

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @private
             */
            defaultOptions: {
                placeholder: i18n.search,
                noResultsMessage: i18n.noResults,
                typeDelayBeforeSearch: 500,
                minLengthBeforeSearch: 1,
                showSuggestsOnFocus: false,
                maxSuggestsToDisplay: -1,
                multiSelect: false,
                itemMultiSelect: false,
                tokenSeparator: ';',
                allowFreeInput: false,
                disabled: false,
                closableItems: true,
                floatingSuggestions: false
            },

            /**
             * Display a search input with autocomplete.
             *
             * @param {Object}  options                                  - The available options.
             *
             * @param {String}  [options.placeholder='Search...']        - Input placeholder.
             * @param {Boolean} [options.disabled=false]                 - Whether the input should be disabled from start or not.
             * @param {Object}  [options.noResultsMessage='No results.'] - Message to display when there is no available suggestion for given input text. Set to false to prevent suggestions list to display and have no message at all.
             * @param {number}  [options.typeDelayBeforeSearch=500]      - Time in milliseconds to wait before starting to search for suggestions.
             * @param {Boolean} [options.showSuggestsOnFocus=false]      - True to show local suggestions on input focus.
             * @param {number}  [options.minLengthBeforeSearch=1]        - Minimal required length before starting to search for suggestions.
             * @param {number}  [options.maxSuggestsToDisplay=-1]        - Max number of suggestions to display.    -1 : no limit.
             * @param {Boolean} [options.multiSelect=false]              - True to allow more than one item selection in input.
             * @param {Boolean} [options.itemMultiSelect=false]          - True to allow items to be selected more than one time.
             * @param {String}  [options.tokenSeparator=';']             - Token used to separate selected items while getting selection.
             * @param {Boolean} [options.allowFreeInput=false]           - True to allow the input of a text that does not match with any suggestions.
             * @param {Boolean} [options.closableItems=true]             - True to show badge crosses.
             * @param {Boolean} [options.floatingSuggestions=false]      - True to make suggestions follow input. Only available in multiSelect mode.
             * @param {number}  [options.maxHeight=180]                  - Specify the maximum height of the suggestions container
             * @param {String}  [options.filterEngine]                   - Optional custom definition of filter engine.
             *                                                             This could be used as a post-processing on matching data - sort, remove duplicates... On every matching suggestions.
             *                                                             Called with one argument : the  suggestions matching input text. Expected to return matching items after filtering.
             *                                                             No filtering by default.
             *
             * @param {Object}   [options.events]                        - The available events.
             *
             * @param {Function} [options.events.onSelect]               - An event dispatched when a suggestion is selected.
             * @param {Function} [options.events.onUnselect]             - An event dispatched when a suggestion is unselected.
             * @param {Function} [options.events.onShowSuggests]         - An event dispatched when suggestions are being shown.
             * @param {Function} [options.events.onHideSuggests]         - An event dispatched when suggestions are being hidden.
             * @param {Function} [options.events.onFocus]                - An event dispatched when input is focused.
             * @param {Function} [options.events.onSelectBadge]          - An event dispatched when a badge is being selected (with mouse or keyboard navigation).
             *                                                             Returns :
             *                                                                - the item object at first argument,
             *                                                                - the Badge instance as second argument,
             *                                                                - the Badge position ad third argument.
             * @param {Function} [options.events.onUnselectBadge]       - An event dispatched when a badge is being unselected (with mouse or keyboard navigation).
             * @param {Function} [options.events.onUpdateInputPosition] - An event dispatched when position in badges list changes (with mouse or keyboard navigation).
             *
             * @param {Function} [options.events.onBlur]                - An event dispatched when input is blurred.
             * @param {Function} [options.events.onClickOutside]        - An event dispatched when clicking outside autocomplete.
             * @param {Function} [options.events.onKeyDown]             - An event dispatched when pressing key on input field.
             * @param {Function} [options.events.onKeyUp]               - An event dispatched when releasing key on input field.
             *
             *
             * @param {Object} [options.datasets] - Suggestions data with optionals engines for search, filter and template.
             *
             * @param {String} [options.datasets.name]                          - Name for dataset identification.
             * @param {Boolean} [options.datasets.displayName=false]            - True to show dataset name with matching suggestions below.
             * @param {String} [options.datasets.searchUrl]                     - Optional URL to be used to retrieve remote suggestions instead of passing them through a static array.
             *                                                                  Expected to contains '{text}' to be set by the input text to search for. Please use remoteSearchEngine for advanced remote suggestions retrieving.
             *
             * @param {Object} [options.datasets.items] - Static array of suggestions.
             *
             * @param {String} options.datasets.items.value                     - Required suggestion value.
             * @param {String} [options.datasets.items.label]                   - Suggestion label to display. Takes value if none..
             * @param {String} [options.datasets.items.subLabel]                - Optional, sub-label displayed below label.
             * @param {String} [options.datasets.items.name]                    - Optional, item custom identifier.
             * @param {Boolean} [options.datasets.items.disabled=false]         - True if the suggestion is disabled by default.
             * @param {Boolean} [options.datasets.items.selected=false]         - Whether to select this item from start.
             * @param {Function} [options.datasets.items.handler]               - An optional handler to call when this item is clicked.
             *
             * @param {Object} [options.datasets.configuration] - Configuration for dataset manipulations.
             *
             * @param {Function} [options.datasets.configuration.searchEngine]          - Optional custom definition of search engine for the given dataset. Called with two arguments : the dataset and the text being searched. Expected to return matching items for given input text. Default search engine used if none.
             * @param {Function} [options.datasets.configuration.remoteSearchEngine]    - Optional custom definition of search engine for the given remote dataset. Called with two arguments : the dataset and the text being searched. Expected to return matching items for given input text. Default remote search engine used if none.
             * @param {Function} [options.datasets.configuration.filterEngine]          - Optional custom definition of filter engine for the given dataset. This could be used as a post-processing on matching data : sort, remove duplicates... On the given dataset only. Called with two arguments : the dataset and suggestions matching input text. Expected to return matching  items after filtering. No filtering by default.
             *
             * @param {Object} [options.datasets.configuration.templateEngine]          - Optional custom definition of template engine for the given dataset. This could be used to display suggestions the way you want for the given dataset. Called for every matching suggestion with three arguments : the DOM container where you should inject your template, the suggestion dataset and its corresponding item data.
             *
             * @param {Function} [options.datasets.configuration.dataParser]            - Optional custom method to parse data in a correct output for autocomplete needs from the response of the searchUrl call. Expected to return items in a correct output i.e. Array of items with at least a 'value' for each item, and additionally any variable to be used in a custom templateEngine. defaultDataParser called if none.
             * @param {Function} [options.datasets.configuration.onGetResults]          - Optional callback that will be called on remote search results retrieve.
             * @param {Function} [options.datasets.configuration.onNoResults]           - Optional callback that will be called on remote search results retrieve if no results.
             * @param {Function} [options.datasets.configuration.onError]               - Optional callback that will be called on remote search results retrieve if an error occurred. Called with the data returned by server and the text of the input.
             * @param {Function} [options.datasets.configuration.onTimeout]             - Optional callback that will be called on remote search  results retrieve if a timeout occurred. Called with the data returned by server and the text of the input.
             *
             * @param {Object} [options.getSuggestion]         - If using some template engine, this could be set to retrieve the correct parent DOM for the suggestion being clicked. Take one argument : the event target element.
             *
             * @constructs Autocomplete
             * @memberof module:DS/UIKIT/Autocomplete
             */
            init: function (options) {

                this.selectedItems = [];
                this.badges = [];
                this.datasets = [];
                this.innerInputs = [];
                this._parent(options);
                
                this.options.maxHeight = (options && options.maxHeight) || this.SUGGESTIONS_MAX_HEIGHT;

                /**
                 * Called when a click happens inside the suggestions list.
                 * Must return the parent 'autocomplete-item' element.
                 *
                 * @param  {Element} element - The event target
                 * @return {Element} - The corresponding 'autocomplete-item' element
                 */
                this.getSuggestion = (options && options.getSuggestion) ? options.getSuggestion : function (element) {
                    var parent;

                    if (element.hasClassName(this.CLS_ITEM)) {
                        return element;
                    } else {
                        parent = element.getParent('.' + this.CLS_ITEM);
                        return parent;
                    }
                };

                this.buildSkeleton();

                options && options.datasets && this._addDatasets(options.datasets);
            },

            /**
             * Build the native input element.
             * @return {Element} - The native input element
             * @private
             */
            _buildInput: function () {
                var options = this.options,
                    className = this.name,
                    attributes = {},
                    input = UWA.createElement('input', { type: 'text' });

                // Set input attributes if needed
                ['placeholder', 'required', 'pattern', 'maxlength'].forEach(function (pref) {
                    if (options[pref]) { attributes[pref] = options[pref]; }
                });

                input.set(attributes);
                input.addClassName(className + '-input');

                // Dynamically set the size regarding placeholder length
                // We have to do this to know when input should go down while appending choices
                // We double the size for chinese and japanese characters
                input.setAttribute('size', (input.getAttribute('placeholder') || '').length * ((i18n._lang === 'zh' || i18n._lang === 'ja') ? 2 : 1));

                if (this.options.name) { input.name = this.options.name; }
                if (!this.options.multiSelect) { input.setStyle('width', '100%'); }

                return input;
            },

            /**
             * Build an inner input to inject between badges.
             * Multi-select mode only.
             *
             * @return {Element}         - The new inner input
             * @private
             */
            _buildInnerInput: function () {
                var input = UWA.createElement('input', { type: 'text' }), computedWidth;
                input.addClassName(this.name + '-inner-input');
                input.addEvent('keyup', function () {
                    // min width (5) plus 8px per char
                    computedWidth = 5 + (input.value.length) * 8;
                    input.setStyle('width', computedWidth + 'px');
                });
                input.addEvents(this.events.input);
                return input;
            },

            /**
             * Build HTML skeleton.
             * @private
             */
            buildSkeleton: function () {
                var elements = this.elements,
                    className = this.name,
                    options = this.options;

                // Safe check if user called buildSkeleton directly (we cannot afford building it twice)
                if (elements.container) { return; }

                elements.container = UWA.createElement('div', {
                    'class': className
                });

                elements.inputContainer = UWA.createElement('div', {
                    'class': className + '-searchbox',
                    'tabindex': '1'
                }).inject(elements.container);


                Client.Platform.ios && elements.inputContainer.classList.add('prevent-ios-zoom-in');

                elements.input = this._buildInput();

                elements.input.inject(elements.inputContainer);

                if (this.options.multiSelect === false) {
                    elements.clear = UWA.createElement('span', {
                        'class': className + '-reset fonticon fonticon-clear'
                    }).inject(elements.inputContainer);
                }

                elements.suggestsContainer = UWA.createElement('div', {
                    'class': className + '-suggests'
                }).inject(elements.container);

                options.multiSelect && options.floatingSuggestions && elements.suggestsContainer.addClassName(className + '-floating-suggests');

                elements.suggestsScroll = UWA.createElement('div', {
                    'class': className + '-suggests-scroll'
                }).inject(elements.suggestsContainer);

                // We need a tab index for keyboard navigation throughout our suggestions list
                elements.suggests = UWA.createElement('ul', { tabindex: '1' }).inject(elements.suggestsScroll);

                if (Utils.Client.Engine.firefox) {
                    elements.suggests.addClassName('scroller-shift');
                }

                // We want a UIKIT scroller for our suggestions list
                this.scroller = new Scroller({
                    element: elements.suggestsScroll
                }).inject(elements.suggestsContainer);

                // Will call handleEvents()
                this.setDisabled(options.disabled);
            },

            /**
             * Add one or more dataset from one single array.
             *
             * @param {Object} datasets - Datasets to add in autocomplete.
             *
             * @param {String} [datasets.name]                          - Name for dataset identification.
             * @param {Boolean} [datasets.displayName=false]            - True to show dataset name with matching suggestions below.
             * @param {String} [options.searchUrl]                      - Optional URL to be used to retrieve remote suggestions instead of passing them through a static array. Expected to contains '{text}' to be set by the input text to search for. Please use remoteSearchEngine for advanced remote suggestions retrieving.
             *
             * @param {Object} [datasets.items] - Static array of suggestions.
             *
             * @param {String} datasets.items.value                     - Required suggestion value.
             * @param {String} [datasets.items.label]                   - Suggestion label to display. Takes value if none..
             * @param {String} [datasets.items.subLabel]                - Optional, sub-label displayed below label.
             * @param {Boolean} [datasets.items.disabled=false]         - True if the suggestion is disabled by default.
             * @param {Function} [datasets.items.handler]               - An optional handler to call when this item is clicked.
             *
             * @param {Object} [datasets.configuration] - Configuration for dataset manipulations.
             *
             * @param {Function} [datasets.configuration.searchEngine]          - Optional custom definition of search engine for the given dataset. Called with two arguments : the dataset and the text being searched. Expected to return matching items for given input text. Default search engine used if none.
             * @param {Function} [configuration.remoteSearchEngine]             - Optional custom definition of search engine for the given remote dataset. Called with two arguments : the dataset and the text being searched. Expected to return matching items for given input text. Default remote search engine used if none.
             * @param {Function} [datasets.configuration.filterEngine]          - Optional custom definition of filter engine for the given dataset. This could be used as a post-processing on matching data : sort, remove duplicates... On the given dataset only. Called with two arguments : the dataset and suggestions matching input text. Expected to return matching items after filtering. No filtering by default.
             *
             * @param {Object} [datasets.configuration.templateEngine]          - Optional custom definition of template engine for the given dataset. This could be used to display suggestions the way you want for the given dataset. Called for every matching suggestion with three arguments : the DOM container where you should inject your template, the suggestion dataset and its corresponding item data.
             *
             * @param {Function} [datasets.configuration.dataParser]            - Optional custom method to parse data in a correct output for autocomplete needs from the response of the searchUrl call. Expected to return items in a correct output i.e. Array of items with at least a 'value' for each item, and additionally any variable to be used in a custom templateEngine. defaultDataParser called if none.
             * @param {Function} [datasets.configuration.onGetResults]          - Optional callback that will be called on remote search results retrieve.
             * @param {Function} [datasets.configuration.onNoResults]           - Optional callback that will be called on remote search results retrieve if no results.
             * @param {Function} [datasets.configuration.onError]               - Optional callback that will be called on remote search results retrieve if an error occurred. Called with the data returned by server and the text of the input.
             * @param {Function} [datasets.configuration.onTimeout]             - Optional callback that will be called on remote search. Called with the data returned by server and the text of the input.
             *
             * @return {this} instance.
             *
             * @private
             */
            _addDatasets: function (datasets) {
                var that = this;

                Utils.splat(datasets).forEach(function (dataset) {
                    that.addDataset(dataset, dataset.configuration);
                });

                return this;
            },

            /**
             * Add a dataset for autocomplete suggestions.
             *
             * @param {Object} [options] - The dataset options
             *
             * @param {String} [options.name]                          - Name for dataset identification.
             * @param {Boolean} [options.displayName=false]            - True to show dataset name with matching suggestions below.
             * @param {String} [options.searchUrl]                     - Optional URL to be used to retrieve remote suggestions instead of passing them through a static array. Expected to contains '{text}' to be set by the input text to search for. Please use remoteSearchEngine for advanced remote suggestions retrieving.
             *
             * @param {Object} [options.items] - Static array of suggestions.
             *
             * @param {String} options.items.value                     - Required suggestion value.
             * @param {String} [options.items.label]                   - Suggestion label to display. Takes value if none..
             * @param {String} [options.items.subLabel]                - Optional, sub-label displayed below label.
             * @param {Boolean} [options.items.disabled=false]         - True if the suggestion is disabled by default.
             * @param {Function} [options.items.handler]               - An optional handler to call when this item is clicked.
             *
             * @param {Object} [configuration] - Configuration for dataset manipulations.
             *
             * @param {Function} [configuration.searchEngine]          - Optional custom definition of search engine for the given dataset. Called with two arguments : the dataset and the text being searched. Expected to return matching items for given input text. Default search engine used if none.
             * @param {Function} [configuration.remoteSearchEngine]    - Optional custom definition of search engine for the given remote dataset. Called with two arguments : the dataset and the text being searched. Expected to return matching items for given input text. Default remote search engine used if none.
             * @param {Function} [configuration.filterEngine]          - Optional custom definition of filter engine for the given dataset. This could be used as a post-processing on matching data : sort, remove duplicates... On the given dataset only. Called with two arguments : the dataset and suggestions matching input text. Expected to return matching items after filtering. No filtering by default.
             *
             * @param {Object} [configuration.templateEngine]          - Optional custom definition of template engine for the given dataset. This could be used to display suggestions the way you want for the given dataset. Called for every matching suggestion with three arguments : the DOM container where you should inject your template, the suggestion dataset and its corresponding item data.
             *
             * @param {Function} [configuration.dataParser]            - Optional custom method to parse data in a correct output for autocomplete needs from the response of the searchUrl call. Expected to return items in a correct output i.e. Array of items with at least a 'value' for each item, and additionally any variable to be used in a custom templateEngine. defaultDataParser called if none.
             * @param {Function} [configuration.onGetResults]          - Optional callback that will be called on remote search results retrieve.
             * @param {Function} [configuration.onNoResults]           - Optional callback that will be called on remote search results retrieve if no results.
             * @param {Function} [configuration.onError]               - Optional callback that will be called on remote search results retrieve if an error occurred. Called with the data returned by server and the text of the input.
             * @param {Function} [configuration.onTimeout]             - Optional callback that will be called on remote search. Called with the data returned by server and the text of the input.
             *
             */
            addDataset: function (options, configuration) {
                var dataset = { items: [] },
                    /**
                     * Called when an item needs to be displayed in the suggestion list, you should apply the value
                     * and maybe change the DOM here.
                     *
                     * @param  {Element} element - The suggestion container where custom template should be injected
                     * @param  {Object} dataset  - The suggestion dataset
                     *
                     * @param  {Object} item     - The suggestion data (value, label... and more custom data)
                     *
                     * @param  {boolean} [item.parent]     - True if the item is a parent item
                     */
                    templateEngine = function (element, dataset, item) {
                        var itemLabel, itemSubLabel;

                        element.addClassName('default-template');

                        if (!item.parent) {
                            // Display classic item
                            itemLabel = UWA.createElement('span', { 'class': 'item-label' });
                            itemLabel.setText(item.label);

                            if (item.parentReference) {
                                itemLabel.setStyle('padding-left', item.parentReference.level + 'em');
                                itemLabel.addClassName('sub-item');
                            }

                            itemLabel.inject(element);

                            if (item.subLabel) {
                                element.addClassName('with-sub-label');
                                itemSubLabel = UWA.createElement('span', { 'class': 'sub-label' });
                                itemSubLabel.setText(item.subLabel);
                                if (item.parentReference) {
                                    itemSubLabel.setStyle('padding-left', item.parentReference.level + 'em');
                                }
                                itemSubLabel.inject(element);
                            }

                        } else {
                            // Display parent item
                            itemLabel = UWA.createElement('span', { 'class': 'item-parent-label' });
                            itemLabel.setText(item.label);

                            if (item.parentReference) {
                                itemLabel.setStyle('margin-left', item.parentReference.level + 'em');
                                itemLabel.addClassName('sub-item');
                            }

                            itemLabel.inject(element);
                        }
                    };

                dataset.id = Utils.getUUID().substr(0, 6);

                dataset.dataCache = {};

                if (options.items) {
                    this.addItems(options.items, dataset);
                }

                // Handling configuration being either in first argument or second argument
                configuration = configuration ? configuration : options.configuration;

                // Merging authorized configuration methods in dataset object
                if (configuration) {
                    ['searchEngine', 'remoteSearchEngine', 'filterEngine', 'templateEngine', 'dataParser', 'onError', 'onTimeout', 'onGetResults', 'onNoResults'].forEach(function (method) {
                        if (UWA.is(configuration[method], 'function')) {
                            dataset[method] = configuration[method];
                        }
                    });

                }

                dataset.templateEngine = dataset.templateEngine ? dataset.templateEngine : templateEngine;

                this.datasets.push(UWA.merge(dataset, options));

                // If user has already begin to interact with the autocomplete, update current suggestions.
                this.used && this.getSuggestions(false, true);
            },

            /**
             * Add items in the given dataset.
             *
             * @param {Object[]} options - Static array of items.
             *
             * @param {String} [options.parentItemId]            - Optional parent item reference.
             * @param {String} [options.level]                   - Optional sub-level (start from 1).
             * @param {String} options.value                     - Required item value.
             * @param {String} [options.label]                   - Item label to display. Takes value if none..
             * @param {String} [options.subLabel]                - Optional, sub-label displayed below label.
             * @param {Boolean} [options.selected=false]         - Whether to select this item from start.
             * @param {Boolean} [options.disabled=false]         - True if the item is disabled by default.
             * @param {Function} [options.handler]               - An optional handler to call when this item is clicked.
             *
             * @param {Object} dataset      - An existing dataset to be updated.
             */
            addItems: function (options, dataset) {
                var that = this;

                Utils.splat(options).forEach(function (itemOptions) {
                    if (options.parentItemId) {
                        itemOptions.parentItemId = options.parentItemId;
                        itemOptions.level = options.level;
                    }
                    that._addItem(itemOptions, dataset);
                });
            },

            /**
             * Add an item in a given dataset.
             *
             * @param {Object} options - Item options.
             *
             * @param {String} [options.parentItemId]            - Optional parent item reference.
             * @param {String} [options.level]                   - Optional sub-level (start from 1).
             * @param {String} options.value                     - Required item value.
             * @param {String} [options.label]                   - Item label to display. Takes value if none..
             * @param {String} [options.subLabel]                - Optional, sub-label displayed below label.
             * @param {String} [options.name]                    - Optional, item custom identifier.
             * @param {Boolean} [options.selected=false]         - Whether to select this item from start.
             * @param {Boolean} [options.disabled=false]         - True if the item is disabled by default.
             * @param {Function} [options.handler]               - An optional handler to call when this item is clicked.
             * @param {String} [options.items]                   - Eventual sub-items.
             *
             * @param {Object} dataset - An existing dataset to be updated.
             *
             * @param {String} [dataset.id]      - Auto-generated dataset reference.
             *
             * @private
             */
            _addItem: function (options, dataset) {
                var item = {};

                // Break if item has no value and no child
                if ((!options.value || !options.value.length) && !options.items) { return; }

                item.id = Utils.getUUID().substr(0, 6);
                item.datasetId = dataset.id;
                item.label = (options.label) ? (options.label) : (options.value);

                dataset.items.push(UWA.merge(item, options));

                // If is a parent
                if (options.items) {
                    item.parent = true;
                    item.level = (!options.level) ? (1) : (options.level + 1);
                    options.items.level = item.level;
                    options.items.parentItemId = item.id;
                    this.addItems(options.items, dataset);
                }

                // If pre-selection required
                options.selected && this.dispatchEvent('onSelect', [item]);

            },

            /**
             * Enable an item for clicking.
             *
             * @param {number|String|Element} id - Identifier of the item to enable.
             * @param {Boolean} [force=false]    - Multi selection only. True to also disable selected item(s) if some.
             * @returns {Autocomplete} - The instance
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            enableItem: function (id, force) {
                return this._setItemDisabled(id, false, force);
            },

            /**
             * Disable an item for clicking.
             *
             * @param {number|String|Element} id - Identifier of the item to disable.
             * @param {Boolean} [force=false]    - Multi selection only. True to also enable selected item(s) if some.
             * @returns {Autocomplete} - The instance
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            disableItem: function (id, force) {
                return this._setItemDisabled(id, true, force);
            },


            /**
             * Enable/disable an item for clicking.
             *
             * @param {number|String|Element} id - Identifier of the item to disable.
             * @param  {Boolean} [disabled=true] - Disable on `true`, enable on `false`.
             * @param {Boolean} [force=false]    - Multi selection only. True to also disable selected item(s) if some.
             * @returns {Autocomplete} - The instance
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @private
             */
            _setItemDisabled: function (id, disabled, force) {
                var item = this.getItem(id);

                if (!item) { return; }

                if (typeof disabled === 'undefined') { disabled = true; }

                item.disabled = disabled;

                if (force === true && this.options.multiSelect) {
                    this._setBadgeDisabled(item.id, disabled);
                }

                return this;
            },

            /**
             * Disable selection badge of given item (multi selection mode only).
             *
             * @param {number} id      - id of the item to enable or disable.
             * @returns {Autocomplete} - The instance
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @private
             */
            _setBadgeDisabled: function (id, disabled) {
                var position = this.getSelectedItemPosition(id), badge;

                if (position >= 0) {
                    badge = this.badges[position];
                    badge && badge.setDisabled(disabled);
                }

                return this;
            },

            /**
             * Remove an item from given dataset cache
             * @param  {Object} dataset - Dataset from which we want to get a cache
             * @param  {Object} item    - Item to remove from the cache
             * @private
             */
            _removeItemFromCache: function (dataset, item) {
                var cachedItems, cachedText, index;

                if (dataset.dataCache) {
                    // Remember cache structure : 'mySearch1' (cachedText) -> cachedItems, 'mySearch2' (cachedText) -> otherCachedItems...
                    // We need to remove item occurrence in every cachedItems.
                    for (cachedText in dataset.dataCache) {
                        if (dataset.dataCache.hasOwnProperty(cachedText)) {
                            cachedItems = dataset.dataCache[cachedText];
                            index = cachedItems.indexOf(item);
                            UWA.is(index) && dataset.dataCache[cachedText].splice(index, 1);
                        }
                    }
                }
            },

            /**
             * Remove one or many specified item(s).
             * @param  {number|String|Element} id - Identifier of the item to retrieve (node, position, name, id or value).
             * @private
             */
            removeItem: function (id) {
                var that = this;

                Utils.splat(id).forEach(function (option) {
                    that._removeItem(option);
                });
            },

            /**
             * Remove item for the given identifier.
             * @param  {number|String|Element} id - Identifier of the item to retrieve (node, position, name, id or value).
             * @private
             */
            _removeItem: function (id) {
                var item = this.getItem(id), itemDataset, index;

                if (item) {
                    // First unselect if was selected
                    this.onUnselect(item);
                    // Remove from dataset
                    itemDataset = this.getDataset(item.datasetId);
                    index = itemDataset.items.indexOf(item);
                    UWA.is(index) && itemDataset.items.splice(index, 1);
                    // Remove from its cache if needed
                    this._removeItemFromCache(itemDataset, item);
                    // Remove from current suggestion list if necessary
                    index = this.currentSuggestions.indexOf(item);
                    UWA.is(index) && this.currentSuggestions.splice(index, 1);
                }
            },

            /**
             * Get the autocomplete input id.
             *
             * @return {String} - The input id.
             */
            getId: function () {
                return this.elements.input.id;
            },

            /**
             * Set the autocomplete input id attribute.
             *
             * @param {String} id - The autocomplete new id.
             *
             * @return {this} instance.
             */
            setId: function (id) {
                if (UWA.is(id, 'string')) { this.elements.input.id = id; }
                return this;
            },

            /**
             * Get the autocomplete input name.
             *
             * @return {String} - The input name.
             */
            getName: function () {
                return this.elements.input.name;
            },

            /**
             * Toggle selection on given item
             *
             * @param  {Object}  item          - Item reference
             * @param  {number}  [position]    - To add or remove at the given position of the already selected items (starting from 0). Multi select mode only.
             * @param  {Boolean} [select]      - True to select, false to unselect
             * @param  {number}  [newPosition] - The next badge position to focus on if unselecting. Multi select mode only.
             *
             * @return {Object}                 - The given item after modification
             */
            toggleSelect: function (item, position, select, newPosition) {
                if (!item || item.disabled) { return; }

                if (select === true) {
                    this.dispatchEvent('onSelect', [item, position]);
                } else if (select === false) {
                    this.dispatchEvent('onUnselect', [item, position, newPosition]);
                } else if (item.selected) {
                    this.dispatchEvent('onUnselect', [item, position, newPosition]);
                } else {
                    this.dispatchEvent('onSelect', [item, position]);
                }

                return item;
            },

            /**
             * Select the given item.
             *
             * @param  {Object} item         - Item reference
             * @param  {String} item.id      - Required item id (auto-generated on addItem() / addItems()).
             * @param  {String} [item.label] - Required item label.
             * @param  {number} [position]   - Item position in selected items list. Multi select mode only. Starting from 0
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            onSelect: function (item, position) {
                var itemBadgeOptions,
                    itemBadge,
                    itemLi,
                    innerInput,
                    options = this.options,
                    that = this;

                if (!options.multiSelect) {
                    // If single select mode, unselect the currently selected item and update input
                    this.selectedItems[0] && this.onUnselect(this.selectedItems[0]);
                    this.elements.input.value = item.label;
                    this.elements.container.toggleClassName(this.CLS_FILLED, true);
                    // Hide suggestions list
                    this.dispatchEvent('onHideSuggests');
                } else {
                    innerInput = this._buildInnerInput();
                    // If multi select mode, add item in input container
                    itemBadgeOptions = {
                        id: 'selected-' + item.id,
                        content: item.label,
                        selectable: true,
                        events: {
                            onClose: function (event) {
                                var deletionPosition = that.getBadgePosition(itemBadge.elements.container),
                                    // Next position : current (next badge is going to be on this position) or -1 if no badge on right
                                    newPosition = (deletionPosition === that.badges.length - 1) ? -1 : deletionPosition;

                                that._handleBadgeDeletion(deletionPosition, newPosition);
                                Event.preventDefault(event);
                            }
                        }
                    };

                    if (options.closableItems) {
                        itemBadgeOptions.closable = true;
                    }

                    itemBadge = new Badge(itemBadgeOptions);
                    // To allow focus on badge
                    itemBadge.elements.container.setAttribute('tabindex', '-1');
                    itemBadge.elements.container.setStyle('outline', '0');

                    // Unselect previously selected badge if some
                    this._toggleBadgeSelection(this.currentPosition, false);

                    if (position >= 0) {
                        this.resetInput(position);

                        // Insert badges right after previous if existing, else at the beginning of the input (index is 0)
                        if (this.badges[position - 1]) {
                            itemBadge.inject(this.badges[position - 1].elements.container, 'after');
                        } else {
                            itemBadge.inject(this.elements.inputContainer.getChildren()[0], 'before');
                        }
                        this.badges.splice(position, 0, itemBadge);
                        this.innerInputs.splice(position, 0, innerInput);
                    } else {
                        this.resetInput();
                        itemBadge.inject(this.elements.input, 'before');
                        this.badges.push(itemBadge);
                        this.innerInputs.push(innerInput);
                    }

                    innerInput.inject(itemBadge.elements.container, 'before');

                    // Update position in badges items and focus this new badge
                    this.dispatchEvent('onUpdateInputPosition', [position]);
                    this._toggleBadgeSelection(this.currentPosition);

                    // If item can be selected only once, retrieve its li in suggests to select it
                    if (!options.itemMultiSelect) {
                        itemLi = this.elements.suggests.getElement('#' + this.CLS_ITEM + '-' + item.id);
                        itemLi && itemLi.addClassName('selected-item');
                    }
                }

                item.selected = true;

                if (position >= 0) {
                    this.selectedItems.splice(position, 0, item);
                } else {
                    this.selectedItems.push(item);
                }

                // Re-show all in multi-select + item multi select modes
                this.options.multiSelect && this.options.itemMultiSelect && this.options.showSuggestsOnFocus && this.showAll();

                // Call the item handler if it was provided.
                if (UWA.is(item.handler, 'function')) {
                    item.handler.call(this);
                }

                this._updateSuggestsPosition();
            },

            /**
             * Unselect the given item.
             *
             * @param  {Object} item                - Item reference
             * @param  {String} item.id             - Item id (auto-generated on addItem() / addItems()).
             * @param  {number} [position]          - Item position in selected items list. Multi select mode only.
             * @param  {number} [newPosition]       - Next position to focus on. Multi select mode only.
             * @param  {Boolean} [resetInput=true]  - [Single selection mode only] True to also reset input.
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            onUnselect: function (item, position, newPosition, resetInput) {
                var index,
                    itemBadge,
                    itemLi,
                    options = this.options;

                if (!options.multiSelect) {
                    (resetInput !== false) && this.resetInput();
                    index = this.getSelectedItemPosition(item.id);
                    UWA.is(index) && index > -1 && this.selectedItems.splice(index, 1);
                    this.elements.container.toggleClassName(this.CLS_FILLED, false);
                } else {
                    index = (this.options.itemMultiSelect && position >= 0) ? position : this.getSelectedItemPosition(item.id);

                    if (UWA.is(index) && index > -1) {
                        this.resetInput(position);
                        itemBadge = this.badges[index];
                        if (!itemBadge) { return; }
                        // Unselect if necessary
                        this._toggleBadgeSelection(index, false);
                        itemBadge.destroy();
                        this.innerInputs[index].destroy();
                        this.badges.splice(index, 1);
                        this.selectedItems.splice(index, 1);
                        this.innerInputs.splice(index, 1);
                        (newPosition >= 0) && this._updateBadgeFocus(newPosition);
                    }

                    // If item can be selected only once, retrieve its li in suggests to unselect it
                    if (!options.itemMultiSelect) {
                        itemLi = this.elements.suggests.getElement('#' + this.CLS_ITEM + '-' + item.id);
                        itemLi && itemLi.removeClassName('selected-item');
                    }
                }

                item.selected = false;

                if (!options.multiSelect) { this.dispatchEvent('onHideSuggests'); }

                this._updateSuggestsPosition();
            },

            /**
             * Unselect every selected items.
             * @param {Boolean} [silent=true] - False to dispatch onUnselect event

             */
            unselectAll: function (silent) {
                var that = this, copy = [];

                copy = copy.concat(this.selectedItems);

                copy.forEach(function (item) {
                    if (silent === false) {
                        that.dispatchEvent('onUnselect', [item]);
                    } else {
                        that.onUnselect(item);
                    }
                });
            },

            /**
             * Show every items (of non-remote datasets).
             */
            showAll: function () {
                var suggestionsByDataset = [],
                    matchingDataset;

                this.datasets.forEach(function (dataset) {
                    matchingDataset = {};
                    matchingDataset.suggestions = [];

                    if (dataset.items && dataset.items.length) {
                        matchingDataset = UWA.merge(matchingDataset, dataset);
                        matchingDataset.suggestions = dataset.items;
                        suggestionsByDataset.push(matchingDataset);
                    }

                });

                if (UWA.is(this.options.filterEngine, 'function')) {
                    suggestionsByDataset = this.options.filterEngine.call(this, suggestionsByDataset);
                }

                if (suggestionsByDataset.length) {
                    this.dispatchEvent('onUpdateSuggests', [suggestionsByDataset]);
                }
            },

            /**
             * Retrieves every items
             * @returns {Array}     Array of item objects
             */
            getItems: function () {
                var items = [];

                this.datasets && this.datasets.forEach(function (dataset) {
                    if (dataset.items && dataset.items.length) {
                        items = items.concat(dataset.items);
                    }
                });

                return items;
            },

            /**
             * Retrieves the specified item.
             *
             * @param  {number|String|Element} id - Identifier of the item to retrieve (node, position, name, id or value).
             * @returns {Object}                  - Item object if retrieved, otherwise false.
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            getItem: function (id) {
                var datasetPosition, datasetLength,
                    itemPosition, itemsLength,
                    dataset, element,
                    item = false;

                for (datasetPosition = 0, datasetLength = this.datasets.length; datasetPosition < datasetLength; datasetPosition += 1) {

                    dataset = this.datasets[datasetPosition];

                    if (!dataset.items) {
                        item = false;
                        continue;
                    }

                    for (itemPosition = 0, itemsLength = dataset.items.length; itemPosition < itemsLength; itemPosition += 1) {
                        item = dataset.items[itemPosition];
                        // If argument is a Node, compare to item's HTML element
                        if (id && id.nodeType) {
                            element = id.hasClassName(this.CLS_ITEM) ? id : id.getParent();
                            if (this.CLS_ITEM + '-' + item.id === element.id) break;
                            // If argument is a number, compare to item's index position
                            // If argument is a String, compare to item's unique id, name or value
                        } else if (itemPosition === id || item.id === id || item.name === id || item.value === id) {
                            break;
                        }

                        item = false;
                    }

                    if (item) { break; }
                }

                return item;
            },

            /**
             * Retrieves the specified item regarding a given label.
             * Useful when trying to retrieve an item from a given input.
             *
             * @param  {String} label   - Label of the item to retrieve
             *
             * @return {Object}         - Item object if retrieved, otherwise false.
             */
            getItemByLabel: function (label) {
                var datasetPosition, datasetLength,
                    itemPosition, itemsLength,
                    dataset,
                    item = false;

                for (datasetPosition = 0, datasetLength = this.datasets.length; datasetPosition < datasetLength; datasetPosition += 1) {

                    dataset = this.datasets[datasetPosition];

                    if (!dataset.items) {
                        item = false;
                        break;
                    }

                    for (itemPosition = 0, itemsLength = dataset.items.length; itemPosition < itemsLength; itemPosition += 1) {
                        item = dataset.items[itemPosition];
                        if (item.label.toLowerCase() === label.toLowerCase()) { break; }
                        item = false;
                    }

                    if (item) { break; }
                }

                return item;
            },

            /**
             * Retrieves item from its corresponding DOM suggestion.
             *
             * @param  {Element} suggestion   - Suggestion DOM Element for the item to retrieve.
             *
             * @return {Object}               - Item object if retrieved, otherwise false.
             */
            getItemFromSuggestion: function (suggestion) {
                var matchingItem = null,
                    suggestionId = suggestion.id && suggestion.id.replace(this.CLS_ITEM + '-', '');

                if (!suggestionId) { return; }

                this.currentSuggestions.some(function (item) {
                    // item id can be a number
                    if ((item.id + '') === suggestionId) {
                        matchingItem = item;
                    }
                    // Break if item has been found
                    return matchingItem;
                });

                return matchingItem;
            },

            /**
             * Retrieves the specified dataset.
             *
             * @param  {number|String} id - Identifier of the item to retrieve (position, id or name).
             * @returns {Object|Boolean}  - Item object if retrieved, otherwise false.
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            getDataset: function (id) {
                var datasetPosition, datasetLength,
                    dataset;

                for (datasetPosition = 0, datasetLength = this.datasets.length; datasetPosition < datasetLength; datasetPosition += 1) {
                    dataset = this.datasets[datasetPosition];

                    // If argument is a number, compare to item's index position
                    // If argument is a String, compare to item's unique id or tab's name
                    if (datasetPosition === id || dataset.id === id || dataset.name === id) {
                        break;
                    }

                    dataset = false;
                }

                return dataset;
            },

            /**
             * Remove every item and cache of the dataset for the given identifier.
             * This will also unselect its selected items.
             * This will keep the dataset available.
             *
             * @param  {number|String} id - Identifier of the dataset to clean (position, id or name).
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            cleanDataset: function (id) {
                var dataset = this.getDataset(id), selectedDatasetItems, that = this;

                // Unselect its selected items
                selectedDatasetItems = this.selectedItems.filter(function (item) { return (item.datasetId === dataset.id); });

                selectedDatasetItems.forEach(function (item) {
                    that.onUnselect(item);
                });

                // Clean cache
                dataset.dataCache = {};
                // Remove items
                dataset.items = [];
            },

            /**
             * Definitively remove dataset for the given identifier.
             * This will also remove and unselect (if appropriate) its items.
             *
             * @param  {number|String} id - Identifier of the dataset to remove (position, id or name).
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            removeDataset: function (id) {
                var dataset = this.getDataset(id), index, selectedDatasetItems = [], that = this, needRefresh = false;

                if (dataset) {
                    index = this.datasets.indexOf(dataset);
                    UWA.is(index) && this.datasets.splice(dataset, 1);
                    // Also remove items from this dataset that are currently selected
                    selectedDatasetItems = this.selectedItems.filter(function (item) { return (item.datasetId === dataset.id); });
                    selectedDatasetItems.forEach(function (item) {
                        that.onUnselect(item);
                    });
                    // Also check if refreshing currentSuggestions is necessary
                    needRefresh = this.currentSuggestions.some(function (item) {
                        return (item.datasetId === dataset.id);
                    });

                    needRefresh && this.getSuggestions();
                }
            },

            /**
             * Dataset name rendering.
             *
             * @param  {String} datasetName     - A dataset name
             *
             * @private
             */
            _appendDatasetName: function (datasetName, container) {
                var itemContainer, itemLabel;
                if (datasetName) {
                    itemContainer = UWA.createElement('li', { 'class': 'dataset-header' });
                    itemLabel = UWA.createElement('span');
                    itemLabel.setText(datasetName);
                    itemLabel.inject(itemContainer);
                    itemContainer.inject(container);
                }
            },

            /**
             * Append an item in the suggestions area with default or custom template engine (regarding item's dataset properties).
             *
             * @param {Object}  dataset         - Existing item's dataset reference.
             * @param {Object}  item            - Existing item reference.
             * @param {Element} container       - UWA Element where to append the item
             *
             * @private
             */
            _appendItem: function (dataset, item, container) {
                var itemContainer, parentReference;

                // If parent not yet in the list, add it first
                if (item.parentItemId) {

                    parentReference = this.getItem(item.parentItemId);

                    if (parentReference) {
                        item.parentReference = parentReference;
                        if (!container.getElement('#' + this.CLS_ITEM + '-' + item.parentItemId)) {
                            this._appendItem(dataset, parentReference, container);
                        }
                    }
                }

                itemContainer = UWA.createElement('li', {
                    'class': this.CLS_ITEM
                });

                itemContainer.id = this.CLS_ITEM + '-' + item.id;
                dataset.templateEngine.call(this, itemContainer, dataset, item);

                if (item.parent) {

                    itemContainer.addClassName(this.CLS_PARENT_ITEM);

                    // If the parent has a value, it means it is selectable.
                    if (item.value && !item.disabled) {
                        itemContainer.addClassName('clickable');
                    }
                }

                item.selected && !this.options.itemMultiSelect && itemContainer.addClassName('selected-item');
                item.disabled && itemContainer.addClassName('disabled');
                item.elements = [];
                item.elements.container = itemContainer;
                itemContainer.inject(container);
            },

            /**
             * Default search engine to retrieve matching items from given input text for non-remote datasets.
             * Simple lowercase/contains test.
             *
             * @param  {Object} dataset - Dataset reference where text is being searched.
             * @param  {String} text    - Text being searched
             *
             * @return {Object}         - Every items from dataset matching given text.
             */
            defaultSearchEngine: function (dataset, text) {
                var matchingItems = [];

                dataset.items && dataset.items.forEach(function (item) {
                    if (item.value && item.label.toLowerCase().contains(text.toLowerCase())) {
                        matchingItems.push(item);
                    }
                });

                return matchingItems;
            },

            /**
             * Default search engine to retrieve matching items from given input text for remote datasets.
             * Simply calls dataset.searchUrl and expects it to return an array of matching items.
             * Do not contains any search logic.
             *
             * @param  {Object} dataset - Dataset reference where text is being searched.
             * @param  {String} text    - Text being searched
             *
             * @return {Object}         - Every items from dataset matching given text.
             */
            defaultRemoteSearchEngine: function (dataset, text) {
                var finalUrl,
                    that = this,
                    results;

                return new Promise(function (resolve, reject) {

                    if (dataset.searchUrl) {
                        finalUrl = dataset.searchUrl.replace('{text}', text);
                        Data.request(finalUrl, {
                            method: 'GET',
                            type: 'text',
                            onComplete: function (data) {
                                results = {};
                                results.matchingItems = [];
                                // Use provided parser or default
                                if (data) {
                                    results.matchingItems = (UWA.is(dataset.dataParser, 'function')) ? (dataset.dataParser.call(that, dataset, data)) : (that.defaultDataParser(data));
                                }
                                results.dataset = dataset;
                                resolve(results);
                            },
                            onFailure: function (data) {
                                data.type = 'error';
                                data.dataset = dataset;
                                reject(data);
                            },
                            onTimeout: function (data) {
                                data.type = 'timeout';
                                data.dataset = dataset;
                                reject(data);
                            }
                        });
                    }
                });
            },

            /**
             * Returns true if the item is selected knowing a dataset and a value. Useful while getting remote data without identifer.
             *
             * @param  {String}  datasetId - Dataset identifier.
             * @param  {String}  value     - Item value.
             *
             * @return {Object}            - The corresponding selected item, otherwise false.
             */
            isSelected: function (datasetId, value) {
                var item = false;

                this.selectedItems.some(function (selectedItem) {

                    if (selectedItem.datasetId === datasetId && selectedItem.value === value) {
                        item = selectedItem;
                    }
                    // Break if item has been found
                    return item;
                });

                return item;
            },

            /**
             * Get the currently clicked item if appropriate.
             * Multi select mode only.
             *
             * @return {Object} The item object if its badge is currently selected, else null.
             */
            getFocusedItem: function () {
                var item = null;
                if (this.options.multiSelect && this.currentPosition >= 0) {
                    item = this.selectedItems[this.currentPosition];
                }
                return item;
            },

            /**
             * Get the currently clicked item if appropriate.
             * Multi select mode only.
             *
             * @return {Badge} The Badge instance currently selected, else null.
             */
            getFocusedBadge: function () {
                var badge = null;
                if (this.options.multiSelect && this.currentPosition >= 0) {
                    badge = this.badges[this.currentPosition];
                }
                return badge;
            },

            /**
             * Returns the position of a given item.
             * Not reliable if an item can be selected more than once (itemMultiSelect mode).
             *
             * @param  {String}  id        - Item id.
             *
             * @return {Object}            - The corresponding item position in selected items array, else -1
             */
            getSelectedItemPosition: function (id) {
                var position = -1;

                this.selectedItems.some(function (selectedItem, index) {
                    if (selectedItem.id === id) {
                        position = index;
                    }
                    // Break if item has been found
                    return position > -1;
                });

                return position;
            },

            /**
             * Returns the position of a given badge dom
             *
             * @param  {DOM} badgeContainer - DOM element for the badge
             * @returns {number}            - Position of the given badge, else -1
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            getBadgePosition: function (badgeContainer) {
                var position = -1;

                this.badges.some(function (badge, index) {
                    if (badge.elements.container === badgeContainer) {
                        position = index;
                    }
                    // Break if item has been found
                    return position > -1;
                });

                return position;
            },

            /**
             * Determine the available suggestions from each dataset for the given input text.
             *
             * @param  {String}     text    - Text for which we want suggestion
             * @param  {Boolean}    silent  - True to prevent re-showing suggestions list
             */
            getSuggestions: function (text, silent) {
                var suggestionsByDataset = [],
                    matchingDataset,
                    spinner,
                    itemSpinner,
                    that = this,
                    datasetFromRemote,
                    noRemoteDataset = true,
                    selectedItem,

                    // Callback used for remote datasets
                    callback = {
                        success: function (results) {
                            matchingDataset = {};
                            matchingDataset.suggestions = results.matchingItems;
                            datasetFromRemote = results.dataset;
                            spinner && spinner.elements && spinner.destroy();

                            // Deal with results
                            if (matchingDataset.suggestions.length > 0) {

                                // Call dataset custom getResults callback if some
                                if (UWA.is(datasetFromRemote.onGetResults, 'function')) {
                                    datasetFromRemote.onGetResults.call(that, datasetFromRemote, text, matchingDataset.suggestions);
                                }

                                matchingDataset.suggestions.forEach(function (item) {

                                    // Keep the dataset id in the item data.
                                    if (!item.datasetId) {
                                        item.datasetId = datasetFromRemote.id;
                                    }

                                    // Check if was selected.
                                    // This prevent re-select a same item from two different searches.
                                    selectedItem = that.isSelected(item.datasetId, item.value);

                                    if (selectedItem) {
                                        item.selected = true;
                                        item.id = selectedItem.id;
                                    }

                                    // Add ids if not
                                    if (!item.id) {
                                        item.id = Utils.getUUID().substr(0, 6);
                                    }

                                });

                                // Call dataset custom filterEngine callback if some
                                if (UWA.is(datasetFromRemote.filterEngine, 'function')) {
                                    matchingDataset.suggestions = datasetFromRemote.filterEngine.call(that, datasetFromRemote, matchingDataset.suggestions);
                                }

                            } else if (UWA.is(datasetFromRemote.onNoResults, 'function')) {
                                // If no results, call dataset custom onNoResults callback if some
                                datasetFromRemote.onNoResults.call(that, datasetFromRemote, text);
                            }

                            // Add matching items in the whole suggestions by dataset array.
                            if (matchingDataset.suggestions && matchingDataset.suggestions.length) {
                                matchingDataset = UWA.merge(matchingDataset, datasetFromRemote);
                                matchingDataset.id = datasetFromRemote.id;
                                suggestionsByDataset.push(matchingDataset);
                            }

                            // Update cache
                            datasetFromRemote.dataCache[text] = matchingDataset.suggestions;

                            // If we have a global filter engine, call it.
                            if (UWA.is(that.options.filterEngine, 'function')) {
                                suggestionsByDataset = that.options.filterEngine.call(that, suggestionsByDataset);
                            }

                            // Update suggestions list
                            that.dispatchEvent('onUpdateSuggests', [suggestionsByDataset, silent]);
                        },
                        error: function (data) {
                            // Kill spinner indicator, call custom dataset error callbacks if some
                            spinner && spinner.elements && spinner.destroy();
                            datasetFromRemote = data.dataset;

                            if (data.type === 'error' && UWA.is(datasetFromRemote.onError, 'function')) {
                                datasetFromRemote = data.dataset;
                                datasetFromRemote.onError.call(that, data || [], text);
                            }

                            if (data.type === 'timeout' && UWA.is(datasetFromRemote.onTimeout, 'function')) {
                                datasetFromRemote.onTimeout.call(that, data || [], text);
                            }

                            // Update suggestions list that was waiting for a result here before display
                            that.dispatchEvent('onUpdateSuggests', [suggestionsByDataset, silent]);
                        }
                    };

                text = text || this.elements.input.value;
                // Clean suggestion list
                this.elements.suggests.empty();

                this.datasets.forEach(function (dataset) {
                    matchingDataset = {};
                    matchingDataset.suggestions = [];

                    // Use cache if this text has already been typed
                    if (dataset.dataCache[text]) {
                        matchingDataset.suggestions = dataset.dataCache[text];
                    } else {
                        // Sorry eslint but it is just humanly more readable here
                        // eslint-disable-next-line no-lonely-if
                        if (UWA.is(dataset.searchEngine, 'function')) {
                            // Case 1 : Custom local search engine - call it, then filter result if needed, update cache.
                            matchingDataset.suggestions = dataset.searchEngine.call(that, dataset, text);

                            if (UWA.is(dataset.filterEngine, 'function')) {
                                matchingDataset.suggestions = dataset.filterEngine.call(that, dataset, matchingDataset.suggestions);
                            }

                            dataset.dataCache[text] = matchingDataset.suggestions;

                        } else if (UWA.is(dataset.remoteSearchEngine, 'function')) {
                            // Case 2 : Custom remote search engine. Add a spinner in suggestions list and call the remote search engine.
                            noRemoteDataset = false;
                            if (!spinner) {
                                itemSpinner = UWA.createElement('li', { 'class': 'message' });
                                itemSpinner.inject(that.elements.suggests, 'top');
                                spinner = new Spinner();
                                spinner.inject(itemSpinner);
                                spinner.show();
                            }

                            // Show suggestions list to see the spinner
                            that.onShowSuggests();

                            // Call the custom dataset remote search engine with our callback.
                            Promise.cast(dataset.remoteSearchEngine.call(that, dataset, text)).then(callback.success, callback.error);

                        } else {
                            // Case 3 : default search (remote or local)
                            if (dataset.searchUrl) {
                                // If the dataset has a searchUrl, we use the default remote search engine.
                                noRemoteDataset = false;

                                if (!spinner) {
                                    itemSpinner = UWA.createElement('li', { 'class': 'message' });
                                    itemSpinner.inject(that.elements.suggests, 'top');
                                    spinner = new Spinner();
                                    spinner.inject(itemSpinner);
                                    spinner.show();
                                }

                                // Show suggestions list to see the spinner
                                that.onShowSuggests();
                                // Call the default remote search engine with our callback.
                                Promise.cast(that.defaultRemoteSearchEngine(dataset, text)).then(callback.success, callback.error);
                            } else {
                                // Else we use the default local search engine
                                matchingDataset.suggestions = that.defaultSearchEngine(dataset, text);
                            }

                            // Call dataset custom filterEngine callback if some
                            if (UWA.is(dataset.filterEngine, 'function')) {
                                matchingDataset.suggestions = dataset.filterEngine.call(that, dataset, matchingDataset.suggestions);
                            }
                            // Update cache
                            dataset.dataCache[text] = matchingDataset.suggestions;
                        }
                    }

                    // Add matching items in the whole suggestions by dataset array.
                    if (matchingDataset.suggestions && matchingDataset.suggestions.length) {
                        matchingDataset = UWA.merge(matchingDataset, dataset);
                        matchingDataset.id = dataset.id;
                        suggestionsByDataset.push(matchingDataset);
                    }
                });

                if (noRemoteDataset) {
                    if (UWA.is(this.options.filterEngine, 'function')) {
                        suggestionsByDataset = this.options.filterEngine.call(that, suggestionsByDataset);
                    }
                    this.dispatchEvent('onUpdateSuggests', [suggestionsByDataset, silent]);
                }
            },

            /**
             * Returns true if the suggestions container should go on top to be visible on current viewport.
             * @param  {number} base - Top base position
             * @returns {Boolean}
             * @private
             */
            _shouldDropUp: function (base) {
                // 'top' is : Autocomplete container 'y' + inputContainer height if not floating mode, else a given base (bottom of inner input)
                var top = base || (this.getContent().getOffsets().y + this.elements.inputContainer.getDimensions().height),
                    height = this.elements.suggestsContainer.getSize().height,
                    viewportHeight = document.documentElement.clientHeight || window.innerHeight,
                    scrollTop = window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop;

                return (top + height > viewportHeight + scrollTop);
            },

            /**
             * Returns true if the suggestions container should go on left to be visible on current viewport. Floating mode only.
             * @param  {number} base - Left base position
             * @returns {Boolean}
             * @private
             */
            _shouldDropLeft: function (base) {
                var left = base,
                    width = this.elements.suggestsContainer.getSize().width,
                    viewportWidth = window.innerWidth || document.documentElement.clientWidth,
                    scrollLeft = window.pageXOffset || document.body.scrollLeft || document.documentElement.scrollLeft;

                return (left + width > viewportWidth + scrollLeft);
            },

            /**
             * Smart positioning for the suggestions container.
             * @private
             */
            _updateSuggestsPosition: function () {
                var container = this.elements.container,
                    suggestsContainer = this.elements.suggestsContainer,
                    floating = this.options.floatingSuggestions && this.options.multiSelect,
                    floatingInput, floatingInputX = 0, floatingInputY = 0, floatingInputHeight = 0,
                    floatingSuggestionsBase,
                    dropUp, dropLeft;

                if (floating) {
                    floatingInput = (this.innerInputs && this.innerInputs[this.currentPosition]) ? this.innerInputs[this.currentPosition] : this.elements.input;
                    floatingInputX = floatingInput ? floatingInput.getPosition().x : this.elements.input.x || 0;
                    floatingInputY = floatingInput ? floatingInput.getPosition().y : this.elements.input.y || 0;
                    floatingInputHeight = floatingInput && floatingInput.getDimensions().height || 0;
                    floatingSuggestionsBase = floatingInput.getOffsets().y + floatingInputHeight + 4;
                    this.elements.suggestsContainer.setStyle('top', '');
                }

                dropUp = this._shouldDropUp(floatingSuggestionsBase);

                if (floating) {
                    dropLeft = this._shouldDropLeft(floatingInput.getOffsets().x);

                    if (dropLeft) {
                        suggestsContainer.setStyle('left', floatingInputX - ((floatingInput.getOffsets().x + suggestsContainer.getSize().width) - document.documentElement.clientWidth));
                    } else {
                        suggestsContainer.setStyle('left', floatingInputX);
                    }

                    if (dropUp) {
                        suggestsContainer.setStyle('top', floatingInputY - suggestsContainer.getDimensions().height - 8);
                    } else {
                        suggestsContainer.setStyle('top', floatingInputY + floatingInputHeight + 4);
                    }

                }

                if (dropUp) {
                    container.addClassName('dropup');
                } else {
                    container.removeClassName('dropup');
                }

            },

            /**
             * Update suggestions container with the given list of items.
             *
             * @param  {Object}     suggestionsByDataset        - List of suggestions to display.
             * @param  {Boolean}    silent                      - True to prevent re-showing suggestions list
             */
            onUpdateSuggests: function (suggestionsByDataset, silent) {
                var itemNoResults,
                    that = this,
                    displayedItems = 1,
                    computedHeight = 0,
                    DOMSuggestions = UWA.createElement('div'),
                    noMatchMessage = this.options.noResultsMessage,
                    preventShow = false;

                this.elements.suggests.empty();
                this.currentSuggestions = [];
                this.keyboardIndex = -1;
                this.elements.suggestsContainer.setStyle('height', this.options.maxHeight + 'px');

                // Case if suggestions
                if (suggestionsByDataset.length) {
                    // Re init scroll
                    this.scroller.scrollTo(0, 0);
                    this.elements.suggestsContainer.removeClassName('no-result');

                    suggestionsByDataset.forEach(function (dataset) {
                        if (dataset.name && dataset.displayName) {
                            that._appendDatasetName(dataset.name, DOMSuggestions);
                        }
                        if (Array.isArray(dataset.suggestions)) {
                            that.currentSuggestions = that.currentSuggestions.concat(dataset.suggestions);
                            dataset.suggestions.forEach(function (item) {
                                if ((that.options.maxSuggestsToDisplay < 0) || (that.options.maxSuggestsToDisplay > 0 && displayedItems <= that.options.maxSuggestsToDisplay)) {
                                    that._appendItem(dataset, item, DOMSuggestions);
                                    displayedItems++;
                                }
                            });
                        }
                    });

                    // Inject items in DOM
                    this.elements.suggests.setHTML(DOMSuggestions.getHTML());

                    // Case if no suggestions and a message to display
                } else if (noMatchMessage) {
                    itemNoResults = UWA.createElement('li', { 'class': 'message' });
                    itemNoResults.setHTML(this.options.noResultsMessage);
                    itemNoResults.inject(this.elements.suggests);
                    this.elements.suggestsContainer.addClassName('no-result');
                    // Case if no suggestions and no message to display : show nothing.
                } else {
                    preventShow = true;
                }

                // Reduce height of suggestions list (fixed due to scroller) if scroller is no more necessary for so few items (we need to force the display of the container)
                this.elements.container.addClassName(this.name + '-suggestsDisplayed');
                computedHeight = this.elements.suggests.offsetHeight;

                // If suggestions computed height is lower than default one, set it, else reset.
                if ((computedHeight > 0) && (computedHeight + 20 <= this.options.maxHeight)) {
                    this.elements.suggestsContainer.setStyle('height', (computedHeight + 20) + 'px');
                    this.elements.suggestsScroll.setStyle('height', (computedHeight + 20) + 'px');
                } else {
                    this.elements.suggestsScroll.setStyle('height', this.options.maxHeight + 'px');
                }

                this.elements.container.removeClassName(this.name + '-suggestsDisplayed');

                if (!preventShow && !silent) {
                    this.dispatchEvent('onShowSuggests');
                } else {
                    this.dispatchEvent('onHideSuggests');
                }
            },

            /**
             * Invoked when the autocomplete input field is being focused.
             */
            onFocus: function () {
                var elements = this.elements;

                if (elements.input.value === this.options.placeholder) {
                    elements.input.value = '';
                }

                this.elements.inputContainer.addClassName('autocomplete-searchbox-focus');

                if (this.options.showSuggestsOnFocus && !this.elements.input.value.length) {
                    // Show all on focus only if nothing in input
                    this.showAll();
                } else if (this.options.multiSelect && this.elements.input.value.length && this.currentSuggestions.length) {
                    // If something in input, simply re-show previous result
                    this.onShowSuggests();
                }
            },

            /**
             * Invoked when a key is released in the autocomplete input field.
             */
            onKeyUp: function (event) {
                var target = Event.getElement(event),
                    key = keyCodes[event.keyCode],
                    upArrow = (key === 'up-arrow'),
                    downArrow = (key === 'down-arrow'),
                    enter = (key === 'enter'),
                    escape = (key === 'escape'),
                    tab = (key === 'tab');

                if (!upArrow && !downArrow && !enter && !escape && !tab) {

                    if (target.value.length === 0) {
                        this.onHideSuggests();
                        this.options.showSuggestsOnFocus && this.showAll();
                        // On single mode, unselect item if one and remove filled class
                        if (!this.options.multiSelect) {
                            this.selectedItems[0] && this.onUnselect(this.selectedItems[0]);
                            this.elements.container.toggleClassName(this.CLS_FILLED, false);
                        }
                        return;
                    }

                    if (target.value.length > 0) {
                        !this.options.multiSelect && this.elements.container.toggleClassName(this.CLS_FILLED, true);
                    }

                    if (target.value.length >= this.options.minLengthBeforeSearch) {
                        clearTimeout(this.typeTimeout);
                        this.typeTimeout = setTimeout(function () {
                            this.getSuggestions(target.value);
                        }.bind(this), this.options.typeDelayBeforeSearch);
                    }
                }
            },

            /**
             * Invoked when a key is typed in the autocomplete input field.
             */
            onKeyDown: function () {
                this.used = true;
                // Update input size in multi select mode.
                if (this.options.multiSelect && this.elements.input && this.elements.input.value) {
                    this.elements.input.setStyle('width', Math.max(this.elements.input.value.length, this.elements.input.size) * 8 + 'px');
                }
            },

            /**
             * Invoked when the list of suggestions is being displayed.
             */
            onShowSuggests: function () {
                var container = this.elements.container;
                this._updateSuggestsPosition();
                container.addClassName(this.name + '-suggestsDisplayed');
                this.suggestsDisplayed = true;
                // Highlight first suggestion
                (this.keyboardIndex < 0) && this._updateKeyboardIndex('down');
            },

            /**
             * Invoked when the list of suggestions is being hidden.
             */
            onHideSuggests: function () {
                this.elements.container.removeClassName(this.name + '-suggestsDisplayed');
                this.suggestsDisplayed = false;
            },

            /**
             * Default onClickOutside handler.
             */
            onClickOutside: function () {
                if (this.elements.input.placeholder === '') {
                    this.elements.input.placeholder = this.options.placeholder;
                }
                this.elements.inputContainer.removeClassName('autocomplete-searchbox-focus');
                this.dispatchEvent('onHideSuggests');
            },

            /**
             * Reset input field.
             * @param {number} [position] - Optional innerInput position. Default to main input
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            resetInput: function (position) {
                var input;

                if (position >= 0) {
                    input = this.innerInputs[position];
                    input && input.setStyle('width', '5px');
                } else {
                    input = this.elements.input;
                    this.elements.input.placeholder = this.options.placeholder;
                }

                if (input) {
                    input.value = '';
                }

                !this.options.multiSelect && this.elements.container.toggleClassName(this.CLS_FILLED, false);
            },

            /**
             * Reset input and selection.
             * @param {Boolean} [silent=true] - False to dispatch onUnselect event
             */
            reset: function (silent) {
                this.resetInput();
                this.unselectAll(silent);
                this._updateBadgeFocus(-1);
            },

            /**
             * Reset data cache of every dataset.
             */
            resetCache: function () {
                this.datasets.forEach(function (dataset) {
                    dataset.dataCache = {};
                });
            },

            /**
             * Check if valid (no matter if empty or not)
             * @return {Boolean} - True if valid.
             */
            isValid: function () {
                // Always ok in free mode
                if (this.options.allowFreeInput) {
                    return true;
                } else {
                    // Single mode : check coherent state
                    if (!this.options.multiSelect) {
                        return (!this.selectedItems[0] || this.selectedItems[0] && this.selectedItems[0].value && this.elements.input.value === this.selectedItems[0].value);
                        // Multi mode : ok if no alone dirty input
                    } else {
                        return (!(this.elements.input.value !== '' && this.selectedItems.length === 0));
                    }
                }
            },

            /**
             * Check if is empty.
             * @return {Boolean} - True if is empty.
             */
            isEmpty: function () {
                if (!this.options.multiSelect) {
                    return (!this.elements.input.value || this.elements.input.value === '');
                } else {
                    return ((!this.selectedItems || this.selectedItems.length === 0) && (!this.elements.input.value || this.elements.input.value === ''));
                }
            },

            /**
             * Get selection as a String of selected items separated by the token separator.
             *
             * @return {String} - A String of selected items separated by the token separator
             */
            getValue: function () {
                var finalValue = '', that = this;

                this.selectedItems.forEach(function (item) {
                    if (item.value) {
                        finalValue = finalValue.concat(item.value + that.options.tokenSeparator);
                    }
                });
                // We do not want the last tokenSeparator produced by the loop.
                return finalValue.substring(0, finalValue.length - 1);
            },

            /**
             * Get selection as an array containing every useful items data.
             *
             * @return {Object} - Array of every selected items.
             */
            getSelection: function () {
                var singleModeItem,
                    allowFree = this.options.allowFreeInput,
                    input = this.elements.input.value,
                    multiItems = [];

                // Single value mode
                if (!this.options.multiSelect) {
                    singleModeItem = this.selectedItems[0];
                    // In single (non multi) select mode; if free input is not allowed, check if the input still match with the selected item
                    if (singleModeItem) {

                        // Match : return item
                        if (singleModeItem.value && singleModeItem.value === input) {
                            return singleModeItem;
                            // Do not match : return null if do not allow free input else input value if some
                        } else if (allowFree) {
                            return (input) ? (input) : ('');
                        } else {
                            return '';
                        }
                        // Free input allowed : return value; else null
                    } else if (allowFree) {
                        return (input) ? (input) : ('');
                    } else {
                        return '';
                    }
                    // Multi select mode
                } else {
                    multiItems = multiItems.concat(this.selectedItems);

                    if (allowFree) {
                        input && multiItems.push(input);
                    }

                    return (multiItems.length) ? (multiItems) : ('');
                }

            },

            /**
             * Get selected items from given dataset only.
             * @param  {String} datasetName - Dataset identifier.
             * @return {Object}             - Array of every selected item from given dataset.
             */
            getSelectionByDataset: function (datasetName) {
                var dataset = this.getDataset(datasetName),
                    itemsFromDataset = [];

                if (!dataset) { return; }
                itemsFromDataset = this.selectedItems.filter(function (item) { return (item.datasetId === dataset.id); });

                return (itemsFromDataset.length) ? (itemsFromDataset) : ('');

            },

            /**
             * Default data parser for remote dataset suggestions. Convert input into array.
             *
             * @param  {Object} data    - Input to convert in array (Json object or xml).
             * @return {Object}         - Input converted in array (if was possible).
             */
            defaultDataParser: function (data) {
                var prop, firstProp, found;

                if (Json.isJson(data)) {
                    data = Json.decode(data);
                    found = true;
                } else {
                    data = Json.xmlToJson(data);

                    // get first entry in json object, because in XML there is a root container
                    for (prop in data) {
                        if (data.hasOwnProperty(prop)) {
                            data = data[prop];
                            break;
                        }
                    }
                }

                // get first array in json object
                for (prop in data) {
                    if (data.hasOwnProperty(prop)) {
                        if (!firstProp) { firstProp = prop; }

                        if (Array.isArray(data[prop])) {
                            data = data[prop];
                            found = true;
                            break;
                        }
                    }
                }

                // fallback when xml has NO array, but only one item, try to get the first entry
                if (!found && firstProp) {
                    data = [data[firstProp]];
                }

                // If Object -> Push it to an array
                if (!Array.isArray(data)) {
                    var lonelyItem = [];
                    for (var key in data) {
                        if (data.hasOwnProperty(key)) {
                            lonelyItem[key] = data[key];
                        }
                    }
                    data = [];
                    data.push(lonelyItem);
                }

                return Array.isArray(data) ? data : [];
            },

            getCurrentPosition: function () {
                return this.currentPosition;
            },

            /**
             * Get badge instance for the current or given position
             *
             * @param {String} [side='left']                   - Side to retrieve badge from the current Position. 'left' or 'right'.
             * @param {number} [position=this.currentPosition] - Starting position.
             * @returns {Badge|null}                           - Instance of the badge if found, else null
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            getNeighbourBadge: function (side, position) {
                var index = -1,
                    startingPosition = (position >= 0) ? position : this.currentPosition,
                    direction = side || 'left';

                if (startingPosition >= 0) {
                    index = (direction === 'left') ? (startingPosition - 1) : (startingPosition + 1);
                } else {
                    index = (direction === 'left') ? (this.badges.length - 1) : -1;
                }

                return this.badges[index] || null;
            },

            /**
             * Get item data for the current position
             *
             * @param {String} [side='left']                   - Side to retrieve badge from the current Position. 'left' or 'right'.
             * @param {number} [position=this.currentPosition] - Starting position.
             * @returns {Object}                               - Data of the item if found, else null
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            getNeighbourSelectedItem: function (side, position) {
                var index = -1,
                    startingPosition = (position >= 0) ? position : this.currentPosition,
                    direction = side || 'left';

                if (startingPosition >= 0) {
                    index = (direction === 'left') ? (startingPosition - 1) : (startingPosition + 1);
                } else {
                    index = (direction === 'left') ? (this.badges.length - 1) : -1;
                }

                return this.selectedItems[index] || null;
            },

            /**
             * Focus on a given badge knowing its position in badges list
             *
             * @param {number}  position                      - Index in badges list
             * @param {Boolean} [preventBadgeSelection=false] - True to prevent focusing the targeted badge
             *
             * @private
             */
            _updateBadgeFocus: function (position, preventBadgeSelection) {
                this._toggleBadgeSelection(this.currentPosition, false);
                this.dispatchEvent('onUpdateInputPosition', [position]);
                !preventBadgeSelection && this._toggleBadgeSelection(position, true, preventBadgeSelection);
            },

            /**
             * Focus on a given inner input knowing its position in inner inputs list
             *
             * @param {number}  position       - Index in inner inputs list
             * @param {Boolean} [silent=false] - True to prevent dispatching onUpdatePosition event
             *
             * @private
             */
            _updateInnerInputFocus: function (position, silent) {
                var innerInput = this.innerInputs[position];
                if (innerInput) {
                    !silent && this.dispatchEvent('onUpdateInputPosition', [position]);
                    innerInput.focus();
                }
            },

            /**
             * Select or unselect a badge if exists
             *
             * @param {number}  position       - Index in badges list
             * @param {Boolean} [select=true]  - True to select the badge
             * @param {Boolean} [silent=false] - True to prevent dispatching event
             *
             * @private
             */
            _toggleBadgeSelection: function (position, select, silent) {

                var badge = this.badges[position];

                if (!badge) { return; }

                if (typeof select === 'undefined') { select = true; }

                if (select) {
                    // When crosses are hidden by default, show them when selecting a badge
                    !this.options.closableItems && badge.setClosable(true);
                    badge.select();
                    badge.elements.container.focus();
                    !silent && this.dispatchEvent('onSelectBadge', [this.selectedItems[position], badge, this.getBadgePosition(badge.elements.container)]);
                    this.currentBadge = badge;
                } else if (this.currentBadge) {
                    // When crosses are hidden by default, hide them when selecting a badge
                    !this.options.closableItems && badge.setClosable(false);
                    badge.select(false);
                    !silent && this.dispatchEvent('onUnselectBadge', [this.selectedItems[position], badge, this.getBadgePosition(badge.elements.container)]);
                    this.currentBadge = null;
                }
            },

            /**
             * Set the badge selection  position
             *
             * @param {number}  position - Index in badges list
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             */
            onUpdateInputPosition: function (position) {
                this.currentPosition = position;
            },

            /**
             * Change index of the selected suggestion through the keyboard.
             *
             * @param {String || number} index - 'reset', 'up', 'down' or the index directly. Will proceed an initialization if nothing is provided.
             *
             * @private
             */
            _updateKeyboardIndex: function (index) {
                var that = this, pos = this.keyboardIndex, savePos = this.keyboardIndex, shouldUpdate, previous, current,
                    // Method that returns next available item (skip if disabled)
                    getNextPosition = function (pos) {
                        var startPos = pos;

                        shouldUpdate = false;

                        if (pos === -1 && index !== 'reset') {
                            // If no position yet, initiate to first item
                            pos = 0;
                            shouldUpdate = true;
                        } else if (that.currentSuggestions && index === 'down' && pos < that.currentSuggestions.length - 1) {
                            // Go down when possible
                            pos = pos + 1;
                            shouldUpdate = true;
                        } else if (index === 'up' && pos > 0) {
                            // Go up when possible
                            pos = pos - 1;
                            shouldUpdate = true;
                        } else if (index === 'reset') {
                            // Unselect active item and reset index
                            that._hoverItem(pos, false);
                            pos = -1;
                        }

                        if (shouldUpdate) {
                            current = getItemBySuggestionsPosition(pos);
                            if (!current) {
                                // We have reached end of the suggestions list and item is not selectable, keep on previous
                                if (pos === that.currentSuggestions.length - 1) {
                                    current = previous;
                                    pos = startPos;
                                    // Else try to reach next one
                                } else {
                                    return getNextPosition(pos);
                                }
                            }
                        }

                        return pos;
                    },
                    // Return item at given position if enable, else false
                    getItemBySuggestionsPosition = function (position) {
                        var item = null;

                        if (that.currentSuggestions) {
                            item = that.currentSuggestions[position];
                        }

                        return (item && (item.disabled || !item.value)) ? (false) : (item);
                    },
                    // Update scroll to make selected item visible
                    // Returns 0 if no need to change scroll, 1 to go down, 2 to go up
                    getScrollInstructions = function (oldItem, newItem) {

                        var update = 0, containerHeight, offsetOld, offsetNew, oldRatio, newRatio, oldItemDOM, newItemDOM;

                        if (!oldItem || !newItem) {
                            return;
                        }

                        oldItemDOM = that.elements.suggestsContainer.getElement('#' + that.CLS_ITEM + '-' + oldItem.id);
                        newItemDOM = that.elements.suggestsContainer.getElement('#' + that.CLS_ITEM + '-' + newItem.id);

                        if (!oldItemDOM || !newItemDOM) {
                            return;
                        }

                        containerHeight = that.elements.suggestsContainer.getDimensions().height;

                        offsetOld = oldItemDOM.offsetTop;
                        offsetNew = newItemDOM.offsetTop;

                        oldRatio = Math.floor(offsetOld / containerHeight);
                        newRatio = Math.floor(offsetNew / containerHeight);

                        if (oldRatio + 1 === newRatio) {
                            update = 1;
                        } else if (oldRatio - 1 === newRatio) {
                            update = 2;
                        }

                        return update;
                    };

                previous = getItemBySuggestionsPosition(savePos);

                // Directly update index if provided (hover) or get to next position (from arrows navigation)
                if (typeof index === 'number') {
                    pos = index;
                    current = getItemBySuggestionsPosition(pos);
                    if (!current) { return; }
                    previous && this._hoverItem(previous, false);
                    this._hoverItem(current, true);
                } else {
                    pos = getNextPosition(pos);
                    if (shouldUpdate && pos >= 0) {
                        previous && this._hoverItem(previous, false);
                        current && this._hoverItem(current, true, (pos === 0) ? (3) : (getScrollInstructions(previous, current)));
                    }
                }

                this.keyboardIndex = pos;
            },

            /**
             * Fake an hover on a given suggestion or disable hover.
             * @param {Object} item           - Item to hover
             * @param {Boolean} [hover=true]  - True to hover, false to un-hover.
             * @param {number} [updateScroll] - 1 to go on element top, 2 to go on element bottom, 3 to go top
             * @private
             */
            _hoverItem: function (item, hover, updateScroll) {
                var itemDOM,
                    shouldHover;

                if (item) {
                    shouldHover = (hover === undefined) ? (true) : hover;
                    itemDOM = this.elements.suggestsContainer.getElement('#' + this.CLS_ITEM + '-' + item.id);

                    // Break early if item not in DOM
                    if (!itemDOM) { return; }

                    if (shouldHover) {
                        itemDOM.addClassName(this.CLS_HOVERED_ITEM);
                        itemDOM.focus();
                        if (updateScroll === 1) {
                            this.scroller.scrollToElement(itemDOM, 'top');
                        }
                        if (updateScroll === 2) {
                            this.scroller.scrollToElement(itemDOM, 'bottom');
                        }
                        if (updateScroll === 3) {
                            this.scroller.scrollTo(0, 0);
                        }
                    } else {
                        itemDOM.removeClassName(this.CLS_HOVERED_ITEM);
                    }
                }
            },

            /**
             * Provide the currently selected item in a keyboard navigation context.
             * @return {Object} - The keyboard-selected item
             * @private
             */
            _getActiveItem: function () {
                var index = this.keyboardIndex;

                if (index >= 0) {
                    return this.currentSuggestions[index];
                } else {
                    return false;
                }
            },

            /**
             * Shorthand for setDisabled(false)
             * @return {this} instance.
             */
            enable: function () {
                return this.setDisabled(false);
            },

            /**
             * Shorthand for setDisabled()
             * @return {this} instance.
             */
            disable: function () {
                return this.setDisabled();
            },

            /**
             * Get if this input is disabled.
             * @return {Boolean}
             */
            isDisabled: function () {
                return this.elements.input.disabled;
            },

            /**
             * Enable/disable the autocomplete.
             *
             * @param  {Boolean} [disabled=true]       - Disable on `true`, enable on `false`.
             * @return {this} instance
             */
            setDisabled: function (disabled) {
                var elements = this.elements;

                if (typeof disabled === 'undefined') {
                    disabled = true;
                }

                elements.input.disabled = disabled;
                elements.inputContainer.toggleClassName('disabled', disabled);
                this.handleEvents();

                return this;
            },

            /**
             * Try to cast the current input as a selection.
             *
             * @param  {number} [position] - To add or remove at the given position of the already selected items (starting from 0). Multi select mode only.
             * @returns {Object}           - Matching item is some, else null
             * @memberof module:DS/UIKIT/Autocomplete.Autocomplete#
             * @private
             */
            _selectCurrentInput: function (position) {
                var input = position >= 0 ? this.innerInputs[position].value : this.elements.input.value,
                    item,
                    forceSelection = this.options.itemMultiSelect === true ? true : null;

                if (!input) { return; }

                // If input match an existing item, pick it
                item = this.getItemByLabel(input);

                // Else get the only possible match
                if (!item && this.suggestsDisplayed && this.currentSuggestions && this.currentSuggestions.length === 1) {
                    item = this.currentSuggestions[0];
                }

                // Else if no matching item and in free input mode; create an item from this input
                if (!item && this.options.allowFreeInput) {
                    item = {};
                    item.id = Utils.getUUID().substr(0, 6);
                    item.value = item.label = input;
                }

                // Else do not do anything more
                if (!item) { return; }

                return this.toggleSelect(item, position, forceSelection);
            },

            /**
             * Badge deletion actions when delete comes from click or keyboard.
             * @private
             */
            _handleBadgeDeletion: function (deletionPosition, newPosition) {
                var badge = this.badges[deletionPosition];
                if (newPosition === this.selectedItems.length) { newPosition = -1; }
                if (badge && badge.isDisabled()) { return; }
                this.dispatchEvent('onUnselect', [this.selectedItems[deletionPosition], deletionPosition, newPosition]);
                if (newPosition === -1) {
                    this.elements.input.focus();
                }
            },

            /**
             * Main method for handling events.
             */
            handleEvents: function () {
                var forceSelection = this.options.itemMultiSelect === true ? true : null;

                if (!this.events) {
                    this.events = {};
                    this.events.input = {

                        focus: function (event) {
                            var target = Event.getElement(event),
                                onInnerInput = /inner-input/.test(target.className);
                            if (onInnerInput) {
                                // update position to badge on the right of the current inner input
                                this._updateBadgeFocus(this.getBadgePosition(target.nextSibling), true);
                            } else {
                                this._updateBadgeFocus(-1);
                            }
                            // Do not refocus on item deletion
                            if (!/fonticon-cancel/.test(target.className)) {
                                this.dispatchEvent('onFocus', [event]);
                            }
                        }.bind(this),

                        blur: function (event) {
                            this.dispatchEvent('onBlur', [event]);
                        }.bind(this),

                        keyup: function (event) {
                            this.dispatchEvent('onKeyUp', [event]);
                        }.bind(this),

                        keydown: function (event) {
                            var key = keyCodes[event.keyCode],
                                target = Event.getElement(event),
                                onInnerInput = /inner-input/.test(target.className),
                                innerInput = this.innerInputs[this.currentPosition],
                                onNotEmptyInnerInput = onInnerInput && innerInput && innerInput.value.length,
                                onMainInput = /autocomplete-input/.test(target.className),
                                onNotEmptyMainInput = onMainInput && this.elements.input.value.length,
                                upArrow = (key === 'up-arrow'),
                                downArrow = (key === 'down-arrow'),
                                enter = (key === 'enter'),
                                tab = (key === 'tab'),
                                escape = (key === 'escape');

                            this.dispatchEvent('onKeyDown', [event]);

                            // Up : go up in suggestions list
                            if (upArrow) {
                                this._updateKeyboardIndex('up');
                                Event.preventDefault(event);
                            }

                            // Down : go down in suggestions list
                            if (downArrow) {
                                this._updateKeyboardIndex('down');
                                Event.preventDefault(event);
                            }

                            // Enter or tab : choose item or go to next input. Keep tab native behavior unless user was typing something that matches something.
                            if (enter || tab) {
                                var activeItem = this._getActiveItem(),
                                    item = null;
                                // Stop event propagation (that could be used for a form submit later for instance) if user aim is to select something
                                // Case 1: user is navigating with keyboard on the suggestion list
                                if (enter && activeItem && this.suggestsDisplayed) {
                                    Event.preventDefault(event);
                                    // Item multi selection : force to add at given position
                                    // Single item selection : simple toggle
                                    item = this.toggleSelect(activeItem, this.currentPosition, forceSelection);
                                    // Case 2: user wants to select something on multiSelect mode
                                } else if (this.options.multiSelect && (onNotEmptyInnerInput || onNotEmptyMainInput)) {
                                    item = this._selectCurrentInput(this.currentPosition);
                                    (enter || item) && Event.preventDefault(event);
                                }

                                // If on an inner input, go to next inner inputs on enter; go to main input on a tab
                                if (onInnerInput && item) {
                                    if (enter) {
                                        (this.innerInputs[this.currentPosition + 1] || this.elements.input).focus();
                                    } else {
                                        this.elements.input.focus();
                                    }
                                }
                            }

                            // Tab or escape : close suggestions list
                            if (tab || escape) {
                                this.dispatchEvent('onHideSuggests');
                            }
                        }.bind(this)
                    };

                    // This event is necessary for languages which use IME (input method editors) in ff
                    // see https://www.w3.org/TR/uievents/#keys-IME
                    if (Client.Engine.firefox) {
                        this.events.input.compositionupdate = function (event) {
                            this.dispatchEvent('onKeyUp', [event]);
                        }.bind(this);
                    }

                    this.events.inputContainer = {
                        click: function (event) {
                            var target = Event.getElement(event),
                                onBadge = /badge/.test(target.className) && !(/disabled/.test(target.className) || /disabled/.test(target.parentElement.className)),
                                onBadgeCross = /badge-close/.test(target.className) && !/disabled/.test(target.parentElement.className),
                                onInnerInput = /inner-input/.test(target.className),
                                targetIsCloseIcon = /fonticon-cancel/.test(target.className),
                                onResetCross = /autocomplete-reset/.test(target.className);

                            if (!onBadge && !onInnerInput && !targetIsCloseIcon) {
                                this.elements.input.focus();
                            }
                            if (onBadge && !onBadgeCross) {
                                if (target.hasClassName('badge-content')) {
                                    target = target.getParent();
                                }
                                this._updateBadgeFocus(this.getBadgePosition(target));
                            }
                            if (onResetCross && this.options.multiSelect === false) {
                                this.reset(false);
                            }
                        }.bind(this),

                        keydown: function (event) {
                            var key = keyCodes[event.keyCode],
                                newPosition,
                                newInnerInputPosition,
                                target = Event.getElement(event),
                                onBadge = /badge/.test(target.className),
                                onDisabledBadge = onBadge && /disabled/.test(target.className),
                                onInnerInput = /inner-input/.test(target.className),
                                innerInput = this.innerInputs[this.currentPosition],
                                onNotEmptyInnerInput = onInnerInput && innerInput && innerInput.value.length,
                                onEmptyInnerInput = innerInput && innerInput.value === '',
                                onMainInput = /autocomplete-input/.test(target.className),
                                onNotEmptyMainInput = onMainInput && this.elements.input.value.length,
                                leftArrow = (key === 'left-arrow'),
                                rightArrow = (key === 'right-arrow'),
                                backspace = (key === 'backspace'),
                                del = (key === 'del'),
                                tab = (key === 'tab');

                            // Left arrow: go to previous badge / input if appropriate
                            if (leftArrow) {
                                newPosition = -1;
                                newInnerInputPosition = -1;

                                if (!this.options.multiSelect || !this.selectedItems.length || onNotEmptyInnerInput || onNotEmptyMainInput) { return; }

                                if (this.currentPosition != null && this.currentPosition >= 0) {
                                    if (onBadge) {
                                        // Leaving badge for inner input on the left : keep same position but focus this input
                                        newInnerInputPosition = this.currentPosition;
                                    } else if (onEmptyInnerInput) {
                                        // Leaving inner input for badge on the left : decrement position and focus on this badge
                                        newPosition = this.currentPosition - 1;
                                    }
                                } else if (this.elements.input.value === '') {
                                    // Leaving main input
                                    newPosition = this.selectedItems.length - 1;
                                }

                                if (newPosition >= 0) {
                                    this._updateBadgeFocus(newPosition);
                                } else if (newInnerInputPosition >= 0) {
                                    this._updateInnerInputFocus(newInnerInputPosition);
                                }
                            }

                            // Right arrow: go to next badge / input if appropriate
                            if (rightArrow) {
                                newPosition = -1;
                                newInnerInputPosition = -1;

                                if (!this.options.multiSelect || !this.selectedItems.length || onNotEmptyInnerInput || onNotEmptyMainInput) { return; }

                                // If on inner input, going on right don't change actual position, else let's increment it.
                                if (this.currentPosition != null && this.currentPosition >= 0) {
                                    if (onBadge) {
                                        // Leaving badge for inner input on the right : increment position and focus on this input
                                        newInnerInputPosition = this.currentPosition + 1;
                                    } else if (onEmptyInnerInput) {
                                        // Leaving empty inner input for badge input on the right : keep same position but focus this badge
                                        newPosition = this.currentPosition;
                                    }
                                }

                                if (newPosition >= 0 && newPosition < this.selectedItems.length) {
                                    this._updateBadgeFocus(newPosition);
                                } else if (newInnerInputPosition >= 0 && newInnerInputPosition < this.selectedItems.length) {
                                    this._toggleBadgeSelection(this.currentPosition, false);
                                    this._updateInnerInputFocus(newInnerInputPosition);
                                } else if (newPosition === this.selectedItems.length || newInnerInputPosition === this.selectedItems.length) {
                                    // Focus on input and reset position if going back to main input
                                    this._updateBadgeFocus(-1);
                                    this.elements.input.focus();
                                    this.onShowSuggests();
                                }
                            }

                            if (backspace || del) {
                                var deletionPosition, item, incomingText, incomingItem;

                                if (!this.options.multiSelect && !this.options.allowFreeInput) {
                                    // In single select mode, and no free input + item does not match anymore, unselect it
                                    item = this.getItem(target.value);
                                    incomingText = target.value.substring(0, target.value.length - 1);
                                    incomingItem = this.getItem(incomingText);
                                    if (item && !incomingItem) {
                                        this.onUnselect(this.selectedItems[0], null, null, false);
                                    }
                                } else {
                                    if (!this.selectedItems.length || onNotEmptyInnerInput || onNotEmptyMainInput || onDisabledBadge) { return; }

                                    // Backspace on main input: remove last badge
                                    if (backspace && this.currentPosition < 0 && onMainInput && this.elements.input.value === '') {
                                        deletionPosition = this.selectedItems.length - 1;
                                        newPosition = -1;
                                    } else if (this.currentPosition >= 0) {
                                        // Backspace on a badge or inner input: go to previous or back to input if no previous,
                                        if (backspace) {
                                            deletionPosition = onInnerInput ? this.currentPosition - 1 : this.currentPosition;
                                            newPosition = onInnerInput ? this.currentPosition - 2 : this.currentPosition - 1;
                                        } else {
                                            // Delete on a badge: go to next or main input if no next
                                            deletionPosition = this.currentPosition;
                                            newPosition = (deletionPosition === this.badges.length - 1) ? -1 : deletionPosition;
                                        }
                                    }

                                    deletionPosition >= 0 && this._handleBadgeDeletion(deletionPosition, newPosition);
                                    Event.preventDefault(event);
                                }

                            }

                            // Tab on a badge : focus main input
                            if (tab && onBadge) {
                                this.elements.input.focus();
                                Event.preventDefault(event);
                            }

                        }.bind(this)
                    };

                    this.events.suggestsContainer = {
                        mouseover: function (event) {
                            var target = Event.getElement(event),
                                suggestion = this.getSuggestion(target),
                                itemId, i,
                                position = -1,
                                itemLabelDom,
                                itemLabel;

                            if (!suggestion || !suggestion.id) { return; }

                            // Display content as title if cropped by viewport
                            itemLabelDom = suggestion.getElement('.item-label');
                            if (itemLabelDom) {
                                if (itemLabelDom.offsetWidth < itemLabelDom.scrollWidth) {
                                    itemLabel = itemLabelDom.textContent;
                                    itemLabel && itemLabelDom.setAttribute('title', itemLabel);
                                } else {
                                    itemLabelDom.setAttribute('title', '');
                                }
                            }

                            itemId =  suggestion.id.replace('autocomplete-item-', '');

                            // Get the item position in suggestions list
                            for (i = 0; i < this.currentSuggestions.length; i++) {
                                if (this.currentSuggestions[i].id === itemId) {
                                    position = i;
                                    break;
                                }
                            }

                            position > -1 && this._updateKeyboardIndex(position);

                        }.bind(this),
                        click: function (event) {
                            var target = Event.getElement(event),
                                suggestion = this.getSuggestion(target),
                                item;

                            // Break early if not on an item element
                            if (!suggestion) { return; }

                            // Check if clickable (for parent item, acceptable if has the clickable class)
                            if (!suggestion.hasClassName(this.CLS_PARENT_ITEM) || (suggestion.hasClassName(this.CLS_PARENT_ITEM) && suggestion.hasClassName('clickable'))) {
                                // Check if suggestion matches an existing item
                                item = this.getItemFromSuggestion(suggestion);

                                // Break early if no item found or if is disabled
                                if (!item || item.disabled) { return; }

                                this.toggleSelect(item, this.currentPosition, forceSelection);

                                if (this.options.multiSelect) {
                                    // If on an inner input, go to next inner input, else focus main input
                                    if (this.currentPosition > -1) {
                                        (this.innerInputs[this.currentPosition + 1] || this.elements.input).focus();
                                    } else {
                                        this.elements.input.focus();
                                    }
                                }
                            }
                        }.bind(this)
                    };

                    // The click dismiss event
                    this.events.document = {
                        click: function (event) {
                            if (!Event.getElement(event).isInjected(this.elements.container) && event.target !== this.elements.container.suggestsContainer) {
                                this.dispatchEvent('onClickOutside', [event]);
                                this._updateBadgeFocus(-1);
                            }
                        }.bind(this)
                    };
                }

                if (this.isDisabled()) {
                    removeEvent('click', document, this.events.document.click);
                    this.elements.inputContainer.removeEvents(this.events.inputContainer);
                    this.elements.input.removeEvents(this.events.input);
                    this.elements.suggestsContainer.removeEvents(this.events.suggestsContainer);
                } else {
                    if (this.hasEvent('onClickOutside')) {
                        addEvent('click', document, this.events.document.click, true);
                    }
                    this.elements.inputContainer.addEvents(this.events.inputContainer);
                    this.elements.input.addEvents(this.events.input);
                    this.elements.suggestsContainer.addEvents(this.events.suggestsContainer);
                }
            },

            /**
             * Destroy the Autocomplete.
             * Control and its children should not be used after this.
             */
            destroy: function () {
                delete this.datasets;
                delete this.selectedItems;
                delete this.badges;
                delete this.innerInputs;
                delete this.currentSuggestions;

                this.scroller.destroy();

                removeEvent('click', document, this.events.document.click);
                
                this._parent();
            },            
        };

        return Abstract.extend(Autocomplete);
    });

/**
 * An API to help you play with the tedious forms.
 * @module DS/UIKIT/Form
 * @requires DS/UIKIT/Input/Text
 * @requires DS/UIKIT/Input/Button
 * @requires DS/UIKIT/Input/ButtonGroup
 * @requires DS/UIKIT/Input/Number
 * @requires DS/UIKIT/Input/Select
 * @requires DS/UIKIT/Input/Date
 * @requires DS/UIKIT/Input/Toggle
 * @requires DS/UIKIT/Autocomplete
 * @requires DS/UIKIT/Input/File
 * @extends UWA/Control/Abstract
 */
define('DS/UIKIT/Form',
    [
        'UWA/Core',
        'UWA/Data',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Input/Text',
        'DS/UIKIT/Input/Password',
        'DS/UIKIT/Input/Button',
        'DS/UIKIT/Input/ButtonGroup',
        'DS/UIKIT/Input/Number',
        'DS/UIKIT/Input/Select',
        'DS/UIKIT/Input/Date',
        'DS/UIKIT/Input/Toggle',
        'DS/UIKIT/Autocomplete',
        'DS/UIKIT/Input/File'
    ],

    function (UWA, Data, Element, Event, Utils, Abstract, Text, Password, Button, ButtonGroup, NumberInput, Select, Date, Toggle, Autocomplete, File) {

        'use strict';

        function fireChange (element) {
            if ('createEvent' in document) {
                var evt = document.createEvent('HTMLEvents');
                evt.initEvent('change', false, true);
                element.dispatchEvent(evt);
            } else {
                element.fireEvent('onchange');
            }
        }

        function parseClassName (klasses) {
            var i, l, match;
            if (!klasses) { return; }
            klasses = klasses.split(' ');

            for (i = 0, l = klasses.length; i < l; i++) {
                match = klasses[i].match(/horizontal|inline|vertical$/);
                if (match && !match[1]) {
                    if (match[0] === 'horizontal') {
                        klasses[i] = 'form-horizontal';
                    } else if (match[0] === 'inline') {
                        klasses[i] = 'form-inline';
                    } else if (match[0] === 'vertical') {
                        klasses[i] = 'form-vertical';
                    }
                }
            }
            return klasses.join(' ');
        }

        var patterns = {
            alpha: /^[a-zA-Z]+$/,
            alpha_numeric: /^[a-zA-Z0-9]+$/,
            integer: /^[-+]?\d+$/,
            number: /^[-+]?\d*(?:[\.\,]\d+)?$/,

            // amex, visa, diners
            card: /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/,
            cvv: /^([0-9]){3,4}$/,

            // http://www.whatwg.org/specs/web-apps/current-work/multipage/states-of-the-type-attribute.html#valid-e-mail-address
            email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,

            url: /^(https?|ftp|file|ssh):\/\/(((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/,
            // abc.de
            domain: /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$/,

            datetime: /^([0-2][0-9]{3})\-([0-1][0-9])\-([0-3][0-9])T([0-5][0-9])\:([0-5][0-9])\:([0-5][0-9])(Z|([\-\+]([0-1][0-9])\:00))$/,
            // YYYY-MM-DD
            date: /(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))$/,
            // HH:MM:SS
            time: /^(0[0-9]|1[0-9]|2[0-3])(:[0-5][0-9]){2}$/,
            dateISO: /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/,
            // MM/DD/YYYY
            month_day_year: /^(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.]\d{4}$/,

            // #FFF or #FFFFFF
            color: /^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/
        };

        /**
         * @lends module:DS/UIKIT/Form.module:DS/UIKIT/Form.Form
         */
        var Form = {

            /**
             * Component name used by `Abstract.getClassNames`.
             * Component classname.
             * Component variations classname prefix.
             * @type {String}
             * @readonly
             * @default
             * @constant
             * @memberof module:DS/UIKIT/Form.Form#
             */
            name: 'form',

            /**
             * Every text inputs instances used by the Form.
             * @type {Text[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            texts: null,

            /**
             * Every toggle input instances used by the Form.
             * @type {Toggle[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            booleans: null,

            /**
             * Every select input instances used by the Form.
             * @type {Select[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            lists: null,

            /**
             * Every date input instances used by the Form.
             * @type {Date[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            dates: null,

            /**
             * Every password input instances used by the Form.
             * @type {Password[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            passwords: null,

            /**
             * Every file input instances used by the Form.
             * @type {File[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            files: null,

            /**
             * Every file input instances used by the Form.
             * Currently implemented as Number inputs.
             * @type {Number[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            ranges: null,

            /**
             * Every button input instances used by the Form.
             * @type {Button[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            buttons: null,

            /**
             * Every autocomplete input instances used by the Form.
             * @type {Autocomplete[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            autocompletes: null,

            /**
             * Every number input instances used by the Form.
             * @type {Number[]}
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            numbers: null,

            /**
             * @property {Object} defaultOptions - The default form options.
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            defaultOptions: {
                className: 'form-vertical',
                fields: [],
                buttons: [],
                labelSuffix: '',
                grid: '2 10',
                autocomplete: false,
                method: 'POST',
                encoding: 'application/x-www-form-urlencoded'
            },

            /**
             * An API to help you play with the tedious forms.
             *
             * @example
             * require(['DS/UIKIT/Form'], function (Form) {
             *     new Form({
             *         className: 'horizontal',
             *         fields: [{
             *             url: 'toto.php',
             *             type: 'text',
             *             value: 'standard value',
             *             name: 'my_text',
             *             label: 'My text label',
             *             placeholder: 'Enter a text...',
             *             required: true,
             *             pattern: '[a-zA-Z]'
             *         }]
             *     }).inject(body);
             * });
             *
             * @param {Object} options                          - The available options.
             *
             * @param {String}   [options.className='vertical'] - An optional class name. Can be: `horizontal`, `vertical`, `inline`.
             * @param {Element}  [options.renderTo]             - If specified will inject the Form at a specific place, else will have to be injected manually.
             * @param {String}   [options.labelSuffix]          - An optional label suffix string.
             * @param {String}   [options.novalidate=false]     - Whether to disable validation for this form.
             * @param {Boolean}  [options.autocomplete=false]   - Whether this form should be autocompleted by the browser.
             * @param {String}   [options.grid='2 10']          - In case you are using a `className='vertical'`, specify the grid options (must add to 12).
             * @param {Object[]} [options.fields]               - An array of form fields (see the field builder).
             * @param {String}   [options.fields.helperText]    - An additional text to display under the field.
             * @param {String}   [options.fields.errorText]     - An additional text to display under the field when its value is not valid.
             * @param {Object[]} [options.buttons]              - A configuration option for your form buttons. It is similar to a UIKIT.Input.Button configuration.
             *                                                    The only difference is that you pass an action function for handling the click and not an events object.
             *                                                    Check UIKIT.Input.Button for more configurations.
             *
             * @param {String}     [options.buttons.value]      - The button value.
             * @param {String}     [options.buttons.type]       - The button type: `submit`, `value` or none.
             * @param {Function}   [options.buttons.action]     - The function to add on this button click if any.
             *
             * @param {String}   [options.url]                  - The url to submit this form. Will use an invisible iframe.
             * @param {String}   [options.method='POST']        - The method to use for sending this form.
             * @param {String}   [options.encoding='application/x-www-form-urlencoded'] - The form enctype.
             * @param {Object}   [options.events]               - The available events.
             *
             * @param {Function}   [options.events.onChange]    - Invoked when an input inside the form changes.
             * @param {Function}   [options.events.onSubmit]    - Invoked when the form is submitted.
             * @param {Function}   [options.events.onValid]     - Invoked when the form passes the validation.
             * @param {Function}   [options.events.onInvalid]   - Invoked when the form fails the validation.
             *
             * @constructs Form
             * @memberof module:DS/UIKIT/Form
             */
            init: function (options) {
                options = options || {};

                this.texts = [];
                this.booleans = [];
                this.lists = [];
                this.dates = [];
                this.passwords = [];
                this.files = [];
                this.ranges = [];
                this.buttons = [];
                this.autocompletes = [];
                this.numbers = [];

                if (options.className) {
                    options.className = parseClassName(options.className);
                }

                this.id = Utils.getUUID().substring(0, 6);
                this._parent(options);
                this.buildSkeleton();
            },

            /**
             * Build the form HTML skeleton.
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            buildSkeleton: function () {

                var that = this,
                    fields = this.options.fields,
                    buttons = this.options.buttons,
                    fieldBuilders = this.fields,
                    fieldElements = [],
                    actions, form,
                    // we need to inject radio helpers when last radio has been injected
                    radioHelpers = [],
                    injectHelpers = function (field, helpersBase, where) {
                        var helper;
                        if (field.helperText && helpersBase) {
                            helper = UWA.createElement('span', {
                                text: field.helperText,
                                'class': 'form-control-helper-text'
                            }).inject(helpersBase, where || 'after');
                        }
                        // insert error text when needed : should be before the helper text for CSS matching
                        if (field.errorText && helpersBase) {
                            UWA.createElement('span', {
                                text: field.errorText,
                                'class': 'form-control-error-text'
                            }).inject(where === 'bottom' ? helper : helpersBase, where === 'bottom' ? 'before' : 'after');
                        }
                    };

                form = UWA.createElement('form', {
                    attributes: {
                        novalidate: 'novalidate',
                        autocomplete: this.options.autocomplete ? 'on' : 'off'
                    },
                    'class': this.getClassNames(),
                    events: {
                        submit: function (event) {
                            Event.stop(event);
                            that.submit.call(that, false);
                        },

                        reset: function (event) {
                            Event.stop(event);
                            that.reset.call(that);
                        }
                    }
                });

                // Loop over fields and create elements
                fields.forEach(function (field) {
                    var parent,
                        fieldContainer,
                        helpersBase;

                    if (field.type !== 'hidden') {
                        // Default to text field
                        if (fieldBuilders[field.type] === undefined) {
                            field.type = 'text';
                        }

                        // Find the previous radio if exists with same name for coherence.
                        if (field.type === 'radio' && field.name) {
                            fieldElements.some(function (f) {
                                var input = f && f.getElement('input');
                                if (input && input.type === 'radio' && input.name === field.name) {
                                    parent = f;
                                    return true;
                                }
                            });
                        }

                        fieldContainer = fieldBuilders[field.type](field, that, parent);

                        if (!parent && fieldContainer) {
                            // Add symbol on required fields
                            if (field.label && field.required) {
                                UWA.createElement('span', {
                                    'class': 'label-field-required',
                                    text: ' *'
                                }).inject(fieldContainer.getElement('label'));
                            }
                            // insert helper & error texts when needed
                            if (field.type === 'file') {
                                helpersBase = fieldContainer.getElement('.input-file');
                            } else if (field.type === 'autocomplete') {
                                helpersBase = fieldContainer.getElement('.autocomplete');
                            } else if (field.type === 'radio') {
                                radioHelpers.push({ field: field, helpersBase: fieldContainer.firstChild });
                            } else if (field.type === 'number') {
                                helpersBase = fieldContainer.getElement('.input-number');
                            } else {
                                helpersBase = fieldContainer && fieldContainer.getElement('.form-control') ;
                            }

                            helpersBase && injectHelpers(field, helpersBase);
                        }

                        // Apply small style to label if input has small style
                        if (field.label && field.className && field.className.contains('input-sm')) {
                            fieldContainer.getElement('label').addClassName('label-sm');
                        }

                        // Add Field element container to fieldset
                        fieldElements.push(fieldContainer);
                    }
                });

                // Inject helper and error text for injected radio lists
                radioHelpers.forEach(function (data) {
                    injectHelpers(data.field, data.helpersBase, 'bottom');
                });

                // Sort buttons then loop over buttons and create footer actions
                buttons.sort(function (a, b) {
                    if ((a.type === 'submit' && b.type !== 'submit') || (a.type === 'reset' && !b.type))
                        return -1;
                    if ((a.type !== 'submit' && b.type === 'submit') || (b.type === 'reset' && !a.type))
                        return 1;
                    return 0;
                }).forEach(function (button, i) {

                    if (!/submit|reset/.test(button.type)) {
                        button.type = 'button';
                    }

                    if (!i) {
                        actions = fieldBuilders[button.type](button, that);
                    } else {
                        fieldBuilders[button.type](button, that, actions);
                    }
                });

                actions && actions.addClassName('form-footer');
                fieldElements.push(actions);

                // Append elements
                form.addContent(fieldElements);

                // Set form has control container
                this.elements.container = form;
            },

            /**
             * Returns all inputs. Does not return buttons nor submit/reset.
             * @returns {Element[]} The input elements.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getFields: function (all) {

                var container = this.elements.container,
                    query = 'textarea, input, select';

                if (all) { query += ', button'; }

                return container.getElements(query);
            },

            /**
             * Returns an input with the specified name. Does not return buttons nor submit/reset.
             * Will only return the first radio with the provided name (in case of many radios).
             * @param {String} name - The field name.
             * @returns {Element|null}   - The element if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getField: function (name) {

                var i, l, element,
                    elements = this.getFields();

                for (i = 0, l = elements.length; i < l; i++) {
                    element = elements[i];
                    if (element.name === name || element.id === name) {
                        return element;
                    }
                }
            },

            /**
             * Returns the input instance having the specified name among the given elements.
             * @param {String} name - The input name.
             * @returns {Object}    - The input if any, else null.
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            _getInput: function (name, elements) {

                var i, l, element;

                for (i = 0, l = elements.length; i < l; i++) {
                    element = elements[i];
                    if (element.getName() === name) {
                        return element;
                    }
                }
            },

            /**
             * Returns the list input instance having the specified name.
             * @param {String} name - The list name.
             * @returns {Object}    - The list if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getListInput: function (name) {
                return this._getInput(name, this.lists);
            },

            /**
             * Returns the text input instance having the specified name.
             * @param {String} name   - The text name.
             * @returns {Object|null} - The text if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getTextInput: function (name) {
                return this._getInput(name, this.texts);
            },

            /**
             * Returns the boolean input instance having the specified name.
             * @param {String} name  - The boolean name.
             * @returns {Object|null}- The boolean if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getBooleanInput: function (name) {
                return this._getInput(name, this.booleans);
            },

            /**
             * Returns the date input instance having the specified name.
             * @param {String} name   - The date name.
             * @returns {Object|null} - The date if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getDateInput: function (name) {
                return this._getInput(name, this.dates);
            },

            /**
             * Returns the password input instance having the specified name.
             * @param {String} name   - The password name.
             * @returns {Object|null} - The password if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getPasswordInput: function (name) {
                return this._getInput(name, this.passwords);
            },

            /**
             * Returns the file input instance having the specified name.
             * @param {String} name  - The file name.
             * @returns {Object|null} - The file if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getFileInput: function (name) {
                return this._getInput(name, this.files);
            },

            /**
             * Returns the range input instance having the specified name.
             * @param {String} name   - The range name.
             * @returns {Object|null} - The range if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getRangeInput: function (name) {
                return this._getInput(name, this.ranges);
            },

            /**
             * Returns the number input instance having the specified name.
             * @param {String} name  - The number name.
             * @returns {Object|null} - The range if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getNumberInput: function (name) {
                return this._getInput(name, this.numbers);
            },

            /**
             * Returns the button input instance having the specified name.
             * @param {String} name   - The button name.
             * @returns {Object|null} - The button if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getButtonInput: function (name) {
                return this._getInput(name, this.buttons);
            },

            /**
             * Returns the autocomplete input instance having the specified name.
             * @param {String} name   - The autocomplete name.
             * @returns {Object|null} - The autocomplete if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getAutocompleteInput: function (name) {
                return this._getInput(name, this.autocompletes);
            },

            /**
             * Returns the input instance having the specified name.
             * @param {String} name   - The input name.
             * @returns {Object|null} - The input if any, else null.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getInput: function (name) {
                return this._getInput(name, this.getAllInputInstances());
            },

            /**
             * Removes all the error message from the form.
             * @returns {Form} - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            unvalidate: function () {
                this.getContent().getElements('.has-error').forEach(function (element) {
                    element.removeClassName('has-error');
                });

                return this;
            },

            /**
             * Try to validate the form. Will show up UI errors when possible.
             * @param  {Boolean} [hideErrors=true]    - If `true`, will hide the UI messages for wrong inputs.
             * @param  {Boolean} [preventFocus=false] - If `true`, will prevent the focus on the first invalid input.
             * @returns {Boolean}                     - `true` if the form validates.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            validate: function (hideErrors, preventFocus) {

                var errorFields = [],
                    fields = this.getFields(),
                    pattern,
                    fieldFromItem,
                    that = this;

                // Always clear old error messages
                this.unvalidate();

                fields.forEach(function (field) {

                    switch (field.type) {
                        case 'button':
                        case 'submit':
                            // Skip submit && button
                            break;

                        case 'radio':
                            var radios, allUnchecked;

                            if (field.required && !field.disabled) {
                                radios = fields.filter(function (f) { if (f.name === field.name) return true; });
                                // Only do this if it was not added to the error field by a previous radio
                                if (errorFields.every(function (f) { return radios.indexOf(f) === -1; })) {
                                    allUnchecked = radios.every(function (f) { return !f.checked; });

                                    if (allUnchecked) {
                                        errorFields.push(field);
                                    }
                                }
                            }
                            break;

                        case 'checkbox':
                            if (field.required && field.checked === false && !field.disabled) {
                                errorFields.push(field);
                            }
                            break;

                        case 'text':
                        case 'textarea':
                        case 'email':
                        case 'url':
                        case 'tel':

                            // Break early if text but autocomplete
                            if (field.name && that.getAutocompleteInput(field.name)) { break; }

                            pattern = field.pattern || field.getAttribute('pattern');
                            pattern = pattern ? pattern : /text(area)?/.test(field.type) ? false : field.type;

                            if (field.required && field.value === '' && !field.disabled) {
                                errorFields.push(field);
                            } else if (pattern && !field.disabled) {
                                if (pattern === 'tel') pattern = 'alpha_numeric';
                                if (patterns.hasOwnProperty(pattern) && pattern.length > 0) {
                                    pattern = patterns[pattern];
                                } else if (pattern.length > 0) {
                                    pattern = new RegExp(pattern);
                                }

                                if (UWA.is(pattern, 'regexp') && field.value.length > 0 && !pattern.test(field.value)) {
                                    errorFields.push(field);
                                }
                            }
                            break;

                        default:
                            if (field.required && field.value === '' && !field.disabled) {
                                errorFields.push(field);
                            }
                            break;
                    }
                });

                // Autocomplete fields validation
                this.autocompletes.forEach(function (item) {

                    fieldFromItem = that.getField(item.getId());

                    if (fieldFromItem.required && !fieldFromItem.disabled) {
                        if (item.isEmpty() || !item.isValid()) {
                            errorFields.push(fieldFromItem);
                        }
                    } else if (!item.isValid()) {
                        errorFields.push(fieldFromItem);
                    }

                });

                if (hideErrors !== true && errorFields.length > 0) {
                    errorFields.forEach(function (field) {
                        field.getParent('.form-group').addClassName('has-error');
                    });

                    // Focus the first error field
                    !preventFocus && errorFields[0].focus();
                }

                // Dispatch event of success/failure
                this.dispatchEvent(errorFields.length === 0 ? 'onValid' : 'onInvalid');

                return errorFields.length === 0;
            },

            /**
             * Calling this method will submit the form if and only if it passes form validation.
             * @param {Boolean} [force=false] - If true, will disable form validation (if options.novalidate is true) for this submit only.
             * @returns {Form}                - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            submit: function (force) {

                var options = this.options,
                    iframe;

                if (options.novalidate || (!options.novalidate && this.validate()) || force) {

                    this.dispatchEvent('onSubmit', this.getValues());

                    if (options.url) {

                        // Update the form attributes
                        this.getContent().setAttributes({
                            method: options.method,
                            action: options.url,
                            target: 'form_transfer_' + this.id,
                            enctype: options.encoding
                        });

                        // Create the invisible iframe for posting content
                        iframe = UWA.createElement('iframe', {
                            name: 'form_transfer_' + this.id,
                            src: 'javascript:false;',
                            attributes: {
                                tabindex: -1,
                                frameborder: 0
                            },
                            styles: {
                                visibility: 'hidden',
                                width: 0,
                                height: 0,
                                border: 0
                            }
                        }).inject(document.body);

                        // Remove it once it did the job
                        iframe.onload = function () {
                            iframe.parentNode.removeChild(iframe);
                        };

                        // <glorious-hook> Manually set a value for autocomplete inputs in multi select mode...
                        this.autocompletes.forEach(function (autocomplete) {
                            if (autocomplete.options && autocomplete.options.multiSelect === true) {
                                autocomplete.elements.input.value = autocomplete.getValue();
                            }
                        });

                        // Actually submit the form
                        this.getContent().submit();

                        // ...And blank it back </glorious-hook>
                        this.autocompletes.forEach(function (autocomplete) {
                            if (autocomplete.options && autocomplete.options.multiSelect === true) {
                                autocomplete.elements.input.value = '';
                            }
                        });
                    }
                }

                return this;
            },

            /**
             * Get all the input instances of the form.
             * @returns {Object[]} - All the instances.
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getAllInputInstances: function () {
                return [].concat(
                    this.texts,
                    this.booleans,
                    this.lists,
                    this.dates,
                    this.passwords,
                    this.files,
                    this.ranges,
                    this.buttons,
                    this.autocompletes
                );
            },

            /**
             * Set the form as disabled.
             * @param {Boolean} [disabled=true] - If false, enable the input.
             * @returns {Form}                  - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            setDisabled: function (disabled) {

                if (typeof disabled === 'undefined') {
                    disabled = true;
                }

                this.getAllInputInstances().forEach(function (input) {
                    input.setDisabled(disabled);
                });

                return this;
            },

            /**
             * Shorthand for [setDisabled(false)]{@link module:DS/UIKIT/Form.module:DS/UIKIT/Form.FormsetDisabled}.
             * @returns {Form} - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            enable: function () {
                return this.setDisabled(false);
            },

            /**
             * Shorthand for [setDisabled()]{@link module:DS/UIKIT/Form.module:DS/UIKIT/Form.FormsetDisabled}.
             * @returns {Form} - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            disable: function () {
                return this.setDisabled();
            },

            /**
             * Calling this method will reset the form.
             * @returns {Form} - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            reset: function () {
                var values = this.getValues();

                Object.keys(values).forEach(function (key) {
                    values[key] = '';
                });

                this.autocompletes.forEach(function (item) {
                    item.reset();
                });

                this.setValues(values);
                this.dispatchEvent('onReset');
                return this;
            },

            /**
             * Get current form fields values using key/value pairs of an object.
             * Will return true or false for a checkbox value.
             * Will return the value of the radio checked.
             * Will return the value for all the other fields.
             * @returns {Object} Value hash or a name/value pair.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getValues: function () {

                var i, l, element,
                    values = {},
                    proto = Array.prototype,
                    elements = this.getFields();

                for (i = 0, l = elements.length; i < l; i++) {

                    element = elements[i];

                    switch (element.type) {
                        case 'button':
                        case 'submit':
                            // Skip submit && button
                            break;

                        case 'password':
                            // Do not save empty password
                            if (element.value !== '') {
                                values[element.name] = element.value;
                            }
                            break;

                        case 'checkbox':
                            values[element.name] = (!!element.checked);

                            // Keep string value like string
                            if (typeof element.value === 'string') {
                                values[element.name] = String(values[element.name]);
                            }
                            break;

                        case 'radio':
                            if (element.checked) {
                                values[element.name] = element.value;
                            }
                            break;

                        case 'select-multiple':

                            // Return all values merged by a `,`
                            values[element.name] = proto.filter.call(element.getElementsByTagName('*'), function (option) {
                                if (option.selected && option.getTagName() !== 'optgroup' && option.value) return true;
                            }).reduce(function (values, value) {
                                return (values ? values + ',' : values) + value.value;
                            }, '') || '';
                            break;

                        default:
                            if (UWA.is(element.name) && element.name.length) {
                                values[element.name] = element.value;
                            }
                            break;
                    }
                }

                this.autocompletes.forEach(function (item) {
                    if (UWA.is(item.elements.input.name) && item.elements.input.name.length) {
                        values[item.elements.input.name] = item.getValue();
                    }
                });

                this.files.forEach(function (item) {
                    if (UWA.is(item.elements.input.name) && item.elements.input.name.length) {
                        values[item.elements.input.name] = item.getValue();
                    }
                });

                return values;
            },

            /**
             * Get the value for a specific form by providing his name.
             * @param {String} name - The field name.
             * @returns {Object}
             * @memberof module:DS/UIKIT/Form.Form#
             */
            getValue: function (name) {
                return this.getValues()[name];
            },

            /**
             * Set current form fields values using key/value pairs of an object.
             * @param {Object} values - Value hash or a name/value pair.
             * @returns {Form}        - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            setValues: function (values) {

                var i, l, element, value,
                    elements = this.getFields();

                for (i = 0, l = elements.length; i < l; i++) {

                    element = elements[i];

                    if (values.hasOwnProperty(element.name)) {
                        value = values[element.name];

                        switch (element.type) {
                            case 'password':
                            case 'button':
                            case 'reset':
                            case 'submit':
                                // Skip submit/reset && button && password
                                break;

                            case 'checkbox':
                                element.checked = (!!value);
                                fireChange(element);
                                break;

                            case 'radio':
                                if (element.checked && String(element.value) === value) {
                                    element.checked = (!!value);
                                    fireChange(element);
                                }
                                break;

                            default:
                                element.value = value;
                                fireChange(element);
                                break;
                        }
                    }
                }

                return this;
            },

            /**
             * Set the value par specified field.
             * @param {String} name  - The field name.
             * @param {String} value - The field new value.
             * @returns {Form}       - The instance.
             * @memberof module:DS/UIKIT/Form.Form#
             */
            setValue: function (name, value) {

                var values = {};
                values[name] = value;

                return this.setValues(values);
            },

            /**
             * Create the field wrapper for the different for dispositions.
             * @private
             * @memberof module:DS/UIKIT/Form.Form#
             */
            createField: function (input, label, hidden, parent) {

                var fieldWrapper, gridSize;

                if (this.options.className.indexOf('form-horizontal') > -1 && this.options.grid) {
                    gridSize = this.options.grid.split(' ');
                    if (!gridSize || gridSize.length < 2) {
                        gridSize = [2, 10];
                    }

                    if (parent) {
                        input.inject(parent.getChildren()[0]);
                    } else if (label) {
                        label.addClassName('col-sm-' + gridSize[0] + ' control-label');
                        fieldWrapper = UWA.createElement('div', {
                            'class': 'form-group',
                            html: [
                                label,
                                {
                                    tag: 'div',
                                    'class': 'col-sm-' + gridSize[1],
                                    html: input
                                }]
                        });
                    } else {
                        fieldWrapper = UWA.createElement('div', {
                            'class': 'form-group',
                            html: {
                                tag: 'div',
                                'class': 'col-sm-offset-' + gridSize[0] + ' col-sm-' + gridSize[1],
                                html: input
                            }
                        });
                    }
                } else if (this.options.className.indexOf('form-inline') > -1) {
                    if (parent) {
                        input.inject(parent);
                    } else if (!label) {
                        fieldWrapper = UWA.createElement('div', {
                            'class': 'form-group',
                            html: input
                        });
                    } else {
                        label.addClassName('sr-only');
                        fieldWrapper = UWA.createElement('div', {
                            'class': 'form-group',
                            html: [label, input]
                        });
                    }
                } else if (parent) {
                    input.inject(parent);
                } else if (!label) {
                    fieldWrapper = UWA.createElement('div', {
                        'class': 'form-group',
                        html: input
                    });
                } else {
                    fieldWrapper = UWA.createElement('div', {
                        'class': 'form-group',
                        html: [label, input]
                    });
                }

                if (hidden) {
                    fieldWrapper.hide();
                }

                return fieldWrapper;
            },

            setClassName: function (klass) {
                this.options.className = parseClassName(klass);
                this.getContent().className = this.getClassNames();
                return this;
            },

            fields: {

                /**
                 * Text field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Text options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.text
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                text: function (options, form) {

                    var input, label,
                        that = form,
                        defaultOptions = {
                            attributes: {
                                autocomplete: 'off',
                                autocorrect: 'off',
                                autocapitalize: 'off'
                            },
                            id: 'input-' + Utils.getUUID().substring(0, 6)
                        };

                    input = new Text(UWA.extend(options, defaultOptions, true));

                    form.texts.push(input);

                    // When the input text changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n(options.label + that.options.labelSuffix)
                        });
                    }

                    return that.createField.call(that, input, label);
                },

                /**
                 * Text area field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Text options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.textarea
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                textarea: function (options, form) {
                    return this.text(UWA.merge(options, { multiline: true }), form);
                },

                /**
                 * Password field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Text options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.password
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                password: function (options, form) {

                    var input, label,
                        that = form,
                        defaultOptions = {
                            attributes: {
                                autocomplete: 'off',
                                autocorrect: 'off',
                                autocapitalize: 'off'
                            },
                            id: 'input-' + Utils.getUUID().substring(0, 6)
                        };

                    input = new Password(UWA.extend(options, defaultOptions, true));

                    form.passwords.push(input);

                    // When the password changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label) || UWA.is(options.name)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n((options.label || options.name) + that.options.labelSuffix)
                        });
                    }

                    return that.createField.call(that, input, label);
                },

                /**
                 * File field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/File options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.files
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                file: function (options, form) {

                    var input, label,
                        that = form,
                        fieldWrapper,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6)
                        };

                    input = new File(UWA.extend(options, defaultOptions, true));

                    form.files.push(input);

                    // When the file changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label) || UWA.is(options.name)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n((options.label || options.name) + that.options.labelSuffix)
                        });
                    }
                    fieldWrapper = that.createField.call(that, input, label);

                    input.elements.textfield.onfocus = function () {
                        fieldWrapper.toggleClassName('focused', true);
                    };

                    input.elements.textfield.onblur = function () {
                        fieldWrapper.toggleClassName('focused', false);
                    };

                    return fieldWrapper;
                },

                /**
                 * Autocomplete field builder.
                 * @param  {Object}  options - DS/UIKIT/Autocomplete options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.autocomplete
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                autocomplete: function (options, form) {

                    var input, label,
                        that = form,
                        fieldWrapper,
                        defaultOptions = {
                            attributes: {
                                autocomplete: 'off',
                                autocorrect: 'off',
                                autocapitalize: 'off'
                            },
                            id: 'input-' + Utils.getUUID().substring(0, 6)
                        };

                    input = new Autocomplete(UWA.extend(options, defaultOptions, true));
                    input.setId(Utils.getUUID().substr(0, 6));

                    form.autocompletes.push(input);

                    // When the input changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label) || UWA.is(options.name)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n((options.label || options.name) + that.options.labelSuffix)
                        });
                    }

                    fieldWrapper = that.createField.call(that, input, label);

                    input.addEvent('onFocus', function () {
                        fieldWrapper.toggleClassName('focused', true);
                    });

                    input.addEvent('onBlur', function () {
                        fieldWrapper.toggleClassName('focused', false);
                    });

                    return fieldWrapper;
                },

                /**
                 * List field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Select options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.list
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                list: function (options, form) {

                    var input, label,
                        that = form,
                        hide = false,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6),
                            placeholder: false,
                            multiple: false,
                            nativeSelect: false
                        };

                    input = new Select(UWA.merge(options, defaultOptions));

                    form.lists.push(input);

                    // When the list changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue()[0], options.onchange]);
                    });

                    if (UWA.is(options.label) || UWA.is(options.name)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n((options.label || options.name) + that.options.labelSuffix)
                        });
                    }

                    if (input.getOptions().length === 0) {
                        hide = true;
                    }

                    return that.createField.call(that, input, label, hide);
                },

                /**
                 * Select field builder (alias of list).
                 * @param  {Object}  options - DS/UIKIT/Input/Select options.
                 * @param  {Object}  form    - The form instance.
                 * @return {Element} An element containing the input.
                 *
                 * @alias fields.select
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                select: function (options, form) {
                    return this.list(options, form);
                },

                /**
                 * Range field builder (using number input for now).
                 * @param  {Object}  options - DS/UIKIT/Input/Number options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.range
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                range: function (options, form) {
                    var input, label,
                        that = form,
                        hide = false,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6),
                            placeholder: false
                        };

                    input = new NumberInput(UWA.merge(options, defaultOptions));

                    form.ranges.push(input);

                    // When the input range changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n((options.label || options.name) + that.options.labelSuffix)
                        });
                    }

                    return that.createField.call(that, input, label, hide);
                },

                /**
                 * Number field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Number options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.number
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                number: function (options, form) {

                    var input, label,
                        that = form,
                        fieldWrapper,
                        hide = false,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6),
                            placeholder: false
                        };

                    input = new NumberInput(UWA.merge(options, defaultOptions));

                    form.numbers.push(input);

                    // When the input range changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n((options.label || options.name) + that.options.labelSuffix)
                        });
                    }

                    fieldWrapper = that.createField.call(that, input, label, hide);

                    input.elements.input.onfocus = function () {
                        fieldWrapper.toggleClassName('focused', true);
                    };

                    input.elements.input.onblur = function () {
                        fieldWrapper.toggleClassName('focused', false);
                    };

                    return fieldWrapper;
                },

                /**
                 * Boolean field builder (will be a checkbox, use radio field builder if you want a radio).
                 * @param  {Object}  options - DS/UIKIT/Input/Toggle options.
                 * @param  {Object}  form    - The form instance.
                 * @param  {Element} parent  - The previous radio instance element if exists.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.boolean
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                'boolean': function (options, form, parent) {

                    var input,
                        that = form,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6),
                            type: 'checkbox',
                            className: 'primary'
                        };

                    // If we have no checked options try to use the value (legacy NV)
                    if (!UWA.is(options.checked) && UWA.is(options.value)) {
                        options.checked = options.value === 'true' || options.value === true;
                    }

                    input = new Toggle(UWA.merge(options, defaultOptions));

                    form.booleans.push(input);

                    // When the radio changes, fire a onChange for the form.
                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.isChecked(), options.onchange]);
                    });

                    return that.createField.call(that, input, false, false, parent);
                },

                /**
                 * Radio field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Toggle options.
                 * @param  {Object}  form    - The form instance.
                 * @param  {Element} parent  - The previous radio instance element if exists.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.radio
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                radio: function (options, form, parent) {
                    return this['boolean'](UWA.extend(options, { type: 'radio' }), form, parent);
                },

                /**
                 * Checkbox field builder (alias of boolean).
                 * @param  {Object}  options - DS/UIKIT/Input/Toggle options.
                 * @param  {Object}  form    - The form instance.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.checkbox
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                checkbox: function (options, form) {
                    return this['boolean'](UWA.extend(options, { type: 'checkbox' }), form);
                },

                /**
                 * Submit field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Button options.
                 * @param  {Object}  form    - The form instance.
                 * @param  {Element} parent  - A parent to append to.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.submit
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                submit: function (options, form, parent) {

                    var input,
                        that = form,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6),
                            value: 'Submit',
                            className: 'primary',
                            attributes: { type: 'submit' }
                        };

                    // Replace onClick by action if it exists
                    if (options.action) {
                        options.events = options.events || {};
                        options.events.onClick = options.action;
                    }

                    input = new Button(UWA.merge(options, defaultOptions));
                    form.buttons.push(input);
                    return that.createField.call(that, input, false, false, parent);
                },

                /**
                 * Reset field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Button options.
                 * @param  {Object}  form    - The form instance.
                 * @param  {Element} parent  - A parent to append to.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.reset
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                reset: function (options, form, parent) {

                    var input,
                        that = form,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6),
                            value: 'Reset',
                            attributes: { type: 'reset' }
                        };

                    // Replace onClick by action if it exists
                    if (options.action) {
                        options.events = options.events || {};
                        options.events.onClick = options.action;
                    }

                    input = new Button(UWA.merge(options, defaultOptions));
                    form.buttons.push(input);
                    return that.createField.call(that, input, false, false, parent);
                },

                /**
                 * Button field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Button options.
                 * @param  {Object}  form    - The form instance.
                 * @param  {Element} parent  - A parent to append to.
                 * @returns {Element}        - An element containing the input.
                 * @alias fields.button
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                button: function (options, form, parent) {

                    var input,
                        that = form,
                        defaultOptions = {
                            id: 'input-' + Utils.getUUID().substring(0, 6)
                        };

                    // Replace onClick by action if it exists
                    if (options.action) {
                        options.events = options.events || {};
                        options.events.onClick = options.action;
                    }

                    input = new Button(UWA.merge(options, defaultOptions));

                    form.buttons.push(input);

                    return that.createField.call(that, input, false, false, parent);
                },

                /**
                 * Create a new Element div with html.
                 * @param  {Object}  options - The html as options.html.
                 * @returns {Element}        - An element containing the HTML.
                 * @alias fields.html
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                html: function (options) {
                    return UWA.createElement('div', {
                        'class': 'form-group',
                        html: options.html
                    });
                },

                /**
                 * Create a new Element span with help text.
                 * @param  {Object}  options - The text as options.text.
                 * @returns {Element}        - An element containing the HTML.
                 * @alias fields.help
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                help: function (options) {
                    return UWA.createElement('span', {
                        'class': 'help-block',
                        text: options.text
                    });
                },

                /**
                 * Date field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Date options.
                 * @returns {Element}        - An element containing the HTML.
                 * @alias fields.date
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                date: function (options, form) {

                    var input, label,
                        that = form,
                        defaultOptions = {
                            attributes: {
                                autocomplete: 'off',
                                autocorrect: 'off',
                                autocapitalize: 'off'
                            },
                            id: 'input-' + Utils.getUUID().substring(0, 6)
                        };

                    input = new Date(UWA.extend(options, defaultOptions, true));

                    form.dates.push(input);

                    // When the input text changes, fire a onChange for the form.

                    input.addEvent('onChange', function () {
                        that.dispatchEvent('onChange', [this.getName(), this.getValue(), options.onchange]);
                    });

                    if (UWA.is(options.label)) {
                        label = UWA.createElement('label', {
                            'for': input.getId(),
                            text: UWA.i18n(options.label + that.options.labelSuffix)
                        });
                    }

                    return that.createField.call(that, input, label);
                },

                /**
                 * Email field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Text options.
                 * @returns {Element}        - An element containing the HTML.
                 * @alias fields.email
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                email: function (options, form) {
                    return this.text(UWA.merge(options, { attributes: { type: 'email' } }), form);
                },

                /**
                 * Telephone field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Text options.
                 * @returns {Element}        - An element containing the HTML.
                 * @alias fields.tel
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                tel: function (options, form) {
                    return this.text(UWA.merge(options, { attributes: { type: 'tel' } }), form);
                },

                /**
                 * Url field builder.
                 * @param  {Object}  options - DS/UIKIT/Input/Text options.
                 * @returns {Element}        - An element containing the HTML.
                 * @alias fields.url
                 * @memberof module:DS/UIKIT/Form.Form#
                 */
                url: function (options, form) {
                    return this.text(UWA.merge(options, { attributes: { type: 'url' } }), form);
                }
            }
        };

        return Abstract.extend(Form);
    });

/**
 * Displays a modal with more options than the simple one.
 * @module DS/UIKIT/SuperModal
 * @requires DS/UIKIT/Modal
 * @requires DS/UIKIT/Input/Button
 * @requires DS/UIKIT/Input/Text
 * @requires DS/UIKIT/Form
 * @extends UWA/Controls/Abstract
 */
define('DS/UIKIT/SuperModal',
    [
        'UWA/Core',
        'UWA/Element',
        'UWA/Event',
        'UWA/Utils/Client',
        'UWA/Controls/Abstract',
        'DS/UIKIT/Modal',
        'DS/UIKIT/Input/Button',
        'DS/UIKIT/Input/Text',
        'DS/UIKIT/Form',
        'i18n!DS/UIKIT/assets/nls/UIKIT'
    ],


    function (UWA, Element, Event, Client, Abstract, Modal, Button, Text, Form, i18n) {

        'use strict';

        /**
         * @lends module:DS/UIKIT/SuperModal.SuperModal#
         */
        var SuperModal = {

            /**
             * @property {Object} defaultOptions - The default controls options.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             * @private
             */
            defaultOptions: {
                className: '',
                animate: false,
                closable: true,
                overlay: true,
                okButtonText: i18n.ok,
                koButtonText: i18n.ko
            },

            /**
             * @property {Object} modals - The modals queue and current modal.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             * @private
             */
            modals: {
                current: null,
                queue: []
            },

            /**
             * Display a modal with more options thant the simple one.
             * Also manage focus state.
             *
             * @example
             * require(['DS/UIKIT/SuperModal', 'DS/UIKIT/Input/Button'], function (SuperModal, Btn) {
             *     var myAlertButton   = new Btn({ value: "Alert" }).inject(body);
             *     var myConfirmButton = new Btn({ value: "Confirm" }).inject(body);
             *     var myPromptButton  = new Btn({ value: "Prompt" }).inject(body);
             *     var mySuperModal = new SuperModal({
             *         closable: true,
             *         renderTo: document.body
             *     });
             *     myAlertButton.addEvent("onClick", function () {
             *         mySuperModal.alert("Lorem...", function () {
             *             console.log("A sample alert message callback");
             *         });
             *     });
             *     myConfirmButton.addEvent("onClick", function () {
             *         mySuperModal.confirm("Lorem...", "Are you sure ?", function (result) {
             *             console.log("Confirm result: " + result);
             *         });
             *     });
             *     myPromptButton.addEvent("onClick", function () {
             *         mySuperModal.prompt("Don't lie, I will come and find you if you do.", "How old are you ?", function (result) {
             *             if (result === null) {
             *                 console.log("Prompt dismissed");
             *               } else {
             *                 console.log("You are " + result + " years old");
             *             }
             *         });
             *     });
             *     myPromptButton.addEvent("onClick", function () {
             *         mySuperModal.dialog({
             *             body: "<p>Quite a fancy body.</p>",
             *             title: "How old are you ?",
             *             buttons: [
             *                 { value: "foo", action: function (modal) { modal.hide(); }},
             *                 { value: "bar", action: function (modal) { modal.hide(); }}
             *             ]
             *         });
             *     });
             * });
             *
             * @param {Object} options                            - The available options.
             *
             * @param {String}   [options.className]              - An optional class name.
             * @param {Boolean}  [options.animate=false]          - Should the modals be animated.
             * @param {Boolean}  [options.closable=true]          - Should the modals have a cross at top right.
             * @param {Boolean}  [options.overlay=true]           - Should the modals display an overlay behind itself.
             * @param {Element}  [options.renderTo=document.body] - Where to render the modals created by this SuperModal.
             * @param {String}   [options.placeholder]             - An optional placeholder for your confirm modals.
             * @param {String}   [options.okButtonText='Ok']      - The 'Ok' button text in case you dislike the message for your modals.
             * @param {String}   [options.koButtonText='Cancel']  - The 'Cancel' button text in case you dislike the message for your modals.
             * @param {Function} [options.callback]               - An optional callback to be called when your modals gets hidden.
             * @param {Object}   [options.events]                 - The available events.
             *
             * @param {Function} [options.events.onShow]          - Invoked when a modal is shown.
             * @param {Function} [options.events.onHide]          - Invoked when a modal is hidden.
             *
             * @constructs SuperModal
             * @memberof module:DS/UIKIT/SuperModal
             */
            init: function (options) {
                this._parent(options);
            },

            /**
             * Attempts to display an alert modal else push it onto the queue.
             * @param {String|Object} message   - The message to display inside this modal.
             *                                    If it is an object like than it's properties name should match the optional properties below.
             * @param {String}   [title]        - The title to display. Can be omitted.
             * @param {Function} [callback]     - An optional callback to be called when modal gets hidden, override the default one if provided.
             * @param {String}   [okButtonText] - The 'Ok' button text in case you dislike the message, override the default one if provided.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             */
            alert: function () {

                var args = arguments,
                    msg = args[0],
                    title = args[1],
                    callback = args[2],
                    okText = args[3],
                    modal, button,
                    options = UWA.merge({ visible: false }, this.options);

                if (UWA.is(args[0], 'object')) {
                    msg = args[0].message;
                    title = args[0].title;
                    callback = args[0].callback;
                    okText = args[0].okButtonText;
                }

                options.closable = this.options.closable !== false;

                // Add events for alert modal
                options.events = {
                    onHide: function () {
                        if (UWA.is(callback, 'function')) {
                            callback();
                        }
                    },
                    onShow: function () {
                        button.focus();
                    }
                };

                // Create modal
                modal = this.modalFactory(options);

                // If it is a string try to add as string
                if (UWA.is(msg, 'string')) {
                    modal.elements.body.addContent({ tag: 'p', text: msg });
                }

                if (UWA.is(title, 'string')) {
                    modal.setHeader({ tag: 'h4', text: title });
                } else {
                    modal.getHeader().hide();
                    if (!callback) {
                        callback = title;
                    }
                }

                if (!UWA.is(callback, 'function') && this.options.callback) {
                    callback = this.options.callback;
                }

                // Create the Ok button
                button = new Button({
                    value: okText || options.okButtonText,
                    className: 'primary',
                    events: {
                        onClick: function () { modal.hide(); }
                    }
                });

                modal.setFooter(button);
                modal.dispatchEvent('onShowModal');
            },

            /**
             * Attempts to display a confirm modal else push it onto the queue.
             * @param {String|Object} message   - The message to display inside this modal.
             *                                    If it is an object like than it's properties name should match the optional properties below.
             * @param {String}   [title]        - The title to display. Can be omitted.
             * @param {Function} [callback]     - An optional callback to be called when modal gets hidden, override the default one if provided.
             * @param {String}   [okButtonText] - The 'Ok' button text in case you dislike the message, override the default one if provided.
             * @param {String}   [koButtonText] - The 'Cancel' button text in case you dislike the message, override the default one if provided.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             */
            confirm: function () {

                var args = arguments,
                    msg = args[0],
                    title = args[1],
                    callback = args[2],
                    okText = args[3],
                    koText = args[4],
                    modal, buttons = [],
                    options = UWA.merge({ visible: false }, this.options);

                function handleChoice (value) {
                    return function () {
                        modal.preventEvent = true;
                        modal.hide();
                        if (UWA.is(callback, 'function')) {
                            callback(value);
                        }
                    };
                }

                if (UWA.is(args[0], 'object')) {
                    msg = args[0].message;
                    title = args[0].title;
                    callback = args[0].callback;
                    okText = args[0].okButtonText;
                    koText = args[0].koButtonText;
                }

                options.closable = this.options.closable !== false;

                // Add events for confirm modal
                options.events = {
                    onHide: function () {
                        if (!modal.preventEvent && UWA.is(callback, 'function')) {
                            callback();
                        }
                    },
                    onShow: function () {
                        buttons[0].focus();
                    }
                };

                // Create modal
                modal = this.modalFactory(options);

                // If it is a string try to add as string
                if (UWA.is(msg, 'string')) {
                    modal.elements.body.addContent({ tag: 'p', text: msg });
                }

                if (UWA.is(title, 'string')) {
                    modal.setHeader({ tag: 'h4', text: title });
                } else {
                    modal.getHeader().hide();
                    if (!callback) {
                        callback = title;
                    }
                }

                if (!UWA.is(callback, 'function') && this.options.callback) {
                    callback = this.options.callback;
                }

                // Create the buttons
                buttons.push(new Button({ value: okText || options.okButtonText, className: 'primary' }));
                buttons[0].addEvent('onClick', handleChoice(true));
                buttons.push(new Button({ value: koText || options.koButtonText }));
                buttons[1].addEvent('onClick', handleChoice(false));

                modal.setFooter(buttons);
                modal.dispatchEvent('onShowModal');
            },

            /**
             * Attempts to display a prompt modal else push it onto the queue.
             * @param {String|Object} message     - The message to display inside this modal.
             *                                      If it is an object like then its properties name should match the optional properties below.
             * @param {String}   [title]          - The title to display. Can be omitted.
             * @param {Function} [callback]       - An optional callback to be called when modal gets hidden, override the default one if provided.
             * @param {String}   [okButtonText]   - The 'Ok' button text in case you dislike the message, override the default one if provided.
             * @param {String}   [koButtonText]   - The 'Cancel' button text in case you dislike the message, override the default one if provided.
             * @param {String}   [placeholder]    - An optional placeholder, override the default one if provided.
             * @param {Boolean}  [required=false] - Set the input text as required.
             * @param {String}   [value]          - Set the input text value.
             * @param {number}   [maxlength]      - Set the maximum length of the input.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             */
            prompt: function () {

                var args = arguments,
                    msg = args[0],
                    title = args[1],
                    callback = args[2],
                    okText = args[3],
                    koText = args[4],
                    placeholder = args[5],
                    required = args[6],
                    value = args[7],
                    maxlength = Math.max(0, args[8]) || false,
                    modal, buttons = [],
                    options = UWA.merge({ visible: false }, this.options),
                    form;

                function handleChoice (value) {
                    return function () {
                        if (value) {
                            value = modal.getContent().getElement('input').value;
                        }
                        modal.preventEvent = true;
                        modal.hide();
                        if (UWA.is(callback, 'function')) {
                            callback(value);
                        }
                    };
                }

                options.closable = this.options.closable !== false;

                if (UWA.is(args[0], 'object')) {
                    msg = args[0].message;
                    title = args[0].title;
                    callback = args[0].callback;
                    okText = args[0].okButtonText;
                    koText = args[0].koButtonText;
                    placeholder = args[0].placeholder;
                    required = args[0].required;
                    value = args[0].value;
                    maxlength = Math.max(0, args[0].maxlength) || false;
                }

                // Add events for prompt modal
                options.events = {
                    onHide: function () {
                        if (!modal.preventEvent && UWA.is(callback, 'function')) {
                            callback();
                        }
                    },
                    onShow: function () {
                        form.getField('input-confirm').focus();
                    }
                };

                // Create modal
                modal = this.modalFactory(options);

                form = new Form({
                    fields: [{
                        type: 'text',
                        required: required === true,
                        value: value || '',
                        placeholder: placeholder || options.placeholder || i18n.response,
                        name: 'input-confirm',
                        maxlength: maxlength
                    }],
                    events: { onSubmit: handleChoice(true) }
                });

                // If it is a string try to add as string
                if (UWA.is(msg, 'string')) {
                    modal.elements.body.addContent({ tag: 'p', text: msg }, form);
                } else {
                    modal.elements.body.addContent(msg, form);
                }

                if (UWA.is(title, 'string')) {
                    modal.setHeader({ tag: 'h4', text: title });
                } else {
                    modal.getHeader().hide();
                    if (!callback) {
                        callback = title;
                    }
                }

                if (!UWA.is(callback, 'function') && this.options.callback) {
                    callback = this.options.callback;
                }

                // Create the buttons
                buttons.push(new Button({ value: okText || options.okButtonText, className: 'primary' }));
                buttons[0].addEvent('onClick', function () { form.submit(); });
                buttons.push(new Button({ value: koText || options.koButtonText }));
                buttons[1].addEvent('onClick', handleChoice(false));

                modal.setFooter(buttons);
                modal.dispatchEvent('onShowModal');
            },

            /**
             * Attempts to display a dialog modal else push it onto the queue.
             * @param {Object} options - The available options.
             *
             * @param {String|Element|Object} options.body - The dialog body.
             * @param {String} [options.title]             - The dialog title.
             * @param {Array} [options.buttons]            - A configuration option for your modal buttons. It is similar to a UIKIT.Input.Button configuration.
             *                                               The only difference is that you pass an action function for handling the modal and not an events object.
             *                                               Check UIKIT.Input.Button for more configurations.
             *
             * @param {Function} [options.buttons.action]  - The method that will be called when the button is clicked. Will be passed the modal object as parameter.
             * @param {Function} [options.buttons.value]   - The button value.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             */
            dialog: function (options) {

                var opts = UWA.merge({ visible: false }, this.options),
                    modal,
                    buttons;

                opts.closable = this.options.closable !== false;

                // Prevent events to be added twice
                opts.events = {
                    onHide: function () {},
                    onShow: function () {}
                };

                modal = this.modalFactory(opts);

                function handleButtonClick (action) {
                    return function () {
                        if (UWA.is(action, 'function')) {
                            action(modal);
                        }
                    };
                }

                if (UWA.is(options.title, 'string')) {
                    modal.setHeader({ tag: 'h4', text: options.title });
                } else {
                    modal.getHeader().hide();
                }

                if (options.body) {
                    modal.elements.body.addContent(options.body);
                }

                // Create the buttons and find the primary
                if (options.buttons && options.buttons.length > 0) {
                    buttons = options.buttons.map(function (button) {
                        return new Button(UWA.extend(button, {
                            events: {
                                onClick: handleButtonClick(button.action)
                            }
                        }));
                    });

                    // Put all primaries to left
                    buttons = buttons.sort(function (a, b) {
                        function check (o) { return o.getContent().hasClassName('btn-primary'); }
                        if (check(a) && !check(b))
                            return -1;
                        if (!check(a) && check(b))
                            return 1;
                        return 0;
                    });

                    // Focus the first button on left
                    modal.addEvent('onShow', function () { buttons[0].focus(); });
                    modal.setFooter(buttons);
                } else {
                    // Clear the focus if no buttons (avoid multiple modals when pressing enter and focus is on button launching the modal)
                    // or put the focus on cross if available
                    if (opts.closable) {
                        modal.addEvent('onShow', function () {
                            modal.elements.close.focus();
                        });
                    } else {
                        modal.addEvent('onShow', function () {
                            modal.elements.content.setAttribute('tabindex', '0');
                            modal.elements.content.focus();
                        });
                    }
                }

                modal.dispatchEvent('onShowModal');
            },

            /**
             * Hide the current modal and try to show the next in queue if any.
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             */
            next: function () {
                if (this.modals.current) {
                    this.modals.current.hide();
                }
            },

            /**
             * A helper for creating modals and handling callbacks.
             * @param {Object} options - The available options.
             * @private
             * @memberof module:DS/UIKIT/SuperModal.SuperModal#
             */
            modalFactory: function (options) {

                var modal,
                    that = this;

                modal = new Modal(options);

                modal.addEvents({
                    onShowModal: function () {
                        if (!that.modals.current) {
                            that.modals.current = this;
                            that.lastFocus = document.activeElement;
                            this.show();
                        } else {
                            that.modals.queue.push(this);
                        }
                    },
                    onShow: function () {
                        that.dispatchEvent('onShow');
                    },
                    onHide: function () {
                        var queue = that.modals.queue,
                            next;

                        // Dispatch onHide before showing next modal.
                        that.dispatchEvent('onHide');

                        // Destroy the modal, we are not keeping tabs on previous modal atm
                        this.destroy();

                        if (queue && queue.length > 0) {
                            next = queue.splice(0, 1)[0];

                            if (next.elements) {
                                next.show();
                                that.modals.current = next;
                            }
                        } else {
                            that.modals.current = null;
                            if (that.lastFocus && UWA.is(that.lastFocus.focus, 'function')) {
                                that.lastFocus.focus();
                            }
                        }
                    }
                });

                modal.inject(options.renderTo || document.body);
                return modal;
            }
        };

        return Abstract.extend(SuperModal);
    });

