/*!================================================================
 *  JavaScript Form Validaion
 *  emxCPNCalendarValidation.js
 *  Version 1.1
 *
 *  Copyright (c) 1992-2017 Dassault Systemes. All Rights Reserved.
 *  This program contains proprietary and trade secret information
 *  of MatrixOne,Inc. Copyright notice is precautionary only
 *  and does not evidence any actual or intended publication of such program
 *
 *  static const char RCSID[] = $Id: emxCPNCalendarValidation.js.rca 1.5 Wed Apr  2 16:23:17 2008 przemek Experimental przemek $
 *=================================================================
 */
 function getDate(formName,dateField){
    updatedLocation = originalLocation + "&formName=" + formName + "&dateField=" + dateField;
    window.open(updatedLocation,'SelectDate','height=280,width=300,status=no,toolbar=no,menubar=no,location=no');
  }

   function changeDate(m,d,y,formName,dateField){
    // DATE FORMAT MM/DD/YYYY
    formattedDate = m + "/" + d + "/" + y;
    // Get the Form and Field objects and assing the date value.
    var formObject = document.forms[formName];
    var fieldObject = formObject.elements[dateField];
    fieldObject.value=formattedDate;
    fieldObject.focus();
  }

  //Added for New KeyableDate Feature on 21/7/2003
    function validateEnteredDate (formName,dateField,language) {      
		
      if(dateFormat == '1') {
        return validateEnteredShortDate (formName,dateField,language);
      } else if(dateFormat == '2') {
        return validateEnteredMediumDate (formName,dateField,language);
      }
    }

 function changeDateValue(m,d,y,formName,dateField){
 
    //create date string
//Modified for CPG X+4 HF1
    y = parseInt(y,10);

    if ((y > 50) && (y <= 99))
    {
        y = y + 1900;
    }
    else
    {
        y = y + 2000;
    }
    // This else is default (English)
    var regDate = m + "/" + d + "/" + y;
    var engDate = new Date(regDate);

    //var acceptLang = "<%=request.getHeader("Accept-Language")%>";

    // Generate Date foemat
    // IF YOU CHANGE THIS AREA, YOU HAVE TO CHANGE [emxProgramMethods.jsp]...

    if ( acceptLang.indexOf("ja") == 0 ) {
        formattedDate = y + "/";
        if ( 0 < m && m < 10 ) {
          formattedDate += "0";
        }
        formattedDate = formattedDate + m + "/" + d;
    } else if (acceptLang.indexOf("de") == 0) {
        formattedDate = d + ".";
        if ( 0 < m && m < 10 ) {
          formattedDate += "0";
        }
        formattedDate = formattedDate + m + "." + y;
    } else if ( acceptLang.indexOf("fr-ca") == 0 ) {
        formattedDate = y + "-";
        if ( 0 < m && m < 10 ) {
          formattedDate += "0";
        }
        formattedDate = formattedDate + m + "-" + d;
    } else if (acceptLang.indexOf("fr") == 0) {
        var arrMonthNamesFR = new Array("janv.","f\u00E9vr.","mars","avr.","mai","juin","juil.","ao\u00FBt","sept.","oct.","nov.","d\u00E9c.");
        if ( 1900 <= y && y < 2000 ) {
          y = y - 1900;
        }
        if ( 2000 <= y && y < 2100 ) {
          y = y - 2000;
        }
        formattedDate = d + " " + arrMonthNamesFR[engDate.getMonth()] + " ";
        if ( 0 < y && y < 10 ) {
          formattedDate += "0";
        }
        formattedDate = formattedDate + y;
    } else if (acceptLang.indexOf("es") == 0) {
		var arrMonthNamesES = new Array("jan","feb.","mar","apr.","may","jun","jul.","aug","sep","oct","nov","dic");
		if ( 1900 <= y && y < 2000 ) {
		  y = y - 1900;
		}
		if ( 2000 <= y && y < 2100 ) {
		  y = y - 2000;
		}
		formattedDate = d + "-" + arrMonthNamesES[engDate.getMonth()] + "-";
		if ( 0 < y && y < 10 ) {
		  formattedDate += "0";
		}
		formattedDate = formattedDate + y;
	} else if (acceptLang.indexOf("it") == 0) {
        var arrMonthNamesIT = new Array("gen","feb","mar","apr","mag","giu","lug","ago","set","ott","nov","dic");
        if ( 1900 <= y && y < 2000 ) {
          y = y - 1900;
        }
        if ( 2000 <= y && y < 2100 ){
          y = y - 2000;
        }
        formattedDate = d + "-" + arrMonthNamesIT[engDate.getMonth()] + "-";
        if ( 0 < y && y < 10 ) {
          formattedDate += "0";
        }
        formattedDate = formattedDate + y;
    } else if (acceptLang.indexOf("ko") == 0) {
        formattedDate = y + "-";
        if ( 0 < m && m < 10 ) {
          formattedDate += "0";
        }
        formattedDate = formattedDate + m + "-" + d;
    } else if (acceptLang.indexOf("zh") == 0) {
        formattedDate = y + "-" + m + "-" + d;
    } else {
        //save getTime() info for form validation
        //to make sure starting date <= ending date
        if(formName == "ProjectEdit")
        {
            if(dateField == "EstimatedStartDate")
            {
                startDateTime = engDate.getTime();
            }
            else if(dateField == "EstimatedFinishDate")
            {
                endDateTime = engDate.getTime();
            }
        }

        //data for date calculation - needs to be redone for other countries
        var arrMonthNames = new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
        formattedDate = arrMonthNames[engDate.getMonth()] + " " + engDate.getDate() + ", " + engDate.getFullYear();
    }

    // Get the Form and Field objects and assing the date value.
    var formObject = document.forms[formName];
    var fieldObject = formObject.elements[dateField];
    fieldObject.value=formattedDate;
  }
function validateEnteredMediumDate (formName,dateField,language) {  
	  var formObject = document.forms[formName];
      var fieldObject = formObject.elements[dateField];
      fieldObject.value = trimWhitespace(fieldObject.value);
      var dateStr=trimWhitespace(fieldObject.value);
      var langArray = language.split(",");
      var baseLangArr = langArray[0].split("-");
      var baseLang = baseLangArr[0];
      var sLength = dateStr.length;
      var months   = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      var frMonths = ["janv.","f\u00e9vr.","mars","avr.","mai","juin","juil.","ao\u00fbt","sept.","oct.","nov.","d\u00e9c."];
      var itMonths = ["gen","feb","mar","apr","mag","giu","lug","ago","set","ott","nov","dic"];
      var ptMonths = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
      var elMonths = ["\u0399\u03b1\u03bd\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2" ,
                "\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2",
                "\u039c\u03ac\u03c1\u03c4\u03b9\u03bf\u03c2",
          "\u0391\u03c0\u03c1\u03af\u03bb\u03b9\u03bf\u03c2",
          "\u039c\u03ac\u03b9\u03bf\u03c2",
          "\u0399\u03bf\u03cd\u03bd\u03b9\u03bf\u03c2",
          "\u0399\u03bf\u03cd\u03bb\u03b9\u03bf\u03c2",
          "\u0391\u03cd\u03b3\u03bf\u03c5\u03c3\u03c4\u03bf\u03c2",
          "\u03a3\u03b5\u03c0\u03c4\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2",
          "\u039f\u03ba\u03c4\u03ce\u03b2\u03c1\u03b9\u03bf\u03c2",
          "\u039d\u03bf\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2",
          "\u0394\u03b5\u03ba\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2"
               ];

      if (sLength == 0) {
        return true;
      }
      var sYear;
      var sMonth;
      var sDay;
      var msg;

      if (baseLang == "ja") { //2003/03/31
        var fmtchk = false;
  if(sLength == 9) {
    fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d)$/);
  }
  else {
    fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d\d)$/);
  }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 2003/03/31");
          fieldObject.focus();
          return false;
        }
        var dateArr = dateStr.split("\/");
        sYear  = parseInt(dateArr[0],10);
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[2],10);

      }else if (baseLang == "en"){ // Mar 31, 2003

        var fmtchk = false;
        if(sLength == 12) {
          fmtchk = dateStr.match(/^(\w\w\w) (\d\d), (\d\d\d\d)$/);
        }else {
          fmtchk = dateStr.match(/^(\w\w\w) (\d), (\d\d\d\d)$/);
        }
        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " Mar 31, 2003");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split(" ");
        sMonth = dateArr[0];
        sDay   = parseInt(dateArr[1],10);
        sYear  = parseInt(dateArr[2],10);

        // Test the month for validity
        var found = false;
        for (i=0;i<12;i++) {
          if (months[i] == sMonth) {
            sMonth = i+1;
            found = true;
            break;
          }
        }
        if (found == false) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonthFormat</emxUtil:i18nScript>" + " Mar 31, 2003");
          fieldObject.focus();
          return false;
        }

      }else if (baseLang == "de") { // 31.03.2002
        var fmtchk = false;
        if(sLength == 9) {
          fmtchk = dateStr.match(/^(\d)\.(\d\d)\.(\d\d\d\d)$/);
        } else {
          fmtchk = dateStr.match(/^(\d\d)\.(\d\d)\.(\d\d\d\d)$/);
        }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31.03.2003");
          fieldObject.focus();
          return false;
        }

        var dateArr = dateStr.split(".");
        sYear  = parseInt(dateArr[2],10);
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[0],10);

      }else if (baseLang == "it") { //31-mar-03
        var fmtchk = false;
        if(sLength == 9) {
          fmtchk = dateStr.match(/^(\d\d)-(\w\w\w)-(\d\d)$/);
        } else  {
          fmtchk = dateStr.match(/^(\d)-(\w\w\w)-(\d\d)$/);
        }
        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31-mar-03");
          fieldObject.focus();
          return false;
        }

        var dateArr = dateStr.split("-");
        sDay   = parseInt(dateArr[0]);
        sMonth = dateArr[1];
        sYear  = parseInt("20" + dateArr[2]);
        // Validate month
        var found = false;
        for (i=0;i<12;i++) {
          if (itMonths[i] == sMonth) {
            sMonth = i+1;
            found = true;
            break;
          }
        }
        if (found == false) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonthFormat</emxUtil:i18nScript>" + " 31-dic-03");
          fieldObject.focus();
          return false;
        }
      } else if (baseLang == "fr") { //31 mars 03
          var dateArr = dateStr.split(" ");
          sDay   = dateArr[0];
          sYear  = dateArr[2];
          var Year = sYear;
          if(dateArr.length !=3 || isNaN(sYear) || isNaN(sDay)){
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31 mars 03");
            fieldObject.focus();
            return false;
          }

          sDay   = parseInt(dateArr[0]);
          sMonth = dateArr[1];
          sYear  = parseInt("20" + dateArr[2]);
          // Validate month
          var found = false;
          for (i=0;i<12;i++){
            if (frMonths[i] == sMonth){
              sMonth = i+1;
              found = true;
              break;
            }
          }
          if (found == false){
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonthFormat</emxUtil:i18nScript>" + " 31 mars 03");
            fieldObject.focus();
            return false ;
          }
          if(sYear>2099){
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidYear</emxUtil:i18nScript>" + Year);
          fieldObject.focus();
          return false;
          }

      }else if (baseLang == "zh-cn") { // 2003-3-31

    var fmtchk = false;
    if(sLength == 10) {
      fmtchk = dateStr.match(/^(\d\d\d\d)-(\d\d)-(\d\d)$/);
    }else if(sLength == 8) {
      fmtchk = dateStr.match(/^(\d\d\d\d)-(\d)-(\d)$/);
    }else if(sLength == 9) {
      fmtchk = dateStr.match(/^(\d\d\d\d)-(\d)-(\d\d)$/) || dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d)$/);
    }

    if(!fmtchk) {
      alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 2003-3-31");
      eval("fieldObject.focus();");
      return false;
    }

    var dateArr = dateStr.split("-");
    sMonth = parseInt(dateArr[1],10);
    sDay   = parseInt(dateArr[2],10);
    sYear  = parseInt(dateArr[0],10);
      }else if (baseLang == "zh-tw"){ // 2003/3/31
        var fmtchk = false;
        if(sLength == 10) {
          fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d\d)$/);
        }else if(sLength == 8) {
          fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d)\/(\d)$/);
        }else if(sLength == 9) {
          fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d)\/(\d\d)$/) || dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d)$/);
        }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 2003/3/31");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split("\/");
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[2],10);
        sYear  = parseInt(dateArr[0],10);
      }else if (baseLang == "es"){ // 31-mar-03
        var fmtchk = dateStr.match(/^(\d\d)-(\w\w\w)-(\d\d)$/);

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31-mar-03");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split("-");
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[0],10);
        sYear  = parseInt("20" + dateArr[2],10);
      }
      else if (baseLang == "el"){ // j nnn aaaa
          var dateArr = dateStr.split(" ");
          sDay   = dateArr[0];
          sYear  = dateArr[2];
          var Year = sYear;
          if(dateArr.length !=3 || isNaN(sYear) || isNaN(sDay)){
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31 Mar 03");
            fieldObject.focus();
            return false;
          }

          sDay   = parseInt(dateArr[0]);
          sMonth = dateArr[1];
          sYear  = parseInt(dateArr[2]);
          // Validate month
          var found = false;
          for (i=0;i<12;i++){
            if (elMonths[i] == sMonth){
              sMonth = i+1;
              found = true;
              break;
            }
          }
          if (found == false){
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonthFormat</emxUtil:i18nScript>" + " 31 Mar 03");
            fieldObject.focus();
            return false ;
          }
          if(sYear>2099){
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidYear</emxUtil:i18nScript>" + Year);
          fieldObject.focus();
          return false;
          }

      }else if (baseLang == "pt"){ // d/MMM/yy
          var dateArr = dateStr.split("\/");
          sDay   = dateArr[0];
          sYear  = dateArr[2];
          var Year = sYear;
          if(dateArr.length !=3 || isNaN(sYear) || isNaN(sDay)){
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31/Mar/03");
            fieldObject.focus();
            return false;
          }

          sDay   = parseInt(dateArr[0]);
          sMonth = dateArr[1];
          sYear  = parseInt("20" + dateArr[2]);
          // Validate month
          var found = false;
          for (i=0;i<12;i++){
            if (ptMonths[i] == sMonth){
              sMonth = i+1;
              found = true;
              break;
            }
          }
          if (found == false){
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonthFormat</emxUtil:i18nScript>" + "  31/Mar/03");
            fieldObject.focus();
            return false ;
          }
          if(sYear>2099){
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidYear</emxUtil:i18nScript>" + Year);
          fieldObject.focus();
          return false;
          }
      }

      if (sYear < 1900) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidYear</emxUtil:i18nScript>" + Year);
        fieldObject.focus();
        return false;
      } else if (sMonth < 1 || sMonth > 12) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonth</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if (sDay < 1 || sDay > 31) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay31</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if ((sMonth == 4 || sMonth == 6 ||
                  sMonth == 9 || sMonth == 11) && sDay == 31) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay30</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if (sMonth == 2 && sDay > 29) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay28</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if (sMonth == 2 && sDay == 29) {
          var iMod = sYear % 4;
          if (iMod == 0) {
            iMod = sYear % 100;
            if (iMod == 0) {
              iMod = sYear % 400;
              if (iMod != 0) {
                alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay28</emxUtil:i18nScript>");
                fieldObject.focus();
                return false;
              }
            }
          }else{
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay28</emxUtil:i18nScript>");
            fieldObject.focus();
            return false;
          }
      }

      return true;
  }
 function validateEnteredShortDate (formName,dateField,language) {
	 
      var formObject = document.forms[formName];
      var fieldObject = formObject.elements[dateField];
      fieldObject.value = trimWhitespace(fieldObject.value);
      var dateStr=trimWhitespace(fieldObject.value);
      var langArray = language.split(",");
      var baseLangArr = langArray[0].split("-");
      var baseLang = baseLangArr[0];
      var sLength = dateStr.length;

      if (sLength == 0) {
        return true;
      }
      var sYear;
      var sMonth;
      var sDay;
      var msg;

      if (baseLang == "ja") { //03/12/31
        var fmtchk = false;

  fmtchk = dateStr.match(/^(\d\d)\/(\d\d)\/(\d\d)$/);

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 03/12/31");
          fieldObject.focus();
          return false;
        }
        var dateArr = dateStr.split("\/");
        sYear  = parseInt("20" + dateArr[0],10);
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[2],10);

      }else if (baseLang == "en"){ // 3/31/2003
        var fmtchk = false;
        if(sLength == 10) {
          fmtchk = dateStr.match(/^(\d\d)\/(\d\d)\/(\d\d\d\d)$/);
        }else if(sLength == 8) {
          fmtchk = dateStr.match(/^(\d)\/(\d)\/(\d\d\d\d)$/);
        }else if(sLength == 9) {
          fmtchk = dateStr.match(/^(\d\d)\/(\d)\/(\d\d\d\d)$/) || dateStr.match(/^(\d)\/(\d\d)\/(\d\d\d\d)$/);
        }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 3/31/2003");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split("\/");
        sMonth = parseInt(dateArr[0],10);
        sDay   = parseInt(dateArr[1],10);
        sYear  = parseInt(dateArr[2],10);
      }else if (baseLang == "de") { // 31.03.02
        var fmtchk = false;
        fmtchk = dateStr.match(/^(\d\d)\.(\d\d)\.(\d\d\d\d)$/);

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31.03.02");
          fieldObject.focus();
          return false;
        }

        var dateArr = dateStr.split(".");
        sYear  = parseInt("20" + dateArr[2],10);
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[0],10);

      }else if (baseLang == "it") { //31/12/03
  var fmtchk = dateStr.match(/^(\d\d)\/(\d\d)\/(\d\d)$/);

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31/12/03");
          fieldObject.focus();
          return false;
        }

        var dateArr = dateStr.split("\/");
        sDay   = parseInt(dateArr[0]);
        sMonth = parseInt(dateArr[1]);
        sYear  = parseInt("20" + dateArr[2]);
      } else if (baseLang == "fr") { // 31/03/03
          var fmtchk = dateStr.match(/^(\d\d)\/(\d\d)\/(\d\d)$/);
    if(!fmtchk) {
      alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31/03/03");
      fieldObject.focus();
      return false;
    }

          var dateArr = dateStr.split("\/");
          sDay   = parseInt(dateArr[0]);
          sMonth = parseInt(dateArr[1]);
          sYear  = parseInt("20" + dateArr[2]);
      } else if (baseLang == "zh-cn") { // 31-3-31

    var fmtchk = false;
    if(sLength == 8) {
      fmtchk = dateStr.match(/^(\d\d)-(\d\d)-(\d\d)$/);
    }else if(sLength == 6) {
      fmtchk = dateStr.match(/^(\d\d)-(\d)-(\d)$/);
    }else if(sLength == 7) {
      fmtchk = dateStr.match(/^(\d\d)-(\d)-(\d\d)$/) || dateStr.match(/^(\d\d)\/(\d\d)\/(\d)$/);
    }

    if(!fmtchk) {
      alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31-3-31");
      eval("fieldObject.focus();");
      return false;
    }

    var dateArr = dateStr.split("-");
    sMonth = parseInt(dateArr[1],10);
    sDay   = parseInt(dateArr[2],10);
    sYear  = parseInt("20" + dateArr[0],10);
      }else if (baseLang == "zh-tw"){ // 2003/3/31
        var fmtchk = false;
        if(sLength == 10) {
          fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d\d)$/);
        }else if(sLength == 8) {
          fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d)\/(\d)$/);
        }else if(sLength == 9) {
          fmtchk = dateStr.match(/^(\d\d\d\d)\/(\d)\/(\d\d)$/) || dateStr.match(/^(\d\d\d\d)\/(\d\d)\/(\d)$/);
        }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 2003/3/31");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split("\/");
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[2],10);
        sYear  = parseInt(dateArr[0],10);
      }else if (baseLang == "es"){ // 31/03/03
        var fmtchk = false;
        if(sLength == 8) {
          fmtchk = dateStr.match(/^(\d\d)\/(\d\d)\/(\d\d)$/);
        }else if(sLength == 7) {
          fmtchk = dateStr.match(/^(\d)\/(\d\d)\/(\d\d)$/);
        }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31/03/03");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split("\/");
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[0],10);
        sYear  = parseInt("20" + dateArr[2],10);
      }else if (baseLang == "el"){ // 31/3/2003
        var fmtchk = false;
        if(sLength == 10) {
          fmtchk = dateStr.match(/^(\d\d)\/(\d\d)\/(\d\d\d\d)$/);
        }else if(sLength == 8) {
          fmtchk = dateStr.match(/^(\d)\/(\d)\/(\d\d\d\d)$/);
        }else if(sLength == 9) {
          fmtchk = dateStr.match(/^(\d\d)\/(\d)\/(\d\d\d\d)$/) || dateStr.match(/^(\d)\/(\d\d)\/(\d\d\d\d)$/);
        }

        if(!fmtchk) {
          alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31/3/2003");
          eval("fieldObject.focus();");
          return false;
        }

        var dateArr = dateStr.split("\/");
        sMonth = parseInt(dateArr[1],10);
        sDay   = parseInt(dateArr[0],10);
        sYear  = parseInt(dateArr[2],10);
      }else if (baseLang == "pt"){ // 31-03-2003
              var fmtchk = dateStr.match(/^(\d\d)-(\d\d)-(\d\d\d\d)$/);

              if(!fmtchk) {
                alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.DateFormatError</emxUtil:i18nScript>" + " 31-03-2003");
                eval("fieldObject.focus();");
                return false;
              }

              var dateArr = dateStr.split("-");
              sMonth = parseInt(dateArr[1],10);
              sDay   = parseInt(dateArr[0],10);
              sYear  = parseInt(dateArr[2],10);
      }

      if (sYear < 1900) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidYear</emxUtil:i18nScript>" + Year);
        fieldObject.focus();
        return false;
      } else if (sMonth < 1 || sMonth > 12) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidMonth</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if (sDay < 1 || sDay > 31) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay31</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if ((sMonth == 4 || sMonth == 6 ||
                  sMonth == 9 || sMonth == 11) && sDay == 31) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay30</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if (sMonth == 2 && sDay > 29) {
        alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay28</emxUtil:i18nScript>");
        fieldObject.focus();
        return false;
      } else if (sMonth == 2 && sDay == 29) {
          var iMod = sYear % 4;
          if (iMod == 0) {
            iMod = sYear % 100;
            if (iMod == 0) {
              iMod = sYear % 400;
              if (iMod != 0) {
                alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay28</emxUtil:i18nScript>");
                fieldObject.focus();
                return false;
              }
            }
          }else{
            alert("<emxUtil:i18nScript localize=\"i18nId\">emxCPN.Date.InvalidDay28</emxUtil:i18nScript>");
            fieldObject.focus();
            return false;
          }
      }

      return true;
  }



