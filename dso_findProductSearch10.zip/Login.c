Login()
{
	web_set_sockets_option("SSL_VERSION", "2&3");
	
	web_set_max_html_param_len("99999");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");	
	
	lr_start_transaction("dso_findProductSearch01_NegvtIE");

	web_reg_find("Text=3DPassport - Login", 
		LAST);
	
	/*Correlation comment - Do not change!  Original value='LT-700-5nxfbdUVELYwWDWzvQVneWmIhcrwBk' Name ='lt' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=lt",
		//"LB=\"en\",\"notificationMsgs\":[],\"lt\":\"",
		"LB=\"lt\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		//"RequestUrl=*/login*",
		LAST);		

	web_url("plmtest.pg.com", 
		"URL=https://plmtest.pg.com/enovia", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/fonts/3ds/3dsregular.woff2", "Referer=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/css/main-ifwe.css", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/js/DS/W3DPassport/W3DPassport.js", "Referer=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/js/DS/W3DPassport/dsp/DSP.js", "Referer=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/js/DS/W3DPassport/dsp/utils/loadCustomCss.js", "Referer=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/js/DS/W3DPassport/login.js", "Referer=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/img/3dexperience/3DEXLoginCompassTxt.png", "Referer=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/css/main-ifwe.css", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/fonts/uwa/icons.woff", "Referer=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/css/main-ifwe.css", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/fonts/3ds/entypo.woff2", "Referer=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/css/main-ifwe.css", ENDITEM, 
		"Url=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/fonts/3ds/3dslight.woff2", "Referer=https://plmsit-3dp.pg.com/3dpassport/resources-180713164522/css/main-ifwe.css", ENDITEM, 
		LAST);

	web_url("en", 
		"URL=https://plmsit-3dp.pg.com/3dpassport/api/public/i18n/local/en", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("dso_findProductSearch01_NegvtIE",LR_AUTO);
	
	lr_think_time(lr_get_attrib_double("time"));
	
	lr_start_transaction("dso_findProductSearch02_login");
	
	web_reg_save_param_ex(
		"ParamName=ticket",
		"LB=ticket=",
		"RB=\r\nContent-Language",
		SEARCH_FILTERS,
		"Scope=Headers",
		"IgnoreRedirections=No",
		//"RequestUrl=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080",
		LAST);

	web_add_header("Origin", 
		"https://plmsit-3dp.pg.com");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("login", 
		"Action=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://plmsit-3dp.pg.com/3dpassport/login?service=https%3A%2F%2Fplmtest.pg.com%2Fenovia%2F%3FserverId%3Drd628o00000000000000000000ffff97d0ccd9o8080", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=lt", "Value={lt}", ENDITEM, 
		"Name=fp", "Value=d6b56e5e7108cf2e1958fe2514cca937f14807724e153bb1d6b2c659589b8be089c2eb22bbfd316118dd064205a740cf4fda893582dee44c9958f50c1f9d6219", ENDITEM, 
		"Name=username", "Value={pUserName}", ENDITEM, 
		"Name=password", "Value={pPassword}", ENDITEM, 
		LAST);	
	
	lr_end_transaction("dso_findProductSearch02_login",LR_AUTO);
		
	lr_start_transaction("dso_findProductSearch03_SelectRoleAndLoadHomePage");
	
	web_reg_find("Text=3DEXPERIENCE Platform", 
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=ENO_CSRF_TOKEN",
		"LB=name= \"ENO_CSRF_TOKEN\" value=\"",
		"RB=\" ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/emxSecurityContextSelection.jsp*",
		LAST);
	
	web_url("emxSecurityContextSelection.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxSecurityContextSelection.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/?ticket={ticket}", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=emxUIConstantsJavaScriptInclude.jsp", ENDITEM, 
		"Url=fonts/3ds-Regular.woff", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIDefault.css", ENDITEM, 
		"Url=images/utilProgressGray.gif", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIDefault.css", ENDITEM, 
		"Url=fonts/3ds-Light.woff", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIDefault.css", ENDITEM, 
		"Url=images/Next_btn.png", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIDefault.css", ENDITEM, 
		"Url=images/Previous_btn.png", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIDefault.css", ENDITEM, 
		"Url=images/Home_btn.png", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIDefault.css", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://plmsit-3dp.pg.com");

	web_submit_data("emxSecurityContextSelectionProcess.jsp", 
		"Action=https://plmtest.pg.com/enovia/common/emxSecurityContextSelectionProcess.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxSecurityContextSelection.jsp", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=widgetId", "Value=null", ENDITEM, 
		"Name=locationAwareMode", "Value=true", ENDITEM, 
		"Name=txtUserName", "Value={pUserName}", ENDITEM, 
		"Name=txtCurrentLocation", "Value=UNITED STATES", ENDITEM, 
		"Name=txtNewLocation", "Value=UNITED STATES", ENDITEM, 
		"Name=Organization", "Value=PG", ENDITEM, 
		"Name=Project", "Value=Internal_PG", ENDITEM, 
		"Name=Role", "Value={pRole}", ENDITEM, 
		"Name=csrfTokenName", "Value=ENO_CSRF_TOKEN", ENDITEM, 
		"Name=ENO_CSRF_TOKEN", "Value={ENO_CSRF_TOKEN}", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");
	
	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("emxNavigator.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxSecurityContextSelectionProcess.jsp", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webapps/UIKIT/assets/fonts/3dsregular.ttf", "Referer=https://plmtest.pg.com/enovia/webapps/UIKIT/UIKIT.css", ENDITEM, 
		"Url=../plugins/IFWENavigator/images/Top_Bar_Layer_Top.png", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUINavigator.css", ENDITEM, 
		"Url=../webapps/UIKIT/assets/fonts/3dsbold.ttf", "Referer=https://plmtest.pg.com/enovia/webapps/UIKIT/UIKIT.css", ENDITEM, 
		"Url=../webapps/UIKIT/assets/fonts/3dslight.ttf", "Referer=https://plmtest.pg.com/enovia/webapps/UIKIT/UIKIT.css", ENDITEM, 
		"Url=../webapps/i3DXCompass/assets/images/compass.png", "Referer=https://plmtest.pg.com/enovia/webapps/i3DXCompass/i3DXCompass.css", ENDITEM, 
		"Url=images/utilPanelMenuArrows.png", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUINavigator.css", ENDITEM, 
		"Url=../webapps/UIKIT/assets/fonts/3ds-icon.woff2", "Referer=https://plmtest.pg.com/enovia/webapps/UIKIT/UIKIT.css", ENDITEM, 
		LAST);
	
	web_save_timestamp_param("tStamp", LAST); 
 	lr_save_string(lr_eval_string("{tStamp}"),"Apptimestamp");

	web_add_header("Origin", 
		"https://plmsit-3dp.pg.com");

	web_custom_request("emxClientSideInfoProcessing.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxClientSideInfoProcessing.jsp?xhr=0.25047869290216607", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		"EncType=text/xml", 
		"Body=<emxRoot><timeZoneOffset>5</timeZoneOffset><clientSideUrlInfo><protocol>https:</protocol><host>plmtest.pg.com</host><port></port><pathname>/enovia/common/emxNavigator.jsp</pathname></clientSideUrlInfo></emxRoot>", 
		EXTRARES, 
		"Url=styles/emxUICalendar.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/i3DXCompassPlatformServices/i3DXCompassPlatformServices.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=styles/emxUIMenu.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TopBar/TopBar.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TopFrame/TopFrame.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWPClientCode/UWPClientCode.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/SNSearchUX/SNSearchUX.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TopBarProxy/TopBarProxy.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TagNavigator/assets/TaggerSettings.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Class/Collection.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Class/Model.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Class/View.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Controls/TabView.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TagNavigatorProxy/TagNavigatorProxy.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Controls/Overlay.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Controls/Carousel.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TagNavigator/TagNavigator_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/W3DLegal/W3DLegal.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WAFData/WAFData.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UIKIT/UIKIT.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/MSFDocumentManagement/MSFDocumentManagement.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Class/Listener.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TopBar/assets/nls/TopBar_temp.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);
	
	web_save_timestamp_param("tStamp", LAST); 
 	lr_save_string(lr_eval_string("{tStamp}"),"timestamp1");

	web_url("TopBarView.html", 
		"URL=https://plmtest.pg.com/enovia/webapps/TopBar/assets/templates/TopBarView.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/webapps/UWA2/js/Controls/Accordion.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/UWA2/js/Controls/Scroller.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/ENOFrameworkSearch/SearchUIContainer.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/UWA2/js/Controls/ToolTip.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/TopFrame/TopFrame_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/ENOFrameworkSearch/Search.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/ENOFrameworkSearch/Tagger.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/ENOFrameworkSearch/TopFrameInit.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/TopBar/TopBar_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/Handlebars/Handlebars.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/Usage/Usage.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/i3DXCompassServices/i3DXCompassServices.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/PubSub/PubSub.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/Logger/Logger.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNInfraUX/SNInfraUX.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/W3DLegal/W3DLegal.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/UWA2/js/Controls/Segmented.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/UWA2/assets/css/inline.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/TopBar/TopBar.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/W3DLegal/W3DLegal_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNResultUX/SNResultUX.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/VENHandlebars/handlebars-v1.3.0.min.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/ENOFrameworkSearch/ENOFrameworkSearch_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/PlatformAPI/PlatformAPI.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/resources/AppsMngt/user/getPreferences?name=dnsa&_={timestamp1}", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNInfraUX/assets/SearchSettings.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNInfraUX/assets/SearchSettings_Public.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNInfraUX/assets/SearchView.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/WebRecordEnabler/WebRecordEnabler.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/SNInfraUX/SNInfraUX_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/UIKIT/UIKIT_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/webapps/WebRecordEnabler/Adapter.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/resources/AppsMngt/user/startup?_={timestamp1}", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("ief.jsp", 
		"URL=https://plmtest.pg.com/enovia/integrations/ief.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/integrations/emxIntegrations.jsp", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webapps/SNResultUX/SNResultUX.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/SNInfraUX/assets/SearchColumnCustoAdmin.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/SNInfraUX/assets/SearchColumnCustoDS.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/SNResultUX/assets/SNResultUX_custo.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/egraph/views.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/etree/syncviews.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/etree/basicviews.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/etree/overviewui.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/egraph/views_default.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WebRecordBase/WebRecordBase.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/MessageBus/MessageBus.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/W3DXComponents/W3DXComponents.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/i3DXSNDictionaryAPI/i3DXSNDictionaryAPI.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/SNResultUX/SNResultUX_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/TreeModel/TreeModel.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WebAppsFoundations/WebAppsFoundations.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Utilities/Utilities.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Controls/Controls.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Windows/Windows.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/etree/etree.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Core/Core.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/egraph/egraph.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/CefCommunication/CefCommunication.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/i3DXCompassPlatformServices/i3DXCompassPlatformServices_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WebRecordBase/Utils.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/W3DXComponents/W3DXComponents.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WebRecordBase/Constants.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WebRecordBase/TraceManager.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Selection/Selection.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/CoreEvents/CoreEvents.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNjguMC4zNDQwLjEwNhonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgF7vl5NiIEIAEgAigDGikIBRABGhsKDQgFEAYYASIDMDAxMAEQpMEFGgIYBW2RbsIiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAIaAhgFDp-i6SIEIAEgAigGGikIARABGhsKDQgBEAYYASIDMDAxMAEQjJgFGgIYBTf8wqUiBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABELifBRoCGAUW6M3JIgQgASACKAEaKAgBEAgaGgoNCAEQCBgBIgMwMDEwBBCPFRoCGAVDj1cTIgQgASACKAQaKQgHEAEaGwoNCAcQBhgBIgMwMDEwARC1qwQaAhgFChItaSIEIAEgAigBGicIChAIGhkKDQgKEAgYASIDMDAxMAEQBRoCGAUenj-dIgQgASACKAEaJwgJEAEaGQ"
		"oNCAkQBhgBIgMwMDEwARANGgIYBSAqW7QiBCABIAIoARooCAgQARoaCg0ICBAGGAEiAzAwMTABEMYEGgIYBTJY75UiBCABIAIoARooCA0QARoaCg0IDRAGGAEiAzAwMTABENseGgIYBcnz2IEiBCABIAIoARooCA4QARoaCg0IDhAGGAEiAzAwMTABEPlLGgIYBVNmTHEiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		"Url=../webapps/W3DXComponents/W3DXComponents_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/WebRecordBase/UIMessenger.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Core/wux.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UIBehaviors/UIBehaviors.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Windows/Windows_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Core/wux-3ds-fonticons.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Menu/Menu.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Tree/Tree.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/etree/etree_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Controls/Controls_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Menu/assets/css/Menu.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Spreadsheet/Spreadsheet.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Layouts/Layouts.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Maths/Maths.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Tweakers/Tweakers.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Controls/DatePicker.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Controls/Calendar.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/UWA2/js/Controls/Picker.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Tweakers/assets/defaultTypeRepresentations.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/SmartInputs/SmartInputs.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=../webapps/Tweakers/assets/typeTemplates.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("profileImage", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/profileImage", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("emxNavigatorContentLoad.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxNavigatorContentLoad.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("appName", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/appName?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/webapps/TopBar/assets/sprite2x.png", "Referer=https://plmtest.pg.com/enovia/webapps/TopBar/TopBar.css", ENDITEM, 
		"Url=/enovia/webapps/Menu/assets/fonts/entypo.woff", "Referer=https://plmtest.pg.com/enovia/webapps/Menu/assets/css/Menu.css", ENDITEM, 
		"Url=/enovia/webapps/i3DXCompass/assets/lang/en.json", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);


	web_url("AEFShareMenu", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/AEFShareMenu?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		LAST);


	web_url("AEFPersonMenu", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/AEFPersonMenu?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		LAST);


	web_url("AEFMyHome", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/AEFMyHome?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		LAST);
 	

	web_url("collabSpace", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/collabSpace?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		LAST);

	web_url("AEFHelpMenu", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/AEFHelpMenu?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		LAST);

	web_url("services", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		LAST);

	web_url("services_2", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		LAST);

	web_url("Actions", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/menu/Actions?_={Apptimestamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SearchView.html", 
		"URL=https://plmtest.pg.com/enovia/webapps/SNSearchUX/assets/templates/SearchView.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		LAST);
	
	web_save_timestamp_param("tStamp", LAST); 
 	lr_save_string(lr_eval_string("{tStamp}"),"timestamp9");
 	
 	web_set_max_html_param_len("9999");
 
	web_reg_save_param_ex(
		"ParamName=proxyTicket",
		"LB=\{\"result\": \"",
		"RB=\"\}",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		//"RequestUrl=/*proxyticket*",
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("proxyticket", 
		"URL=https://plmtest.pg.com/enovia/resources/bps/proxyticket?t={timestamp9}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/webapps/SNSearchUX/SNSearchUX.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_url("services_3", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_add_header("Origin", 
		"https://plmsit-3dp.pg.com");

	web_custom_request("fields", 
		"URL=https://plmsit-3dp.pg.com/3dpassport/api/authenticated/user/fields?xrequestedwith=xmlhttprequest", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("services_4", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		LAST);
	
	web_save_timestamp_param("tStamp", LAST); 
 	lr_save_string(lr_eval_string("{tStamp}"),"timestamp10");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("emxPortal.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxPortal.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigatorContentLoad.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../resources/AppsMngt/apps/compass?os=windows&_={timestamp10}", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("services_5", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);


	web_add_header("Origin", 
		"https://plmsit-3dp.pg.com");

	web_url("getcastgc", 
		"URL=https://plmsit-3dp.pg.com/3dpassport/cas/getcastgc?userid={pUserName}&service=V6&ticket={proxyTicket}&callback=https%3A%2F%2Fplmstress%2epg%2ecom%2Fenovia%2Fwebapps%2Fi3DXCompass%2Fgettgc%2ehtml&xrequestedwith=xmlhttprequest", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://plmtest.pg.com/enovia/webapps/InstantMessaging/InstantMessaging.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=https://plmtest.pg.com/enovia/webapps/Frame3DXInfra/Frame3DXInfra.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=https://plmtest.pg.com/enovia/webapps/W3DXNavigationMenu/W3DXNavigationMenu.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("services_6", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/webapps/SNSearchUX/SNSearchUX_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);


	web_add_header("Origin", 
		"https://plmsit-3dp.pg.com");

	web_custom_request("fields_2", 
		"URL=https://plmsit-3dp.pg.com/3dpassport/api/authenticated/user/fields?xrequestedwith=xmlhttprequest", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		EXTRARES, 
		"Url=https://plmtest.pg.com/enovia/webapps/W3DXNavigationMenu/W3DXNavigationMenu_en.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=https://plmtest.pg.com/enovia/webapps/W3DXNavigationMenu/W3DXNavigationMenu.css", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("services_7", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/webapps/RTProxyDriver/RTProxyDriver.js", "Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", ENDITEM, 
		"Url=/enovia/common/styles/emxUIToolbar.css", "Referer=https://plmtest.pg.com/enovia/common/emxPortal.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", ENDITEM, 
		"Url=/enovia/common/styles/emxUIDOMLayout.css", "Referer=https://plmtest.pg.com/enovia/common/emxPortal.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", ENDITEM, 
		LAST);

	web_url("services_8", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("emxPortalDisplay.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/emxPortalDisplay.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxPortal.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		LAST);


	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("services_9", 
		"URL=https://plmtest.pg.com/enovia/resources/AppsMngt/api/v1/services?cors=true", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/enovia/common/styles/emxUIPortal.css", "Referer=https://plmtest.pg.com/enovia/common/emxPortalDisplay.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", ENDITEM, 
		"Url=/enovia/common/images/utilProgressGraySmall.gif", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIPortal.css", ENDITEM, 
		"Url=/enovia/common/images/utilSpacer.gif", "Referer=https://plmtest.pg.com/enovia/common/emxPortalDisplay.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", ENDITEM, 
		"Url=/enovia/common/images/utilPowerviewMinmax.png", "Referer=https://plmtest.pg.com/enovia/common/styles/emxUIPortal.css", ENDITEM, 
		"Url=/enovia/common/images/utilTabsetArrow.gif", "Referer=https://plmtest.pg.com/enovia/common/emxPortalDisplay.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", ENDITEM, 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("pgDigitalInnovationPLMSystem.jsp", 
		"URL=https://plmtest.pg.com/enovia/common/pgDigitalInnovationPLMSystem.jsp?SuiteDirectory=common&portalCmdName=pgDigitalInnovationPLMSystem&jsTreeID=null&suiteKey=Framework&portalMode=true&portal=AEFPowerView&StringResourceFileId=emxFrameworkStringResource", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://plmtest.pg.com/enovia/common/emxPortalDisplay.jsp?portal=AEFPowerView&suiteKey=Framework&StringResourceFileId=emxFrameworkStringResource&SuiteDirectory=common", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		LAST);
		
	lr_end_transaction("dso_findProductSearch03_SelectRoleAndLoadHomePage",LR_AUTO);

	web_add_auto_header("Origin", 
		"https://plmsit-3dp.pg.com");


	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"GET");
	

	web_custom_request("login_3", 
		//"URL=https://plmsit-fed.pg.com:443/federated/login?tenant=OnPremise&xrequestedwith=xmlhttprequest", 
		"URL=https://plmsit-fed.pg.com:443/federated/login?tenant=OnPremise&xrequestedwith=xmlhttprequest", 
		
		
		
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t580.inf", 
		"Mode=HTML", 
		LAST);
	
		web_reg_save_param_ex(
		"ParamName=token",
		"LB=\"access_token\":\"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		//"RequestUrl=/*login*",
		LAST);
	
	
	web_url("login_4", 
		//"URL=https://plmsit-3dp.pg.com/3dpassport/cas/login?service=https%3A%2F%2Fplmsit-fed.pg.com:443%2Ffederated%2Flogin%3Ftenant%3DOnPremise%26xrequestedwith%3Dxmlhttprequest&xrequestedwith=xmlhttprequest", 
		"URL=https://plmsit-3dp.pg.com:443/3dpassport/cas/login?service=https%3A%2F%2Fplmsit-fed.pg.com%2Ffederated%2Flogin%3Ftenant%3DOnPremise%26xrequestedwith%3Dxmlhttprequest%26serverId%3D3670855831.49175.0000&xrequestedwith=xmlhttprequest",
		

		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t581.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"GET");	

	web_custom_request("login_5", 
		"URL=https://plmsit-fed.pg.com:443/federated/login?tenant=OnPremise&xrequestedwith=xmlhttprequest&serverId=3670855831%2e49175%2e0000&ticket={token}", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t582.inf", 
		"Mode=HTML", 
		LAST);
	
	web_custom_request("login_6",
		//"URL=https://plmsit-fed.pg.com:443/federated/login?tenant=OnPremise&xrequestedwith=xmlhttprequest&ticket={token}", 
		"URL= https://plmsit-fed.pg.com:443/federated/login?tenant=OnPremise&xrequestedwith=xmlhttprequest&serverId=3670855831%2e49175%2e0000&ticket={token}",
		
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://plmtest.pg.com/enovia/common/emxNavigator.jsp?ticket={ticket}&collabSpace=Internal_PG", 
		"Snapshot=t583.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);
	
	lr_think_time(lr_get_attrib_double("time"));
	
	return 0;
}
